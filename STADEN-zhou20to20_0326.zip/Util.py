import os, torch
import numpy as np
from torch import nn

from read_binbz2 import read_bin_3d_radar
import datetime
import tifffile




def prepare(dev, *args):
    # print(dev)
    device = torch.device(dev)
    if dev == 'cpu':
        device = torch.device('cpu')
    return [a.to(device) for a in args]


def calc_psnr(sr, hr, scale):
    diff = (sr - hr)
    # shave = scale + 6
    # valid = diff[..., shave:-shave, shave:-shave,:]#2，2，1
    # mse = valid.pow(2).mean()
    mse = np.mean(diff * diff) + 0.0001
    return -10 * np.log10(mse / (4095 ** 2))


def RestoreNetImg(img, mean, max, returnFlag = False, maxVal = None, minVal = None):
    # rImg = (img - self.mean1) / self.std1
    #rImg = np.maximum(np.minimum(img * max + mean, 255), 0)
    rImg = img * max + mean
    if maxVal is None:
        maxVal = np.max(rImg)*0.9
    if minVal is None:
        minVal = np.min(rImg)
    rImg = 255./(maxVal - minVal+0.001) * (rImg - minVal)
    rImg = np.maximum(np.minimum(rImg, 255), 0)
    if returnFlag:
        return rImg, maxVal, minVal
    else:
        return rImg

def RestoreNetImgV2(img, mean, max):
    # rImg = (img - self.mean1) / self.std1
    #rImg = np.maximum(np.minimum(img * max + mean, 255), 0)
    rImg = img * max + mean
    rImg = np.maximum(np.minimum(rImg, 255), 0)
    return rImg

# class GetRadarQPEDataSetAndCrop:
#     def __init__(self, radarCombineRoot,crRoot, qpeRoot, trainListRoot, trainListPrefix, trainListPostfix,epoch,yearList):
#         self.radarCombineRoot = radarCombineRoot
#         self.crRoot = crRoot
#         self.qpeRoot = qpeRoot
#         self.trainListRoot = trainListRoot
#         self.epoch = epoch
#         self.trainListPrefix = trainListPrefix
#         self.trainListPostfix = trainListPostfix
#         self.yearList = yearList
#
#         self.trainSeriesList = []
#         for year in self.yearList:
#             self.trainSeries = []
#             path = os.path.join(self.trainListRoot, '%s%d%s'%(self.trainListPrefix, year, trainListPostfix))
#             with open(path, 'r') as f:
#                 lines = f.readlines()
#                 for line in lines:
#                     self.trainSeries.append(line.rstrip('\n'))
#             self.trainSeriesList.append(self.trainSeries)
#
#         self.dem = tifffile.imread('dem_97-112_25-scale.tif')[192:832,562-200:562-200+800] #原版的200-1700
#         self.dem = self.dem.astype(float)
#         maxDem = np.max(self.dem) #归一化
#         self.dem /= maxDem
#         self.dem = np.expand_dims(self.dem,0)
#
#         self.radarChannel = [1,3,5,7,9]
#         self.inputRadar = None
#         self.goldRadar = None
#         self.conFlag = True
#         self.conThrev = 0.8
#
#     def __len__(self):
#         return self.epoch
#
#     def len(self):
#         return self.epoch
#
#     def __getitem__(self, ind):
#         self.conFlag = True
#         if np.random.rand() < self.conThrev and self.inputRadar is not None:
#             pass
#             # return self.inputRadar, self.goldRadar
#         else:
#             yearID = np.random.randint(len(self.trainSeriesList))
#             ind = np.random.randint(len(self.trainSeriesList[yearID]))
#             self.crYearDir = os.path.join(self.crRoot, str(self.yearList[yearID]))
#             self.combineYearDir = os.path.join(self.radarCombineRoot, str(self.yearList[yearID]))
#             self.qpeYearDir = os.path.join(self.qpeRoot, str(self.yearList[yearID]))
#             beginTimeStr = self.trainSeriesList[yearID][ind]
#             dt = datetime.datetime.strptime(beginTimeStr, '%Y%m%d%H%M')
#             # self.inputRadar = np.zeros((10, 3, 640,800), dtype = np.float32)
#             self.inputRadar = np.zeros((10, 2, 640, 800), dtype=np.float32)
#             self.goldRadar = np.zeros((10, 3, 640,800), dtype=np.float32)
#             # self.inputQPE = np.zeros((10, 1, 896, 1024), dtype=np.float32)
#             # self.goldQPE = np.zeros((10, 1, 896,1024), dtype=np.float32)
#             for k in range(10):
#                 curDt = dt + datetime.timedelta(minutes=6*k)
#                 curDt = curDt.strftime("%Y%m%d%H%M")
#                 crFile = os.path.join(self.crYearDir,
#                                              'CR_%s'%(curDt )
#                                              + '.tif')
#                 curCR = tifffile.imread(crFile)[ 192:832, 562:1362]
#                 curCR = curCR.astype(float) / 50. #uint8，没有负数
#                 # curRadar = np.concatenate([curRadar, self.dem], axis=0)
#                 self.inputRadar[k,0,:] = curCR #896,1024
#
#                 combineFile = os.path.join(self.combineYearDir,
#                                       'zhouCombine_%s' % (curDt)
#                                       + '.tif')
#                 curCombine = tifffile.imread(combineFile)[ 192:832, 562-200:562-200+800] # 200:1700]
#                 curCombine = curCombine.astype(float) / 50. #uint8，没有负数
#                 # curRadar = np.concatenate([curRadar, self.dem], axis=0)
#                 self.inputRadar[k, 1, :] = curCombine  # 896,1024
#
#                 # qpeFile = os.path.join(self.qpeYearDir,
#                 #                            'zhouQPE_%s' % (curDt)
#                 #                            + '.tif')
#                 # curQPE = tifffile.imread(qpeFile)[ 192:832, 562-200:562-200+800]  # 200:1700]
#                 # curQPE = curQPE.astype(float)  #uint8，没有负数
#                 # self.inputRadar[k, 2, :] = curQPE /50 # 896,1024
#
#             for k in range(10,20):
#                 curDt = dt + datetime.timedelta(minutes=6*k)
#                 curDt = curDt.strftime("%Y%m%d%H%M")
#                 crFile = os.path.join(self.crYearDir,
#                                       'CR_%s' % (curDt)
#                                       + '.tif')
#                 curCR = tifffile.imread(crFile)[192:832, 562:1362]
#                 curCR = curCR.astype(float)  / 50. #uint8，没有负数
#                 # curRadar = np.concatenate([curRadar, self.dem], axis=0)
#                 self.goldRadar[k-10,0,:] = curCR #896,1024
#
#                 combineFile = os.path.join(self.combineYearDir,
#                                            'zhouCombine_%s' % (curDt)
#                                            + '.tif')
#                 curCombine = tifffile.imread(combineFile)[192:832, 562-200:562-200+800]  # 200:1700]
#                 curCombine = curCombine.astype(float) / 50. #uint8，没有负数
#                 # curRadar = np.concatenate([curRadar, self.dem], axis=0)
#                 self.goldRadar[k-10, 1, :] = curCombine  # 896,1024
#
#                 qpeFile = os.path.join(self.qpeYearDir,
#                                        'zhouQPE_%s' % (curDt)
#                                        + '.tif')
#                 curQPE = tifffile.imread(qpeFile)[192:832, 562-200:562-200+800]  # 200:1700]
#                 curQPE = curQPE.astype(float) #uint8，没有负数
#                 # curRadar = np.concatenate([curRadar, self.dem], axis=0)
#                 # self.goldQPE[k, 0, :] = curQPE  # 896,1024
#                 self.goldRadar[k-10, 2, :] = curQPE /50.  # 896,1024
#
#             self.inputRadar = torch.from_numpy(self.inputRadar.copy()).float()
#             self.goldRadar = torch.from_numpy(self.goldRadar.copy()).float()
#             # self.inputQPE = torch.from_numpy(self.inputQPE.copy()).float()
#             # self.goldQPE = torch.from_numpy(self.goldQPE.copy()).float()
#             # self.inputRadar = inputRadar.astype(float)
#             # self.goldRadar = goldRadar.astype(float)
#             # self.inputRadar /= 50.
#             # self.goldRadar /= 50.
#
#         # rid = np.random.randint(0, 7)
#         # if rid < 4 :
#         #     pass  #
#         # if rid == 4:
#         #     self.inputRadar = self.inputRadar[:,:, ::-1, :] #T C H W
#         #     self.goldRadar = self.goldRadar[:,:, ::-1, :] #T C H W
#         # if rid == 5:
#         #     self.inputRadar = self.inputRadar[:, :, :, ::-1]  # T C H W
#         #     self.goldRadar = self.goldRadar[:, :, :, ::-1]  # T C H W
#         # if rid == 6:
#         #     self.inputRadar = self.inputRadar[:, :, ::-1, ::-1]  # T C H W
#         #     self.goldRadar = self.goldRadar[:, :, ::-1, ::-1]  # T C H W
#         # return self.inputRadar, self.inputQPE, self.goldRadar, self.goldQPE
#         return self.inputRadar,  self.goldRadar

def sort_files_by_size(root, fileList):
    # 获取目录中的所有文件名
    # files = os.listdir(directory)
    # 使用列表推导来获取文件名和大小的元组列表
    file_sizes = [(name, os.path.getsize(os.path.join(root, 'CR_%s.tif'%name))) for name in fileList]
    sizes = [os.path.getsize(os.path.join(root, 'CR_%s.tif'%name)) for name in fileList]
    # 根据文件大小排序
    sorted_files = sorted(file_sizes, key=lambda x: x[1], reverse=True)
    return sorted_files, sizes

class GetRadarQPEDataSetAndCrop:
    def __init__(self, radarRoot, qpeRoot, trainListRoot, trainListPrefix, trainListPostfix,epoch,yearList):
        # self.radarCombineRoot = radarCombineRoot
        # self.crRoot = crRoot
        self.radarRoot = radarRoot
        self.qpeRoot = qpeRoot
        self.trainListRoot = trainListRoot
        self.epoch = epoch
        self.trainListPrefix = trainListPrefix
        self.trainListPostfix = trainListPostfix
        self.yearList = yearList

        self.trainSeriesList = []
        self.filesizeList = []
        for year in self.yearList:
            directory = 'E:/外推数据/swan/zhou_CR/%d/'%year
            self.trainSeries = []
            tmp = []
            self.filesize = []
            path = os.path.join(self.trainListRoot, '%s%d%s'%(self.trainListPrefix, year, trainListPostfix))
            with open(path, 'r') as f:
                lines = f.readlines()
                for line in lines:
                    tmp.append(line.rstrip('\n').split(',')[0][18:30])
            self.trainSeries = tmp
            # sorted_files,file_sizes = sort_files_by_size(directory, tmp)

            # for k in range(len(sorted_files) // 7):
            #     self.trainSeries.append(sorted_files[k][0])
            # for k in range(len(sorted_files)):
            #     if sorted_files[k][0] == '202204111306':
            #         print(sorted_files[k][0])
            #         print(k)
            # print(len(self.trainSeries))
            # maxSize = sorted_files[0][1]
            # self.filesize = np.array(file_sizes) / maxSize
            # self.filesizeList.append(self.filesize)
            self.trainSeriesList.append(self.trainSeries)

        # self.dem = tifffile.imread('dem_97-112_25-scale.tif')[192:832,562-200:562-200+800] #原版的200-1700
        # self.dem = self.dem.astype(float)
        # maxDem = np.max(self.dem) #归一化
        # self.dem /= maxDem
        # self.dem = np.expand_dims(self.dem,0)

        self.radarChannel = [3,5,7]#[1,3,5,7,9]
        self.inputRadar = None
        self.goldRadar = None
        # self.residualRadar = None
        self.conFlag = True
        self.conThrev = 0.97#0.985
        self.threv = 30./ 50.
        self.sumThrev = 0

        self.yearID = 0
        self.ind = -1
        self.firstName = ''

    def __len__(self):
        return self.epoch

    def len(self):
        return self.epoch

    def __getitem__(self, hehe):
        self.conFlag = True
        # if self.goldRadar is not None :
            # print(torch.sum(self.goldRadar[:, 5, :]>0.1))
        # if (np.random.rand() < self.conThrev and self.inputRadar is not None) \
        #     and (self.goldRadar is not None and torch.sum(self.goldRadar[:, 5, :]>0.1) >200):
        #     # print(torch.mean(self.goldRadar[:, 5, :]))
        #     return self.inputRadar,  self.goldRadar
        #else:
        # if self.goldRadar is not None:
        #     sizeRatio = self.filesizeList[self.yearID][self.ind]
        #     if sizeRatio < 0.5:
        #         self.conThrev = 0.5
        #     elif sizeRatio < 0.7:
        #         self.conThrev = 0.7
        #     else:
        #         self.conThrev = 0.985
            # if self.sumThrev > 600000:
            #     self.conThrev = 0.985
            # elif self.sumThrev > 400000:
            #     self.conThrev = 0.975
            # elif self.sumThrev > 200000:
            #     self.conThrev = 0.96
            # else:# self.sumThrev < 100000:
            #     self.conThrev = 0.9
        # else:
        #     self.conThrev = 0.95

        if np.random.rand() < self.conThrev and self.inputRadar is not None:
            return self.inputRadar, self.goldRadar #, self.residualRadar#,self.residualQPE
        else:
            # if self.ind >= len(self.trainSeriesList[self.yearID]) -1:
            #     if self.yearID == len(self.trainSeriesList)-1:
            #         self.yearID = 0
            #         self.ind = 0
            #     else:
            #         self.yearID += 1
            #         self.ind = 0
            # else:
            #     self.ind +=1
            # self.ind = 7
            self.yearID = np.random.randint(len(self.trainSeriesList))
            self.ind = np.random.randint(len(self.trainSeriesList[self.yearID]))
            # self.ind = np.random.randint(307, 308)  #
            # print(self.yearID, self.ind)

            self.radarYearDir = os.path.join(self.radarRoot, str(self.yearList[self.yearID]))
            # self.crYearDir = os.path.join(self.crRoot, str(self.yearList[yearID]))
            # self.combineYearDir = os.path.join(self.radarCombineRoot, str(self.yearList[yearID]))
            # self.qpeYearDir = os.path.join(self.qpeRoot, str(self.yearList[self.yearID]))
            beginTimeStr = self.trainSeriesList[self.yearID][self.ind]
            # print(beginTimeStr)
            dt = datetime.datetime.strptime(beginTimeStr, '%Y%m%d%H%M')
            #check 30 sample sequence

            for k in range(30):
                curDt = dt + datetime.timedelta(minutes=6*k)
                curDt = curDt.strftime("%Y%m%d%H%M")

                radarFile = os.path.join(self.radarYearDir,
                                         'Z_OTHE_RADAMOSAIC_%s' % (curDt)
                                         + '00.bin.bz2')
                if not os.path.exists(radarFile):
                    print(self.firstName)
                    return self.inputRadar, self.goldRadar#, self.residualRadar

            self.firstName = os.path.join(self.radarYearDir,
                                         'Z_OTHE_RADAMOSAIC_%s' % (dt.strftime("%Y%m%d%H%M"))
                                         + '00.bin.bz2')
            print(self.firstName)
            # self.inputRadar = np.zeros((10, 3, 640,800), dtype = np.float32)
            self.inputRadar = np.zeros((10, 3, 640, 640), dtype=np.float32)
            self.goldRadar = np.zeros((20, 3, 640,640), dtype=np.float32)
            # self.inputQPE = np.zeros((10, 1, 896, 1024), dtype=np.float32)
            # self.goldQPE = np.zeros((10, 1, 896,1024), dtype=np.float32)
            for k in range(10):
                curDt = dt + datetime.timedelta(minutes=6*k)
                curDt = curDt.strftime("%Y%m%d%H%M")

                radarFile = os.path.join(self.radarYearDir,
                                         'Z_OTHE_RADAMOSAIC_%s' % (curDt)
                                         + '00.bin.bz2')
                curRadar = read_bin_3d_radar(radarFile, channel=self.radarChannel)[:,192:832, 642:642+640] # 200:1700]
                curRadar = curRadar.astype(float) / 50. #uint8，没有负数
                # curRadar = read_bin_3d_radar(radarFile, channel=[5])[:, 192:832,
                #            562 - 200:562 - 200 + 800]  # 200:1700]
                # curRadar = curRadar.astype(float) / 50.  # uint8，没有负数
                self.inputRadar[k, :, :] = curRadar  # 896,1024
                #
                # qpeFile = os.path.join(self.qpeYearDir,
                #                            'zhouQPE_%s' % (curDt)
                #                            + '.tif')

            for k in range(10,30):
                curDt = dt + datetime.timedelta(minutes=6*k)
                curDt = curDt.strftime("%Y%m%d%H%M")
                radarFile = os.path.join(self.radarYearDir,
                                         'Z_OTHE_RADAMOSAIC_%s' % (curDt)
                                         + '00.bin.bz2')
                curRadar = read_bin_3d_radar(radarFile, channel=self.radarChannel)[:,192:832, 642:642+640]
                curRadar = curRadar.astype(float)  / 50. #uint8，没有负数
                # curRadar = read_bin_3d_radar(radarFile, channel=[5])[:, 192:832, 562:1362]
                # curRadar = curRadar.astype(float) / 50.  # uint8，没有负数
                self.goldRadar[k-10,:,:] = curRadar #896,1024

            self.residualRadar = self.goldRadar - self.inputRadar[-1, :]
            self.inputRadar = torch.from_numpy(self.inputRadar.copy()).float()
            self.goldRadar = torch.from_numpy(self.goldRadar.copy()).float()
            return self.inputRadar, self.goldRadar #, self.residualRadar#,self.residualQPE
#

# class GetRadarQPEDataSetAndCrop:
#     def __init__(self, radarRoot, qpeRoot, trainListRoot, trainListPrefix, trainListPostfix, epoch, yearList):
#         # self.radarCombineRoot = radarCombineRoot
#         # self.crRoot = crRoot
#         self.radarRoot = radarRoot
#         self.qpeRoot = qpeRoot
#         self.trainListRoot = trainListRoot
#         self.epoch = epoch
#         self.trainListPrefix = trainListPrefix
#         self.trainListPostfix = trainListPostfix
#         self.yearList = yearList
#
#         self.trainSeriesList = []
#         self.filesizeList = []
#         for year in self.yearList:
#             directory = 'E:/外推数据/swan/zhou_Combine/%d/'%year
#             self.trainSeries = []
#             tmp = []
#             self.filesize = []
#             path = os.path.join(self.trainListRoot, '%s%d%s'%(self.trainListPrefix, year, trainListPostfix))
#             with open(path, 'r') as f:
#                 lines = f.readlines()
#                 for line in lines:
#                     tmp.append(line.rstrip('\n'))
#             sorted_files,file_sizes = sort_files_by_size(directory, tmp)
#
#             for k in range(len(sorted_files) // 3):
#                 self.trainSeries.append(sorted_files[k][0])
#
#             self.trainSeriesList.append(self.trainSeries)
#
#         # for year in self.yearList:
#         #     self.trainSeries = []
#         #     path = os.path.join(self.trainListRoot, '%s%d%s' % (self.trainListPrefix, year, trainListPostfix))
#         #     with open(path, 'r') as f:
#         #         lines = f.readlines()
#         #         for line in lines:
#         #             self.trainSeries.append(line.rstrip('\n'))
#
#             # self.trainSeriesList.append(self.trainSeries)
#
#         # self.dem = tifffile.imread('dem_97-112_25-scale.tif')[192:832, 562 - 200:562 - 200 + 800]  # 原版的200-1700
#         # self.dem = self.dem.astype(float)
#         # maxDem = np.max(self.dem)  # 归一化
#         # self.dem /= maxDem
#         # self.dem = np.expand_dims(self.dem, 0)
#
#         # self.radarChannel = [1, 3, 5, 7, 9]
#         self.inputRadar = None
#         self.goldRadar = None
#         # self.residualRadar = None
#         self.conFlag = True
#         self.conThrev = 0.98  # 0.985
#         self.threv = 30. / 50.
#         self.sumThrev = 0
#
#         self.yearID = 0
#         self.ind = -1
#
#     def __len__(self):
#         return self.epoch
#
#     def len(self):
#         return self.epoch
#
#     def __getitem__(self, hehe):
#         self.conFlag = True
#         # if self.goldRadar is not None :
#         # print(torch.sum(self.goldRadar[:, 5, :]>0.1))
#         # if (np.random.rand() < self.conThrev and self.inputRadar is not None) \
#         #     and (self.goldRadar is not None and torch.sum(self.goldRadar[:, 5, :]>0.1) >200):
#         #     # print(torch.mean(self.goldRadar[:, 5, :]))
#         #     return self.inputRadar,  self.goldRadar
#         # else:
#         # if self.goldRadar is not None:
#         #     sizeRatio = self.filesizeList[self.yearID][self.ind]
#         #     if sizeRatio < 0.5:
#         #         self.conThrev = 0.5
#         #     elif sizeRatio < 0.7:
#         #         self.conThrev = 0.7
#         #     else:
#         #         self.conThrev = 0.985
#         # if self.sumThrev > 600000:
#         #     self.conThrev = 0.985
#         # elif self.sumThrev > 400000:
#         #     self.conThrev = 0.975
#         # elif self.sumThrev > 200000:
#         #     self.conThrev = 0.96
#         # else:# self.sumThrev < 100000:
#         #     self.conThrev = 0.9
#         # else:
#         #     self.conThrev = 0.95
#
#         if np.random.rand() < self.conThrev and self.inputRadar is not None:
#             return self.inputRadar, self.goldRadar #, self.residualRadar  # ,self.residualQPE
#         else:
#             self.yearID = np.random.randint(len(self.trainSeriesList))
#             self.ind = np.random.randint(len(self.trainSeriesList[self.yearID]))
#             # self.ind = np.random.randint(307, 308)  #
#             print(self.yearID, self.ind)
#
#             self.radarYearDir = os.path.join(self.radarRoot, str(self.yearList[self.yearID]))
#             # self.crYearDir = os.path.join(self.crRoot, str(self.yearList[yearID]))
#             # self.combineYearDir = os.path.join(self.radarCombineRoot, str(self.yearList[yearID]))
#             # self.qpeYearDir = os.path.join(self.qpeRoot, str(self.yearList[self.yearID]))
#             beginTimeStr = self.trainSeriesList[self.yearID][self.ind]
#             dt = datetime.datetime.strptime(beginTimeStr, '%Y%m%d%H%M')
#             # check 30 sample sequence
#             for k in range(30):
#                 curDt = dt + datetime.timedelta(minutes=6 * k)
#                 curDt = curDt.strftime("%Y%m%d%H%M")
#
#                 radarFile = os.path.join(self.radarYearDir,
#                                          'zhouCombine_%s' % (curDt)
#                              + '.tif')
#                 if not os.path.exists(radarFile):
#                     return self.inputRadar, self.goldRadar#, self.residualRadar
#             # self.inputRadar = np.zeros((10, 3, 640,800), dtype = np.float32)
#             self.inputRadar = np.zeros((10, 1, 640, 640), dtype=np.float32)
#             self.goldRadar = np.zeros((20, 1, 640, 640), dtype=np.float32)
#             # self.inputQPE = np.zeros((10, 1, 896, 1024), dtype=np.float32)
#             # self.goldQPE = np.zeros((10, 1, 896,1024), dtype=np.float32)
#             for k in range(10):
#                 curDt = dt + datetime.timedelta(minutes=6 * k)
#                 curDt = curDt.strftime("%Y%m%d%H%M")
#
#                 radarFile = os.path.join(self.radarYearDir,
#                                          'zhouCombine_%s' % (curDt)
#                              + '.tif')
#                 curRadar = tifffile.imread(radarFile)[192:832, 642:642 + 640]
#                 curRadar = curRadar.astype(float) / 50.  # uint8，没有负数
#                 self.inputRadar[k, 0, :] = curRadar  # 896,1024
#
#             for k in range(10, 30):
#                 curDt = dt + datetime.timedelta(minutes=6 * k)
#                 curDt = curDt.strftime("%Y%m%d%H%M")
#                 radarFile = os.path.join(self.radarYearDir,
#                                          'zhouCombine_%s' % (curDt)
#                              + '.tif')
#                 curRadar = tifffile.imread(radarFile)[192:832, 642:642 + 640]
#                 curRadar = curRadar.astype(float) / 50.  # uint8，没有负数
#                 self.goldRadar[k - 10, 0, :] = curRadar  # 896,1024
#
#             # self.residualRadar = self.goldRadar - self.inputRadar[-1, :]
#             self.inputRadar = torch.from_numpy(self.inputRadar.copy()).float()
#             self.goldRadar = torch.from_numpy(self.goldRadar.copy()).float()
#
#             return self.inputRadar, self.goldRadar #, self.residualRadar

# class GetRadarQPEDataSetAndCropZ357:
#     def __init__(self, radarRoot, trainListRootStep3,trainListRootStep4,
#                  trainListPrefixStep3, trainListPostfixStep3,
#                  trainListPrefixStep4, trainListPostfixStep4,
#                  epoch,yearList):
#         # self.radarCombineRoot = radarCombineRoot
#         # self.crRoot = crRoot
#         self.radarRoot = radarRoot
#         self.trainListRootStep3 = trainListRootStep3
#         self.trainListRootStep4 = trainListRootStep4
#         self.epoch = epoch
#         self.trainListPrefixStep3 = trainListPrefixStep3
#         self.trainListPostfixStep3 = trainListPostfixStep3
#         self.trainListPrefixStep4 = trainListPrefixStep4
#         self.trainListPostfixStep4 = trainListPostfixStep4
#         self.yearList = yearList
#
#         self.trainSeriesListStep3 = []
#         self.trainSeriesListStep4 = []
#         for year in self.yearList:
#             self.trainSeriesStep3 = []
#             self.trainSeriesStep4 = []
#             pathStep3 = os.path.join(self.trainListRootStep3, '%s%d%s'%(
#                 self.trainListPrefixStep3, year, trainListPostfixStep3))
#             pathStep4 = os.path.join(self.trainListRootStep4, '%s%d%s' % (
#                 self.trainListPrefixStep4, year, trainListPostfixStep4))
#             with open(pathStep3, 'r') as f:
#                 lines = f.readlines()
#                 for line in lines:
#                     tmp = line.strip().split(',')
#                     if float(tmp[2]) > 0.14:
#                         self.trainSeriesStep3.append(tmp[0][18:30])
#
#             self.trainSeriesListStep3.append(self.trainSeriesStep3)
#
#             with open(pathStep4, 'r') as f:
#                 lines = f.readlines()
#                 for line in lines:
#                     self.trainSeriesStep4.append(line.rstrip('\n').split(',')[0][18:30])
#
#             self.trainSeriesListStep4.append(self.trainSeriesStep4)
#
#         self.radarChannel = [3,5,7]#[1,3,5,7,9]
#         self.inputRadar = None
#         self.goldRadar = None
#         # self.residualRadar = None
#         self.step4Flag = False
#         self.threvFlag4 = 0.97#0.985 #要改的地方
#         self.threvFlag4to3 = 0.25  # 0.985 #要改的地方
#
#         self.yearID = 0
#         self.ind = -1
#         self.firstName = ''
#
#     def __len__(self):
#         return self.epoch
#
#     def len(self):
#         return self.epoch
#
#     def __getitem__(self, hehe):
#         if not self.step4Flag: #必须换新数据
#             if np.random.rand() < self.threvFlag4to3: #还是step3
#                 self.yearID = np.random.randint(len(self.trainSeriesListStep3))
#                 self.ind = np.random.randint(len(self.trainSeriesListStep3[self.yearID]))
#                 beginTimeStr = self.trainSeriesListStep3[self.yearID][self.ind]
#                 self.step4Flag = False
#                 print('step3')
#                 return self.mygetitem(beginTimeStr)
#             else: #换step4
#                 self.yearID = np.random.randint(len(self.trainSeriesListStep4))
#                 self.ind = np.random.randint(len(self.trainSeriesListStep4[self.yearID]))
#                 beginTimeStr = self.trainSeriesListStep4[self.yearID][self.ind]
#                 self.step4Flag = True
#                 print('step4')
#                 return self.mygetitem(beginTimeStr)
#         else: #上一个是step4
#             if np.random.rand() < self.threvFlag4 and self.inputRadar is not None:#继续用
#                 return self.inputRadar, self.goldRadar  # , self.residualRadar
#             else: #换别的
#                 if np.random.rand() < self.threvFlag4to3:  # 用step3
#                     self.yearID = np.random.randint(len(self.trainSeriesListStep3))
#                     self.ind = np.random.randint(len(self.trainSeriesListStep3[self.yearID]))
#                     beginTimeStr = self.trainSeriesListStep3[self.yearID][self.ind]
#                     self.step4Flag = False
#                     print('step3')
#                     return self.mygetitem(beginTimeStr)
#                 else: #用step4
#                     self.yearID = np.random.randint(len(self.trainSeriesListStep4))
#                     self.ind = np.random.randint(len(self.trainSeriesListStep4[self.yearID]))
#                     beginTimeStr = self.trainSeriesListStep4[self.yearID][self.ind]
#                     self.step4Flag = True
#                     print('step4')
#                     return self.mygetitem(beginTimeStr)
#
#     def mygetitem(self,beginTimeStr):
#         # print(beginTimeStr)
#         dt = datetime.datetime.strptime(beginTimeStr, '%Y%m%d%H%M')
#
#         self.firstName =  dt.strftime("%Y%m%d%H%M")
#         print(self.firstName)
#         for k in range(40):
#             curDt = dt + datetime.timedelta(minutes=6*k)
#             curDt = curDt.strftime("%Y%m%d%H%M")
#             radarFile = os.path.join(self.radarRoot, '%d_z%d' % (self.yearList[self.yearID], self.radarChannel[0]),
#                                      '%s' % (curDt)
#                                      + '_z%d.tif' % (self.radarChannel[0]))
#             if not os.path.exists(radarFile):
#                 return self.inputRadar, self.goldRadar
#         # self.inputRadar = np.zeros((10, 3, 640,800), dtype = np.float32)
#         self.inputRadar = np.zeros((20, 3, 640, 640), dtype=np.float32)
#         self.goldRadar = np.zeros((20, 3, 640,640), dtype=np.float32)
#         # self.inputQPE = np.zeros((10, 1, 896, 1024), dtype=np.float32)
#         # self.goldQPE = np.zeros((10, 1, 896,1024), dtype=np.float32)
#         for k in range(20):
#             curDt = dt + datetime.timedelta(minutes=6*k)
#             curDt = curDt.strftime("%Y%m%d%H%M")
#             for cc in range(len(self.radarChannel)):
#                 ch = self.radarChannel[cc]
#                 radarFile = os.path.join(self.radarRoot, '%d_z%d'%(self.yearList[self.yearID], ch),
#                                          '%s' % (curDt)
#                                          + '_z%d.tif'%(ch))
#                 curRadar = tifffile.imread(radarFile)[80:720, 80:720] # 200:1700]
#                 curRadar = curRadar.astype(float) / 50. #uint8，没有负数
#                 self.inputRadar[k, cc, :] = curRadar
#
#         for k in range(20,40):
#             curDt = dt + datetime.timedelta(minutes=6*k)
#             curDt = curDt.strftime("%Y%m%d%H%M")
#             for cc in range(len(self.radarChannel)):
#                 ch = self.radarChannel[cc]
#                 radarFile = os.path.join(self.radarRoot, '%d_z%d' % (self.yearList[self.yearID], ch),
#                                          '%s' % (curDt)
#                                          + '_z%d.tif' % (ch))
#                 curRadar = tifffile.imread(radarFile)[80:720, 80:720]  # 200:1700]
#                 curRadar = curRadar.astype(float) / 50.  # uint8，没有负数
#                 self.goldRadar[k-20,cc,:] = curRadar #896,1024
#
#         self.inputRadar = torch.from_numpy(self.inputRadar.copy()).float()
#         self.goldRadar = torch.from_numpy(self.goldRadar.copy()).float()
#         return self.inputRadar, self.goldRadar #, self.residualRadar

# class GetRadarQPEDataSetAndCropCR:
#     def __init__(self, radarRoot, trainListRootStep3,trainListRootStep4,
#                  trainListPrefixStep3, trainListPostfixStep3,
#                  trainListPrefixStep4, trainListPostfixStep4,
#                  epoch,yearList):
#         # self.radarCombineRoot = radarCombineRoot
#         # self.crRoot = crRoot
#         self.radarRoot = radarRoot
#         self.trainListRootStep3 = trainListRootStep3
#         self.trainListRootStep4 = trainListRootStep4
#         self.epoch = epoch
#         self.trainListPrefixStep3 = trainListPrefixStep3
#         self.trainListPostfixStep3 = trainListPostfixStep3
#         self.trainListPrefixStep4 = trainListPrefixStep4
#         self.trainListPostfixStep4 = trainListPostfixStep4
#         self.yearList = yearList
#
#         self.trainSeriesListStep3 = []
#         self.trainSeriesListStep4 = []
#         for year in self.yearList:
#             self.trainSeriesStep3 = []
#             self.trainSeriesStep4 = []
#             pathStep3 = os.path.join(self.trainListRootStep3, '%s%d%s'%(
#                 self.trainListPrefixStep3, year, trainListPostfixStep3))
#             pathStep4 = os.path.join(self.trainListRootStep4, '%s%d%s' % (
#                 self.trainListPrefixStep4, year, trainListPostfixStep4))
#             with open(pathStep3, 'r') as f:
#                 lines = f.readlines()
#                 for line in lines:
#                     self.trainSeriesStep3.append(line.strip().split(' ')[0])
#                     # tmp = line.strip().split(',')
#                     # if float(tmp[2]) > 0.14:
#                     #     if tmp[0][23] != '5' and tmp[0][23] != '4':
#                     #         self.trainSeriesStep3.append(tmp[0][18:30])
#
#             self.trainSeriesListStep3.append(self.trainSeriesStep3)
#
#             # with open(pathStep4, 'r') as f:
#             #     lines = f.readlines()
#             #     for line in lines:
#             #         if tmp[0][23] != '5' and tmp[0][23] != '4':
#             #             self.trainSeriesStep4.append(line.rstrip('\n').split(',')[0][18:30])
#             #
#             # self.trainSeriesListStep4.append(self.trainSeriesStep4)
#
#         self.trainSeriesListStep4 = self.trainSeriesListStep3
#         self.inputRadar = None
#         self.goldRadar = None
#         # self.residualRadar = None
#         self.step4Flag = False
#         self.threvFlag4 = 0.80#0.985 #要改的地方
#         self.threvFlag4to3 = 0.25  # 0.985 #要改的地方
#
#         self.yearID = 0
#         self.ind = -1
#         self.firstName = ''
#
#     def __len__(self):
#         return self.epoch
#
#     def len(self):
#         return self.epoch
#
#     def __getitem__(self, hehe):
#         if not self.step4Flag: #必须换新数据
#             if np.random.rand() < self.threvFlag4to3: #还是step3
#                 self.yearID = np.random.randint(len(self.trainSeriesListStep3))
#                 self.ind = np.random.randint(len(self.trainSeriesListStep3[self.yearID]))
#                 beginTimeStr = self.trainSeriesListStep3[self.yearID][self.ind]
#                 self.step4Flag = False
#                 print('step3')
#                 return self.mygetitem(beginTimeStr)
#             else: #换step4
#                 self.yearID = np.random.randint(len(self.trainSeriesListStep4))
#                 self.ind = np.random.randint(len(self.trainSeriesListStep4[self.yearID]))
#                 beginTimeStr = self.trainSeriesListStep4[self.yearID][self.ind]
#                 self.step4Flag = True
#                 print('step4')
#                 return self.mygetitem(beginTimeStr)
#         else: #上一个是step4
#             if np.random.rand() < self.threvFlag4 and self.inputRadar is not None:#继续用
#                 return self.inputRadar, self.goldRadar  # , self.residualRadar
#             else: #换别的
#                 if np.random.rand() < self.threvFlag4to3:  # 用step3
#                     self.yearID = np.random.randint(len(self.trainSeriesListStep3))
#                     self.ind = np.random.randint(len(self.trainSeriesListStep3[self.yearID]))
#                     beginTimeStr = self.trainSeriesListStep3[self.yearID][self.ind]
#                     self.step4Flag = False
#                     print('step3')
#                     return self.mygetitem(beginTimeStr)
#                 else: #用step4
#                     self.yearID = np.random.randint(len(self.trainSeriesListStep4))
#                     self.ind = np.random.randint(len(self.trainSeriesListStep4[self.yearID]))
#                     beginTimeStr = self.trainSeriesListStep4[self.yearID][self.ind]
#                     self.step4Flag = True
#                     print('step4')
#                     return self.mygetitem(beginTimeStr)
#
#     def mygetitem(self,beginTimeStr):
#         # print(beginTimeStr)
#         dt = datetime.datetime.strptime(beginTimeStr, '%Y%m%d%H%M')
#
#         self.firstName =  dt.strftime("%Y%m%d%H%M")
#         print(self.firstName)
#         for k in range(40):
#             curDt = dt + datetime.timedelta(minutes=6*k)
#             curDt = curDt.strftime("%Y%m%d%H%M")
#             radarFile = os.path.join(self.radarRoot, '%d' % (self.yearList[self.yearID]),
#                                      'CR_%s' % (curDt)
#                                      + '.tif' )
#             if not os.path.exists(radarFile):
#                 return self.inputRadar, self.goldRadar
#         # self.inputRadar = np.zeros((20, 1, 640, 640), dtype=np.float32)
#         # self.goldRadar = np.zeros((20, 1, 640,640), dtype=np.float32)
#         self.inputRadar = np.zeros((20, 1, 480, 480), dtype=np.float32)
#         self.goldRadar = np.zeros((20, 1, 480, 480), dtype=np.float32)
#         self.radarYearDir = os.path.join(self.radarRoot, str(self.yearList[self.yearID]))
#         for k in range(20):
#             curDt = dt + datetime.timedelta(minutes=6 * k)
#             curDt = curDt.strftime("%Y%m%d%H%M")
#
#             radarFile = os.path.join(self.radarYearDir,
#                                      'CR_%s' % (curDt)
#                                      + '.tif')
#             curRadar = tifffile.imread(radarFile)[180:660, 740:1220]  # 100:900, 500:1300
#             curRadar = curRadar.astype(float) / 50.  # uint8，没有负数
#             self.inputRadar[k, :, :] = curRadar  # 896,1024
#
#         for k in range(20, 40):
#             curDt = dt + datetime.timedelta(minutes=6 * k)
#             curDt = curDt.strftime("%Y%m%d%H%M")
#             radarFile = os.path.join(self.radarYearDir,
#                                      'CR_%s' % (curDt)
#                                      + '.tif')
#             curRadar = tifffile.imread(radarFile)[180:660, 740:1220]
#             curRadar = curRadar.astype(float) / 50.  # uint8，没有负数
#             self.goldRadar[k - 20, :, :] = curRadar  # 896,1024
#
#         self.inputRadar = torch.from_numpy(self.inputRadar.copy()).float()
#         self.goldRadar = torch.from_numpy(self.goldRadar.copy()).float()
#         return self.inputRadar, self.goldRadar #, self.residualRadar

class GetRadarQPEDataSetAndCropCR:
    def __init__(self, radarRoot, trainListRootStep3,trainListRootStep4,
                 trainListPrefixStep3, trainListPostfixStep3,
                 trainListPrefixStep4, trainListPostfixStep4,
                 epoch,yearList):
        # self.radarCombineRoot = radarCombineRoot
        # self.crRoot = crRoot
        self.radarRoot = radarRoot
        self.trainListRootStep3 = trainListRootStep3
        self.trainListRootStep4 = trainListRootStep4
        self.epoch = epoch
        self.trainListPrefixStep3 = trainListPrefixStep3
        self.trainListPostfixStep3 = trainListPostfixStep3
        self.trainListPrefixStep4 = trainListPrefixStep4
        self.trainListPostfixStep4 = trainListPostfixStep4
        self.yearList = yearList

        self.trainSeriesListStep3 = []
        self.trainSeriesListStep4 = []
        for year in self.yearList:
            self.trainSeriesStep3 = []
            self.trainSeriesStep4 = []
            pathStep3 = os.path.join(self.trainListRootStep3, '%s%d%s'%(
                self.trainListPrefixStep3, year, trainListPostfixStep3))
            pathStep4 = os.path.join(self.trainListRootStep4, '%s%d%s' % (
                self.trainListPrefixStep4, year, trainListPostfixStep4))
            with open(pathStep3, 'r') as f:
                lines = f.readlines()
                for line in lines:
                    self.trainSeriesStep3.append(line.strip().split(' ')[0])
                    # tmp = line.strip().split(',')
                    # if float(tmp[2]) > 0.14:
                    #     if tmp[0][23] != '5' and tmp[0][23] != '4':
                    #         self.trainSeriesStep3.append(tmp[0][18:30])

            self.trainSeriesListStep3.append(self.trainSeriesStep3)

            # with open(pathStep4, 'r') as f:
            #     lines = f.readlines()
            #     for line in lines:
            #         if tmp[0][23] != '5' and tmp[0][23] != '4':
            #             self.trainSeriesStep4.append(line.rstrip('\n').split(',')[0][18:30])
            #
            # self.trainSeriesListStep4.append(self.trainSeriesStep4)

        self.trainSeriesListStep4 = self.trainSeriesListStep3
        self.inputRadar = None
        self.goldRadar = None
        # self.residualRadar = None
        self.step4Flag = False
        self.threvFlag4 = 0.80#0.985#0.985 #要改的地方
        self.threvFlag4to3 = 0.25  # 0.25 #要改的地方

        self.yearID = 0
        self.ind = -1
        self.firstName = ''

    def __len__(self):
        return self.epoch

    def len(self):
        return self.epoch

    def __getitem__(self, hehe):
        if not self.step4Flag: #必须换新数据
            if np.random.rand() < self.threvFlag4to3: #还是step3
                self.yearID = np.random.randint(len(self.trainSeriesListStep3))
                self.ind = np.random.randint(len(self.trainSeriesListStep3[self.yearID]))
                beginTimeStr = self.trainSeriesListStep3[self.yearID][self.ind]
                self.step4Flag = False
                print('step3')
                return self.mygetitem(beginTimeStr)
            else: #换step4
                self.yearID = np.random.randint(len(self.trainSeriesListStep4))
                self.ind = np.random.randint(len(self.trainSeriesListStep4[self.yearID]))
                beginTimeStr = self.trainSeriesListStep4[self.yearID][self.ind]
                self.step4Flag = True
                print('step4')
                return self.mygetitem(beginTimeStr)
        else: #上一个是step4
            if np.random.rand() < self.threvFlag4 and self.inputRadar is not None:#继续用
                return self.inputRadar, self.goldRadar  # , self.residualRadar
            else: #换别的
                if np.random.rand() < self.threvFlag4to3:  # 用step3
                    self.yearID = np.random.randint(len(self.trainSeriesListStep3))
                    self.ind = np.random.randint(len(self.trainSeriesListStep3[self.yearID]))
                    beginTimeStr = self.trainSeriesListStep3[self.yearID][self.ind]
                    self.step4Flag = False
                    print('step3')
                    return self.mygetitem(beginTimeStr)
                else: #用step4
                    self.yearID = np.random.randint(len(self.trainSeriesListStep4))
                    self.ind = np.random.randint(len(self.trainSeriesListStep4[self.yearID]))
                    beginTimeStr = self.trainSeriesListStep4[self.yearID][self.ind]
                    self.step4Flag = True
                    print('step4')
                    return self.mygetitem(beginTimeStr)

    def mygetitem(self,beginTimeStr):
        # print(beginTimeStr)
        dt = datetime.datetime.strptime(beginTimeStr, '%Y%m%d%H%M')
        addTime = np.random.randint(5)
        dt = dt + datetime.timedelta(minutes=6 * addTime)
        self.firstName =  dt.strftime("%Y%m%d%H%M")
        print(self.firstName)
        for k in range(40):
            curDt = dt + datetime.timedelta(minutes=6*k)
            curDt = curDt.strftime("%Y%m%d%H%M")
            radarFile = os.path.join(self.radarRoot, '%d' % (self.yearList[self.yearID]),
                                     'CR_%s' % (curDt)
                                     + '.tif' )
            if not os.path.exists(radarFile):
                return self.inputRadar, self.goldRadar
        self.inputRadar = np.zeros((10, 1, 480, 480), dtype=np.float32)
        self.goldRadar = np.zeros((10, 1, 480,480), dtype=np.float32)
        self.radarYearDir = os.path.join(self.radarRoot, str(self.yearList[self.yearID]))
        for k in range(10):
            curDt = dt + datetime.timedelta(minutes=12 * k)
            curDt = curDt.strftime("%Y%m%d%H%M")

            radarFile = os.path.join(self.radarYearDir,
                                     'CR_%s' % (curDt)
                                     + '.tif')
            curRadar = tifffile.imread(radarFile)[180:660, 740:1220]  # 100:900, 500:1300
            # curRadar[curRadar<15] = 0
            curRadar = curRadar.astype(float) / 50.  # uint8，没有负数
            self.inputRadar[k, :, :] = curRadar  # 896,1024

        for k in range(10, 20):
            curDt = dt + datetime.timedelta(minutes=12 * k)
            curDt = curDt.strftime("%Y%m%d%H%M")
            radarFile = os.path.join(self.radarYearDir,
                                     'CR_%s' % (curDt)
                                     + '.tif')
            curRadar = tifffile.imread(radarFile)[180:660, 740:1220]
            # curRadar[curRadar < 15] = 0
            curRadar = curRadar.astype(float) / 50.  # uint8，没有负数
            self.goldRadar[k - 10, :, :] = curRadar  # 896,1024

        self.inputRadar = torch.from_numpy(self.inputRadar.copy()).float()
        self.goldRadar = torch.from_numpy(self.goldRadar.copy()).float()
        # jiao1 = (self.inputRadar[-1,:]>0.5) * (self.goldRadar[-1,:]>0.5)
        # jiao2 = (self.inputRadar[-1,:]>0.5) + (self.goldRadar[-1,:]>0.5)
        # thr = torch.sum(jiao1) / (torch.sum(jiao2)+0.0001)
        # if thr < 0.2:
        #     print('torch.sum(jiao1> 0.5) / torch.sum(jiao2> 0.5) :', thr)
        #     self.step4Flag = False
        return self.inputRadar, self.goldRadar #, self.residualRadar