import numpy as np
import torch
import torch.nn as nn
from torch.nn import functional as F
from torch.nn.utils.parametrizations import spectral_norm
from torch.nn.modules.pixelshuffle import PixelUnshuffle


def weights_init_normal(m):
    classname = m.__class__.__name__
    if classname.find("Conv3d") != -1:
        torch.nn.init.normal_(m.weight.data, 0.0, 0.02)
    elif classname.find("Conv2d") != -1:
        torch.nn.init.normal_(m.weight.data, 0.0, 0.02)
    elif classname.find("InstanceNorm2d") != -1:
        torch.nn.init.normal_(m.weight.data, 1.0, 0.02)
        torch.nn.init.constant_(m.bias.data, 0.0)
    elif classname.find("BatchNorm3d") != -1:
        torch.nn.init.normal_(m.weight.data, 1.0, 0.02)
        torch.nn.init.constant_(m.bias.data, 0.0)

def get_conv_layer(conv_type: str = "standard") -> torch.nn.Module:
    if conv_type == "2d":
        conv_layer = torch.nn.Conv2d
    elif conv_type == "3d":
        conv_layer = torch.nn.Conv3d
    else:
        raise ValueError(f"{conv_type} is not a recognized Conv method")
    return conv_layer

class DBlock(torch.nn.Module):
    def __init__(
        self,
        input_channels: int = 12,
        output_channels: int = 12,
        conv_type: str = "3d",
        first_relu: bool = True,
        keep_same_output: bool = False,
    ):
        """
        D and 3D Block from Skillful Nowcasting, see https://arxiv.org/pdf/2104.00954.pdf
        Args:
            input_channels: Number of input channels
            output_channels: Number of output channels
            conv_type: Convolution type, see satflow/models/utils.py for options
            first_relu: Whether to have an ReLU before the first 3x3 convolution
            keep_same_output: Whether the output should have the same spatial dimensions as input, if False, downscales by 2
        """
        super().__init__()
        self.input_channels = input_channels
        self.output_channels = output_channels
        self.first_relu = first_relu
        self.keep_same_output = keep_same_output
        self.conv_type = conv_type
        convND = get_conv_layer(conv_type)
        if conv_type == "3d":
            # 3D Average pooling
            self.pooling = torch.nn.AvgPool3d(kernel_size=2, stride=2)
        else:
            self.pooling = torch.nn.AvgPool2d(kernel_size=2, stride=2)
        self.conv_1x1 = spectral_norm(
            convND(
                in_channels=input_channels,
                out_channels=output_channels,
                kernel_size=1,
            )
        )
        self.first_conv_3x3 = spectral_norm(
            convND(
                in_channels=input_channels,
                out_channels=output_channels,
                kernel_size=3,
                padding=1,
            )
        )
        self.last_conv_3x3 = spectral_norm(
            convND(
                in_channels=output_channels,
                out_channels=output_channels,
                kernel_size=3,
                padding=1,
                stride=1,
            )
        )
        # Downsample at end of 3x3
        self.relu = torch.nn.ReLU()
        # Concatenate to double final channels and keep reduced spatial extent

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        if self.input_channels != self.output_channels:
            x1 = self.conv_1x1(x)
            if not self.keep_same_output:
                x1 = self.pooling(x1)
        else:
            x1 = x

        if self.first_relu:
            x = self.relu(x)
        x = self.first_conv_3x3(x)
        x = self.relu(x)
        x = self.last_conv_3x3(x)

        if not self.keep_same_output:
            x = self.pooling(x)
        x = x1 + x  # Sum the outputs should be half spatial and double channels
        return x

class TemporalDiscriminator(torch.nn.Module):
    def __init__(
        self, input_channels, num_layers: int = 2, conv_type: str = "2d", **kwargs
    ):
        super().__init__()
        # input_channels = self.config["input_channels"]
        # num_layers = self.config["num_layers"]
        # conv_type = self.config["conv_type"]

        self.downsample = torch.nn.AvgPool3d(kernel_size=(1, 2, 2), stride=(1, 2, 2))
        # self.downsample = torch.nn.MaxPool3d(kernel_size=(1, 2, 2), stride=(1, 2, 2))
        self.space2depth = PixelUnshuffle(2)
        internal_chn = 24#48
        self.d1 = DBlock(
            input_channels=4 * input_channels,
            output_channels=internal_chn * input_channels,
            conv_type="3d",
            first_relu=False,
        )
        self.d2 = DBlock(
            input_channels=internal_chn * input_channels,
            output_channels=2 * internal_chn * input_channels,
            conv_type="3d",
        )
        self.intermediate_dblocks = torch.nn.ModuleList()
        for _ in range(num_layers):
            internal_chn *= 2
            self.intermediate_dblocks.append(
                DBlock(
                    input_channels=internal_chn * input_channels,
                    output_channels=2 * internal_chn * input_channels,
                    conv_type=conv_type,
                )
            )

        self.d_last = DBlock(
            input_channels=2 * internal_chn * input_channels,
            output_channels=2 * internal_chn * input_channels,
            keep_same_output=True,
            conv_type=conv_type,
        )

        self.fc = spectral_norm(torch.nn.Linear(2 * internal_chn * input_channels, 1))
        self.relu = torch.nn.ReLU()
        # self.bn = torch.nn.BatchNorm1d(2 * internal_chn * input_channels)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = self.downsample(x)

        x = self.space2depth(x)
        # Have to move time and channels
        x = torch.permute(x, dims=(0, 2, 1, 3, 4))
        # 2 residual 3D blocks to halve resolution if image, double number of channels and reduce
        # number of time steps
        x = self.d1(x)
        x = self.d2(x)
        # Convert back to T x C x H x W
        x = torch.permute(x, dims=(0, 2, 1, 3, 4))
        # Per Timestep part now, same as spatial discriminator
        representations = []
        for idx in range(x.size(1)):
            # Intermediate DBlocks
            # Three residual D Blocks to halve the resolution of the image and double
            # the number of channels.
            rep = x[:, idx, :, :, :]
            for d in self.intermediate_dblocks:
                rep = d(rep)
            # One more D Block without downsampling or increase number of channels
            rep = self.d_last(rep)

            rep = torch.sum(F.relu(rep), dim=[2, 3])
            # rep = self.bn(rep)
            rep = self.fc(rep)

            representations.append(rep)
        # The representations are summed together before the ReLU
        x = torch.stack(representations, dim=1)
        # Should be [Batch, N, 1]
        x = torch.sum(x, keepdim=True, dim=1)
        return x

class SpatialDiscriminator(torch.nn.Module):
    def __init__(
        self,
        input_channels: int = 5,
        num_timesteps: int = 10,
        num_layers: int = 2,
        conv_type: str = "2d",
        **kwargs
    ):
        super().__init__()
        self.num_timesteps = num_timesteps
        # First step is mean pooling 2x2 to reduce input by half
        # self.mean_pool = torch.nn.MaxPool2d(2) # Avg
        self.mean_pool = torch.nn.AvgPool2d(2)  # Avg
        self.space2depth = PixelUnshuffle(downscale_factor=2)
        internal_chn = 24
        self.d1 = DBlock(
            input_channels=4 * input_channels,
            output_channels=2 * internal_chn * input_channels,
            first_relu=False,
            conv_type=conv_type,
        )
        self.intermediate_dblocks = torch.nn.ModuleList()
        for _ in range(num_layers):
            internal_chn *= 2
            self.intermediate_dblocks.append(
                DBlock(
                    input_channels=internal_chn * input_channels,
                    output_channels=2 * internal_chn * input_channels,
                    conv_type=conv_type,
                )
            )
        self.d6 = DBlock(
            input_channels=2 * internal_chn * input_channels,
            output_channels=2 * internal_chn * input_channels,
            keep_same_output=True,
            conv_type=conv_type,
        )

        # Spectrally normalized linear layer for binary classification
        self.fc = spectral_norm(torch.nn.Linear(2 * internal_chn * input_channels, 1))
        self.relu = torch.nn.ReLU()
        # self.bn = torch.nn.BatchNorm1d(2 * internal_chn * input_channels)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # x should be the chosen 8 or so
        idxs = torch.randint(low=0, high=x.size()[1], size=(self.num_timesteps,))
        representations = []
        for idx in idxs:
            rep = self.mean_pool(x[:, idx, :, :, :])  # 128x128
            rep = self.space2depth(rep)  # 64x64x4
            rep = self.d1(rep)  # 32x32
            # Intermediate DBlocks
            for d in self.intermediate_dblocks:
                rep = d(rep)
            rep = self.d6(rep)  # 2x2
            rep = torch.sum(F.relu(rep), dim=[2, 3])
            # rep = self.bn(rep)
            rep = self.fc(rep)
            representations.append(rep)

        # The representations are summed together before the ReLU
        x = torch.stack(representations, dim=1)
        # Should be [Batch, N, 1]
        x = torch.sum(x, keepdim=True, dim=1)
        return x

class Discriminator(torch.nn.Module):
    def __init__(
        self,
        input_channels: int = 5,
        num_spatial_frames: int = 10,
        conv_type: str = "2d",
        **kwargs
    ):
        super().__init__()
        self.temporal_discriminator = TemporalDiscriminator(
            input_channels=input_channels
        )
        self.spatial_discriminator = SpatialDiscriminator(
            input_channels=input_channels, num_timesteps=num_spatial_frames
        )

    def load2(self, loadList):
        if loadList[0] is None:
            self.temporal_discriminator.apply(weights_init_normal)
        else:
            self.temporal_discriminator.load_state_dict(torch.load(loadList[0]))
        if loadList[1] is None:
            self.spatial_discriminator.apply(weights_init_normal)
        else:
            self.spatial_discriminator.load_state_dict(torch.load(loadList[1]))

    def save2(self, saveList):
        if saveList[0] is not None:
            torch.save(self.temporal_discriminator.state_dict(), saveList[0])
        if saveList[1] is not None:
            torch.save(self.spatial_discriminator.state_dict(), saveList[1])

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        spatial_loss = self.spatial_discriminator(x)
        temporal_loss = self.temporal_discriminator(x)
        return torch.cat([spatial_loss, temporal_loss], dim=1)


class QPEDiscriminator(nn.Module):
    def __init__(self):
        super(QPEDiscriminator, self).__init__()
        self.nFeat = 10
        self.output_shape = (1,1,1,1)
        wn = lambda x: torch.nn.utils.weight_norm(x)
        act = nn.LeakyReLU
        layer1 = [
            #wn(nn.Conv2d(1,self.nFeat,3,3//2)),
            (DBlock(10, self.nFeat, conv_type="2d")),
            act(inplace=True),
            nn.MaxPool2d(2, stride=2, padding=1),
        ]
        layer2 = [
            (DBlock(self.nFeat, self.nFeat*2, conv_type="2d")),
            # act(inplace=True),
            nn.MaxPool2d(2, stride=2, padding=0),
            (DBlock(self.nFeat*2, self.nFeat*2, conv_type="2d")),
            # act(inplace=True),
            nn.MaxPool2d(2, stride=2, padding=0),
            # nn.MaxPool2d(4, stride=4, padding=1),
            (DBlock(self.nFeat*2, self.nFeat, conv_type="2d")),
            # act(inplace=True),
            # nn.MaxPool2d(3, stride=2, padding=1),
            # (nn.Conv2d(self.nFeat, 1, 3, padding=3 // 2)),
        ]
        self.head = nn.Sequential(*layer1)
        self.body = nn.Sequential(*layer2)
        self._init_weight()


    def _init_weight(self):
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                nn.init.kaiming_normal_(m.weight)
            elif isinstance(m, nn.Linear):
                m.weight.data.normal(0, 0.01)
                m.bias.data.zero_()
            elif isinstance(m, nn.InstanceNorm2d):
                torch.nn.init.normal_(m.weight.data, 1.0, 0.02)
                torch.nn.init.constant_(m.bias.data, 0.0)
            elif isinstance(m, nn.InstanceNorm2d):
                nn.init.constant_(m.bias, 0.0)
                nn.init.normal_(m.weight, 1.0, 0.02)
            elif isinstance(m, nn.GroupNorm):
                torch.nn.init.normal_(m.weight.data, 1.0, 0.02)
                torch.nn.init.constant_(m.bias.data, 0.0)


    def forward(self, input):
        x = self.head(input[:,:,0,:,:])
        x = self.body(x)
        # res = 0
        # randList = np.random.randint(0, input.shape[1], 3)
        # for k in randList: #range(input.shape[1]): # time
        #     x = self.head(input[:,k,:])
        #     x = self.body(x)
        #     res += x
        return x#torch.sigmoid(res)

class RadarDiscriminator(nn.Module):
    def __init__(self):
        super(RadarDiscriminator, self).__init__()
        self.nFeat = 10
        self.output_shape = (1,1,1,1)
        wn = lambda x: torch.nn.utils.weight_norm(x)
        act = nn.LeakyReLU
        layer1 = [
            #wn(nn.Conv2d(1,self.nFeat,3,3//2)),
            (DBlock(5, self.nFeat)),
            # act(inplace=True),
            nn.MaxPool3d(kernel_size = (1,2,2), stride=(1,2,2), padding=0),
        ]
        layer2 = [
            (DBlock(self.nFeat, self.nFeat*2)),
            # act(inplace=True),
            nn.MaxPool3d(kernel_size = (1,2,2), stride=(1,2,2), padding=0),
            (DBlock(self.nFeat*2, self.nFeat*2)),
            # act(inplace=True),
            nn.MaxPool3d(kernel_size=(1, 2, 2), stride=(1, 2, 2), padding=0),
            # nn.MaxPool2d(4, stride=4, padding=1),
            (DBlock(self.nFeat*2, self.nFeat)),
            # act(inplace=True),
            # nn.MaxPool2d(3, stride=2, padding=1),
            # (nn.Conv2d(self.nFeat, 1, 3, padding=3 // 2)),
        ]
        self.head = nn.Sequential(*layer1)
        self.body = nn.Sequential(*layer2)
        self._init_weight()


    def _init_weight(self):
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                nn.init.kaiming_normal_(m.weight)
            elif isinstance(m, nn.Linear):
                m.weight.data.normal(0, 0.01)
                m.bias.data.zero_()
            # elif isinstance(m, nn.InstanceNorm2d):
            #     torch.nn.init.normal_(m.weight.data, 1.0, 0.02)
            #     torch.nn.init.constant_(m.bias.data, 0.0)
            elif isinstance(m, nn.InstanceNorm2d):
                nn.init.constant_(m.bias, 0.0)
                nn.init.normal_(m.weight, 1.0, 0.02)
            elif isinstance(m, nn.GroupNorm):
                torch.nn.init.normal_(m.weight.data, 1.0, 0.02)
                torch.nn.init.constant_(m.bias.data, 0.0)


    def forward(self, input):
        x = torch.permute(input[:,:,:5,:,:], dims=(0, 2, 1, 3, 4))  # 1 5 10 H W
        x = self.head(x)
        x = self.body(x)
        # res = 0
        # randList = np.random.randint(0, input.shape[1], 3)
        # for k in randList: #range(input.shape[1]): # time
        #     x = self.head(input[:,k,:])
        #     x = self.body(x)
        #     res += x
        return x#torch.sigmoid(res)