# 评估指标MSE、SSIM、POD、FAR、CSI
import numpy as np
# import meteva.method as mem
import pandas as pd
# from skimage.metrics import structural_similarity as ssim_compare

# 计算一张图片
def csi_pod_far(pred, real, threshold):

    # 根据阈值生成二进制分类结果
    binary_real = (real >= threshold).astype(int)
    binary_pred = (pred >= threshold).astype(int)

    # 计算混淆矩阵的元素
    hits = np.sum((binary_pred == 1) & (binary_real == 1))  # 命中点
    misses = np.sum((binary_pred == 0) & (binary_real == 1))  # 漏报点
    false_alarms = np.sum((binary_pred == 1) & (binary_real == 0))  # 空报点

    # 计算评价指标
    if hits + misses + false_alarms == 0:
        csi = 0
    else:
        csi = hits / (hits + misses + false_alarms)

    if hits + misses == 0:
        pod = 0
    else:
        pod = hits / (hits + misses)

    if hits + false_alarms == 0:
        far = 0
    else:
        far = false_alarms / (hits + false_alarms)

    return csi, pod, far

# def qpf_evaluate(obs_frames, predict_frames):
#     # obs_frames, predict_frames [20, 360, 920]  , 0~75dBZ
#     thresholds = [20, 30, 40]
#
#     T, H, W = obs_frames.shape
#
#     # 存储每个阈值下的所有评价指标
#     csi_far_pod_list = []
#     all_mse = 0
#     all_ssim = 0
#
#     for threshold in thresholds:
#         all_csi = 0
#         all_pod = 0
#         all_far = 0
#         for i in range(T):
#             obs_frame = obs_frames[i]
#             predict_frame = predict_frames[i]
#             csi, pod, far = csi_pod_far(obs_frame, predict_frame, threshold)
#             all_csi += csi
#             all_pod += pod
#             all_far += far
#         csi_far_pod_list.append([all_csi / T, all_pod / T, all_far / T])
#
#     csi_far_pod_np = np.array(csi_far_pod_list)
#
#     for i in range(T):
#         mse = mem.mse(obs_frame, predict_frame)
#         ssim = ssim_compare(obs_frame / 75., predict_frame / 75., multichannel=False, data_range=1.)
#         all_mse += mse
#         all_ssim += ssim
#
#     return csi_far_pod_np, all_mse / T, all_ssim / T

def csi_timeStep(obs_frames, predict_frames):
    # 反归一化
    obs_frames = obs_frames * 75
    predict_frames = predict_frames * 75
    # 负数置为0
    predict_frames[predict_frames < 0] = 0

    thresholds = [20, 30, 40]
    B, T, C, H, W = obs_frames.shape

    # 存储每个阈值下的所有评价指标
    all_timeStep_list = []

    for threshold in thresholds:
        timeStep_list = []
        for i in range(T):
            all_csi = 0
            for j in range(B):
                obs_frame = obs_frames[j, i, 0, :, :]
                predict_frame = predict_frames[j, i, 0, :, :]
                csi, _, _ = csi_pod_far(obs_frame, predict_frame, threshold)
                all_csi += csi
            timeStep_list.append(all_csi / B)
        all_timeStep_list.append(timeStep_list)

    all_timeStep_list = np.array(all_timeStep_list)

    return all_timeStep_list


# if __name__ == '__main__':
#     # obs_frames = np.random.randint(0, 70, [10, 256, 256])
#     # predict_frames = np.random.randint(0, 70, [10, 256, 256])
#     # csi, mse, ssim = qpf_evaluate(obs_frames, predict_frames)
#     # print(csi)
#     # print(mse)
#     # print(ssim)
#     obs_frames = np.random.randint(0, 70, [2, 20, 1, 256, 256])
#     predict_frames = np.random.randint(0, 30, [2, 20, 1, 256, 256])
#     a = csi_timeStep(obs_frames, predict_frames)
#     print(a)
#     a = pd.DataFrame(a).T
#     a.columns = ['20dBz', '30dBz', '40dBz']  # 设置列名
#     a.index = np.arange(1, 21)  # 设置行名
#     print(a)

