import matplotlib
import matplotlib.pyplot as plt
from matplotlib import colors
import cartopy.crs as ccrs
import numpy as np
from matplotlib.colors import LinearSegmentedColormap
import cv2

def plt_qpe_show(img,  saveName = None): #transposeFlag = False,
    # 可视化插值结果
    # 使用imshow函数显示网格数据
    # 自定义颜色映射
    predImg_arr = (np.where(img < 0, 0, img))#.astype(np.uint8)
    predImg_arr = predImg_arr[::-1,:]
    # predImg_arr = np.transpose(predImg_arr)
    # if transposeFlag:
    #     predImg_arr = np.transpose(predImg_arr)
    my_color = [(1, 1, 1),
                (0.6, 1, 0.6),
                (0.1216, 0.6941, 0.1216),
                (0, 1, 1),
                (0, 0, 1),
                (1, 0, 1),
                (0.6, 0.2, 0),
                ]
    cmap_color = matplotlib.colors.LinearSegmentedColormap.from_list('custom', my_color)
    # bounds = [0, 0.1, 0.20, 0.35, 0.5, 0.75, 0.9, 1] # 值在某个区间内，显示某个颜色，如：0 ~ 0.1显示颜色（1，1，1），以此类推
    bounds = [0, 1, 1.5, 6.9, 14.9, 39.9, 49.9, 100]
    norm = colors.BoundaryNorm(bounds, cmap_color.N, clip=True)


    # X, Y = np.meshgrid(np.arange(103, 108, 0.01), np.arange(28, 33, 0.01))
    # 95-115,25-35  192:832, 562:562 + 800
    X, Y = np.meshgrid(np.arange(100.62, 108.62, 0.01), np.arange(26.92, 33.32, 0.01))  # 64:960, 450:1474
    fig = plt.figure(figsize=(12, 12))
    # fig = plt.figure()
    ax = fig.add_subplot(1, 1, 1, projection=ccrs.PlateCarree())
    ax.set_extent([97, 110, 25, 35], crs=ccrs.PlateCarree())  #95:115
    ax.coastlines(resolution='10m', linewidth=1)
    # ax.add_feature(ccrs.cartopy.feature.LAKES, alpha=0.5)
    # ax.add_feature(ccrs.cartopy.feature.RIVERS, linewidth=1, alpha=0.5)
    ax.add_feature(ccrs.cartopy.feature.BORDERS, linewidth=1, alpha=0.5)
    ax.add_feature(ccrs.cartopy.feature.STATES, linewidth=1, alpha=0.5)
    ax.gridlines(linestyle='--')

    # plt.contourf(X, Y, predImg_arr, norm = norm)
    plt.contourf(X, Y, predImg_arr, cmap=cmap_color, norm = norm, levels = bounds)
    if saveName is not None:
        plt.savefig(saveName,bbox_inches='tight')
    else:
        plt.imshow(predImg_arr, cmap=cmap_color, norm = norm)
        plt.show()

def plt_radar_show(img, saveName = None): #transposeFlag = False,
    predImg_arr = (np.where(img < 0, 0, img))  # .astype(np.uint8)
    predImg_arr = predImg_arr[::-1, :]
    # predImg_arr = np.transpose(predImg_arr)
    # if transposeFlag:
    #     predImg_arr = np.transpose(predImg_arr)
    my_color = ['#029005', '#FFFF03', '#E7C200', '#FF8F00',
              '#FE0000', '#D30104', '#C20000', '#FF00F4', '#AC91ED', '#9B00B9']
    cmap_color = LinearSegmentedColormap.from_list('custom_cmap', my_color)
    bounds = [20, 25, 30, 35, 40, 45, 50, 55, 60, 65, 70]
    norm = colors.BoundaryNorm(bounds, cmap_color.N, clip=True)

    X, Y = np.meshgrid(np.arange(102.4, 107.2, 0.01), np.arange(28.4, 33.2, 0.01))
    fig = plt.figure()
    ax = fig.add_subplot(1, 1, 1, projection=ccrs.PlateCarree())
    ax.set_extent([97, 110, 25, 35], crs=ccrs.PlateCarree()) #95, 115, 25, 35
    ax.coastlines(resolution='10m', linewidth=1)
    ax.add_feature(ccrs.cartopy.feature.BORDERS, linewidth=1, alpha=0.5)
    ax.add_feature(ccrs.cartopy.feature.STATES, linewidth=1, alpha=0.5)
    ax.gridlines(linestyle='--')
    #
    if predImg_arr.shape[0] != X.shape[0] or predImg_arr.shape[1] != Y.shape[1]:
        predImg_arr = cv2.resize(predImg_arr, (X.shape[1], X.shape[0]))
    plt.contourf(X, Y, predImg_arr, cmap=cmap_color, norm=norm, levels=bounds)
    if saveName is not None:
        plt.savefig(saveName,bbox_inches='tight')
    else:
        plt.imshow(predImg_arr, cmap=cmap_color, norm=norm)
        plt.show()
