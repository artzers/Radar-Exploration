from vis import vis_tool
import os, torch
from torch.utils.data import DataLoader
import numpy as np
from model.simvp import  *
import tifffile,datetime
# from sebiao import plt_radar_show
from computer_zhibiao import csi_pod_far
from read_binbz2 import read_bin_3d_radar
import datetime
from Util import RestoreNetImg
import tifffile
from model.phydnet import *
from model.UnetIncepDWRes.UnetIncepDWRes import UnetIncepDWRes
from model.wast import WaST
from model.predrnnv2 import PredRNNv2

import matplotlib
import matplotlib.pyplot as plt
from matplotlib import colors
import cartopy.crs as ccrs
import numpy as np
from matplotlib.colors import LinearSegmentedColormap

class GetRadarQPEDataSetAndCropZuotu:
    def __init__(self, radarRoot, trainListRootStep3,trainListRootStep4,
                 trainListPrefixStep3, trainListPostfixStep3,
                 trainListPrefixStep4, trainListPostfixStep4,
                 epoch,yearList):
        # self.radarCombineRoot = radarCombineRoot
        # self.crRoot = crRoot
        self.radarRoot = radarRoot
        self.trainListRootStep3 = trainListRootStep3
        self.trainListRootStep4 = trainListRootStep4
        self.epoch = epoch
        self.trainListPrefixStep3 = trainListPrefixStep3
        self.trainListPostfixStep3 = trainListPostfixStep3
        self.trainListPrefixStep4 = trainListPrefixStep4
        self.trainListPostfixStep4 = trainListPostfixStep4
        self.yearList = yearList

        self.trainSeriesListStep3 = []
        self.trainSeriesListStep4 = []
        for year in self.yearList:
            self.trainSeriesStep3 = []
            self.trainSeriesStep4 = []
            pathStep3 = os.path.join(self.trainListRootStep3, '%s%d%s'%(
                self.trainListPrefixStep3, year, trainListPostfixStep3))
            pathStep4 = os.path.join(self.trainListRootStep4, '%s%d%s' % (
                self.trainListPrefixStep4, year, trainListPostfixStep4))
            with open(pathStep3, 'r') as f:
                lines = f.readlines()
                for line in lines:
                    tmp = line.strip().split(' ')
                    if float(tmp[1]) > 0.16:
                        self.trainSeriesStep3.append(tmp[0]) #[18:30]

            self.trainSeriesListStep3.append(self.trainSeriesStep3)

            with open(pathStep4, 'r') as f:
                lines = f.readlines()
                for line in lines:
                    tmp = line.strip().split(' ')
                    if float(tmp[1]) > 0.16:
                        self.trainSeriesStep4.append(tmp[0])

            self.trainSeriesListStep4.append(self.trainSeriesStep4)

        # self.radarChannel = [3,5,7]#[1,3,5,7,9]
        self.inputRadar = None
        self.goldRadar = None
        # self.residualRadar = None
        self.step4Flag = False
        self.threvFlag4 = 0.97#0.985 #要改的地方
        self.threvFlag4to3 = 0.25  # 0.985 #要改的地方

        self.yearID = 0
        self.ind = -1
        self.firstName = ''
        # self.CRnameList = []
        # with open('CRindexname.txt', 'r') as fp:
        #     lines = fp.readlines()
        #     for line in lines:
        #         self.CRnameList.append(line.strip())


    def __len__(self):
        return self.epoch

    def len(self):
        return len(self.CRnameList)-1

    def __getitem__(self, hehe):
        # if self.CRnameList[hehe][:4] == '2020':
        #     self.yearID = 0
        # if self.CRnameList[hehe][:4] == '2021':
        #     self.yearID = 1
        # if self.CRnameList[hehe][:4] == '2022':
        #     self.yearID = 2
        # return self.mygetitem(self.CRnameList[hehe])
        # self.yearID = np.random.randint(len(self.trainSeriesListStep4))
        # self.ind = np.random.randint(len(self.trainSeriesListStep4[self.yearID]))
        # beginTimeStr = self.trainSeriesListStep4[self.yearID][self.ind]
        # return self.mygetitem(beginTimeStr)
        validFlag = False
        beginTimeStr = ''
        while not validFlag:
            self.yearID = np.random.randint(len(self.trainSeriesListStep3))
            self.ind = np.random.randint(len(self.trainSeriesListStep3[self.yearID]))
            beginTimeStr = self.trainSeriesListStep3[self.yearID][self.ind]
            dt = datetime.datetime.strptime(beginTimeStr, '%Y%m%d%H%M')
            self.radarYearDir = os.path.join(self.radarRoot, str(self.yearList[self.yearID]))
            validFlag = True
            for k in range(20):
                curDt = dt + datetime.timedelta(minutes=12 * k)
                curDt = curDt.strftime("%Y%m%d%H%M")
                # radarFile = os.path.join(self.radarRoot, '%d_z%d' % (self.yearList[self.yearID], self.radarChannel[0]),
                #                          '%s' % (curDt)
                #                          + '_z%d.tif' % (self.radarChannel[0]))
                radarFile = os.path.join(self.radarYearDir,
                                         'CR_%s' % (curDt)
                                         + '.tif')
                curRadar = tifffile.imread(radarFile)[180:660, 740:1220]
                if not os.path.exists(radarFile):
                    validFlag = False
                    break

        return self.mygetitem(beginTimeStr)
        # if not self.step4Flag: #必须换新数据
        #     if np.random.rand() < self.threvFlag4to3: #还是step3
        #         self.yearID = np.random.randint(len(self.trainSeriesListStep3))
        #         self.ind = np.random.randint(len(self.trainSeriesListStep3[self.yearID]))
        #         beginTimeStr = self.trainSeriesListStep3[self.yearID][self.ind]
        #         self.step4Flag = False
        #         print('step3')
        #         return self.mygetitem(beginTimeStr)
        #     else: #换step4
        #         self.yearID = np.random.randint(len(self.trainSeriesListStep4))
        #         self.ind = np.random.randint(len(self.trainSeriesListStep4[self.yearID]))
        #         beginTimeStr = self.trainSeriesListStep4[self.yearID][self.ind]
        #         self.step4Flag = True
        #         print('step4')
        #         return self.mygetitem(beginTimeStr)
        # else: #上一个是step4
        #     if np.random.rand() < self.threvFlag4 and self.inputRadar is not None:#继续用
        #         return self.inputRadar, self.goldRadar  # , self.residualRadar
        #     else: #换别的
        #         if np.random.rand() < self.threvFlag4to3:  # 用step3
        #             self.yearID = np.random.randint(len(self.trainSeriesListStep3))
        #             self.ind = np.random.randint(len(self.trainSeriesListStep3[self.yearID]))
        #             beginTimeStr = self.trainSeriesListStep3[self.yearID][self.ind]
        #             self.step4Flag = False
        #             print('step3')
        #             return self.mygetitem(beginTimeStr)
        #         else: #用step4
        #             self.yearID = np.random.randint(len(self.trainSeriesListStep4))
        #             self.ind = np.random.randint(len(self.trainSeriesListStep4[self.yearID]))
        #             beginTimeStr = self.trainSeriesListStep4[self.yearID][self.ind]
        #             self.step4Flag = True
        #             print('step4')
        #             return self.mygetitem(beginTimeStr)

    def mygetitem(self,beginTimeStr):
        # print(beginTimeStr)
        dt = datetime.datetime.strptime(beginTimeStr, '%Y%m%d%H%M')
        self.firstName =  dt.strftime("%Y%m%d%H%M")
        print(self.firstName)
        # self.inputRadar = np.zeros((10, 3, 640,800), dtype = np.float32)
        self.inputRadar = np.zeros((10, 1, 480, 480), dtype=np.float32)
        self.goldRadar = np.zeros((10, 1, 480,480), dtype=np.float32)
        for k in range(10):
            curDt = dt + datetime.timedelta(minutes=12*k)
            curDt = curDt.strftime("%Y%m%d%H%M")
            radarFile = os.path.join(self.radarYearDir,
                                     'CR_%s' % (curDt)
                                     + '.tif')
            curRadar = tifffile.imread(radarFile)[180:660, 740:1220]
            curRadar = curRadar.astype(float) / 50.  # uint8，没有负数
            self.inputRadar[k, 0, :] = curRadar
            # for cc in range(len(self.radarChannel)):
            #     ch = self.radarChannel[cc]
                # radarFile = os.path.join(self.radarRoot, '%d_z%d'%(self.yearList[self.yearID], ch),
                #                          '%s' % (curDt)
                #                          + '_z%d.tif'%(ch))
                # curRadar = tifffile.imread(radarFile)[80:720, 80:720] # 200:1700]
                # radarFile = os.path.join(self.radarYearDir,
                #                          'CR_%s' % (curDt)
                #                          + '.tif')
                # curRadar = tifffile.imread(radarFile)[180:660, 740:1220]
                # curRadar = curRadar.astype(float) / 50. #uint8，没有负数
                # self.inputRadar[k, cc, :] = curRadar

        for k in range(10,20):
            curDt = dt + datetime.timedelta(minutes=12*k)
            curDt = curDt.strftime("%Y%m%d%H%M")
            radarFile = os.path.join(self.radarYearDir,
                                     'CR_%s' % (curDt)
                                     + '.tif')
            curRadar = tifffile.imread(radarFile)[180:660, 740:1220]
            curRadar = curRadar.astype(float) / 50.  # uint8，没有负数
            self.goldRadar[k-10, 0, :] = curRadar
            # for cc in range(len(self.radarChannel)):
            #     ch = self.radarChannel[cc]
            #     radarFile = os.path.join(self.radarRoot, '%d_z%d' % (self.yearList[self.yearID], ch),
            #                              '%s' % (curDt)
            #                              + '_z%d.tif' % (ch))
            #     curRadar = tifffile.imread(radarFile)[80:720, 80:720]  # 200:1700]
            #     curRadar = curRadar.astype(float) / 50.  # uint8，没有负数
            #     self.goldRadar[k-20,cc,:] = curRadar #896,1024

        self.inputRadar = torch.from_numpy(self.inputRadar.copy()).float()
        self.goldRadar = torch.from_numpy(self.goldRadar.copy()).float()
        return self.inputRadar, self.goldRadar, self.firstName



#要改的地方
#phydnet
# G = PhyDNet(device ='cuda')
#predrnnv2
G= PredRNNv2(device = 'cuda')
G.hparams.scheduled_sampling = 0
G.hparams.reverse_scheduled_sampling = 0
G.hparams.device='cuda'
#simvp
# G = SimVP(in_shape=[10, 1, 480, 480],
#                        hiddem=32, hid_T=256, N_T=8, N_S=2, model_type='incepu',
#                        drop_path=0.0).cuda()#.cpu()
#TAU
# G = SimVP(in_shape = [10, 1, 480, 480],
#             hiddem=32, hid_T=256, N_T=8,N_S = 2, model_type = 'tau',
#             drop_path = 0.0 ).cuda()#.cpu() # #TAU
#MS UnetIncepDWRes
# G = UnetIncepDWRes(n_channels = 3, n_classes = 3).cuda()
#wast
# G = WaST(device = 'cuda',in_shape = [10,1,480,480],encoder_dim=12, block_list=[2, 6, 2], drop_path_rate=0.25, mlp_ratio=2.)

#要改的地方
# G.load_state_dict(torch.load('./saved_models_phydnet_old_weight//phydnet_30000.pth', map_location=torch.device('cuda')))
G.load_state_dict(torch.load('./saved_models_predrnnv2_old_weight//predrnnv2_19500.pth', map_location=torch.device('cpu')))
# G.load_state_dict(torch.load('./saved_models_simvp_sichuan//simvp_8000.pth', map_location=torch.device('cuda')))
# G.load_state_dict(torch.load('./saved_models_simvp_old_weight//simvp_40500.pth', map_location=torch.device('cpu')))
# G.load_state_dict(torch.load('./saved_models_tau_sichuan//tau_8500.pth', map_location=torch.device('cuda')))
# G.load_state_dict(torch.load('./saved_models_tau_old_weight//tau_134500.pth', map_location=torch.device('cuda')))
# G.load_state_dict(torch.load('./saved_models_UnetIncepDWRes_sichuan//UnetIncepDWRes_7500.pth', map_location=torch.device('cuda')))
# G.load_state_dict(torch.load('./saved_models_wast_sichuan//wast_61000.pth', map_location=torch.device('cuda')))
# G.load_state_dict(torch.load('./saved_models//wast_80000.pth', map_location=torch.device('cpu')))
# G.load_state_dict(torch.load('./saved_models_wast_old_weight//wast_61500.pth', map_location=torch.device('cuda')))
# G = G.eval()

#这里开始用for循环随机数据50个

radarRoot = 'E:/外推数据/swan/zhou_CR'
trainListRootStep3 = './'
trainListPrefixStep3 = 'trainList_'
trainListPostfixStep3 = '_30_ratio.txt'
# trainListPostfixStep3 = '_30.txt'
trainListRootStep4 = trainListRootStep3
trainListPrefixStep4 = trainListPrefixStep3
trainListPostfixStep4 = trainListPostfixStep3

train_dataset = GetRadarQPEDataSetAndCropZuotu(radarRoot, trainListRootStep3,trainListRootStep4,
                 trainListPrefixStep3, trainListPostfixStep3,
                 trainListPrefixStep4, trainListPostfixStep4, 100,
                                              yearList=[2020, 2021, 2022])  # 2020, 2022

train_loader = DataLoader(train_dataset, batch_size=1, shuffle=False,num_workers=0)

count = -1
seriesNameList = []
calcCount = 99
CR10index = np.zeros((calcCount+1,15))
CR20index = np.zeros((calcCount+1,15))


for kk, (inputRadarQPE, goldRadarQPE, firstName) in enumerate(train_loader):  #
    count = count + 1
    print('count:',count)
    if count > calcCount:
        break
    inputRadarQPE = inputRadarQPE.cuda()#.cpu()#
    goldRadarQPE = goldRadarQPE.cuda()#.cpu()#
    #要改的地方
    with torch.no_grad(): #注意看应该是那个网络
        predRadarRes = G.training_step(inputRadarQPE, goldRadarQPE, globalStep=0)#predrnnv2
        # predRadarRes = G.train_forward(inputRadarQPE) #UnetIncepDWRes专用
        # predRadarRes = G(inputRadarQPE) #simvp,tau
        # predRadarRes, _ = G.training_step(inputRadarQPE, goldRadarQPE, min_teaching_ration=0, current_epoch=100)#phydnet
        # predRadarRes = G(inputRadarQPE) #wast

        pred= predRadarRes #inputRadarQPE[:, -1, :] + predRadarRes
        # pred= inputRadarQPE + predRadarRes
        output = pred[0,:].cpu().data.numpy()
        goldRadar = goldRadarQPE.cpu().data.numpy()[0,:]

        seriesNameList.append(firstName)

        # csi15, pod15, far15 = csi_pod_far(np.max(output[:10, :, 40:600, 40:600], 1),
        #                                   np.max(goldRadar[:10, :, 40:600, 40:600], 1), 15 / 50)
        # print('CR 3km 15: ', csi15, pod15, far15)
        # csi20, pod20, far20 = csi_pod_far(np.max(output[:10, :, 40:600, 40:600], 1),
        #                                   np.max(goldRadar[:10, :, 40:600, 40:600], 1), 20 / 50)
        # print('CR 3km 20: ', csi20, pod20, far20)
        # csi30, pod30, far30 = csi_pod_far(np.max(output[:10, :, 40:600, 40:600], 1),
        #                                   np.max(goldRadar[:10, :, 40:600, 40:600], 1), 30 / 50)
        # print('CR 3km 30: ', csi30, pod30, far30)
        # csi35, pod35, far35 = csi_pod_far(np.max(output[:10, :, 40:600, 40:600], 1),
        #                                   np.max(goldRadar[:10, :, 40:600, 40:600], 1), 35 / 50)
        # print('CR 3km 35: ', csi35, pod35, far35)
        # csi40, pod40, far40 = csi_pod_far(np.max(output[:10, :, 40:600, 40:600], 1),
        #                                   np.max(goldRadar[:10, :, 40:600, 40:600], 1), 40 / 50)
        # print('CR 3km 40: ', csi40, pod40, far40)

        # CR10index[count,:] = np.array([csi15, pod15, far15,csi20, pod20, far20,
        #                                csi30, pod30, far30, csi35, pod35, far35, csi40, pod40, far40])

        csi15, pod15, far15 = csi_pod_far(output,
                                          goldRadar, 15 / 50)
        print('CR 3km 15: ', csi15, pod15, far15)
        csi20, pod20, far20 = csi_pod_far(output,
                                          goldRadar, 20 / 50)
        print('CR 3km 20: ', csi20, pod20, far20)
        csi30, pod30, far30 = csi_pod_far(output,
                                          goldRadar, 30 / 50)
        print('CR 3km 30: ', csi30, pod30, far30)
        csi35, pod35, far35 = csi_pod_far(output,
                                          goldRadar, 35 / 50)
        print('CR 3km 35: ', csi35, pod35, far35)
        csi40, pod40, far40 = csi_pod_far(output,
                                          goldRadar, 40 / 50)
        print('CR 3km 40: ', csi40, pod40, far40)

        CR20index[count, :] = np.array([csi15, pod15, far15, csi20, pod20, far20,
                                        csi30, pod30, far30, csi35, pod35, far35, csi40, pod40, far40])
        print('current mean CSI POD FAR15: %.4f %.4f %.4f'%(np.mean(CR20index[:count+1, 0]),
                                                          np.mean(CR20index[:count+1, 1]),
                                                          np.mean(CR20index[:count+1, 2])))
        print('current mean CSI POD FAR20: %.4f %.4f %.4f' % (np.mean(CR20index[:count + 1, 3]),
                                                              np.mean(CR20index[:count + 1, 4]),
                                                              np.mean(CR20index[:count + 1, 5])))
        print('current mean CSI POD FAR30: %.4f %.4f %.4f' % (np.mean(CR20index[:count + 1, 6]),
                                                              np.mean(CR20index[:count + 1, 7]),
                                                              np.mean(CR20index[:count + 1, 8])))
        print('current mean CSI POD FAR35: %.4f %.4f %.4f' % (np.mean(CR20index[:count + 1, 9]),
                                                              np.mean(CR20index[:count + 1, 10]),
                                                              np.mean(CR20index[:count + 1, 11])))
        print('current mean CSI POD FAR40: %.4f %.4f %.4f' % (np.mean(CR20index[:count + 1, 12]),
                                                              np.mean(CR20index[:count + 1, 13]),
                                                              np.mean(CR20index[:count + 1, 14])))


with open('CRindexname.txt','w') as f:
    for k in range(calcCount):
        f.write(seriesNameList[k][0] +'\n')
# np.savetxt('CR10index.txt', CR10index, fmt='%.4f', delimiter=' ')
np.savetxt('CR20index.txt', CR20index, fmt='%.4f', delimiter=' ')
