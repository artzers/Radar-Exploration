import os, torch
import numpy as np
from torch.optim import lr_scheduler as lrs
from Util import RestoreNetImg
from My_loss import ZhouDDR
import itertools
import torch.autograd as autograd
from torch.nn import functional as F

from model.predrnnv2 import PredRNNv2
# from dgmr.dgmr import DGMR
from model.simvp import  *
from model.phydnet import *
from model.mmvp import *
from model.wast_modules import HighFocalFrequencyLoss
from model.wast import WaST
from model.UnetIncepDWRes import Mynet2, AllAttenModel
# from model.mmvp import *
from model.predrnnv2_model import *

torch.autograd.set_detect_anomaly(True)

logger = None
lowMean =0
lowStd = 0
highMean =0
highStd = 0
globalMax = 0

device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")

def get_style_loss(f1,f2):
    #same size
    B,c,h,w = f1.size()
    f1 = f1.view(B*c,  h * w)
    gram1 = torch.mm(f1, f1.t())

    f2 = f2.view(B*c, h * w)
    gram2 = torch.mm(f2, f2.t())
    layer_style_loss = torch.mean((gram1 - gram2) ** 2)
    return layer_style_loss

def loss_hinge_disc(score_generated, score_real):
    """Discriminator hinge loss."""
    l1 = F.relu(1.0 - score_real)
    loss = torch.mean(l1)
    l2 = F.relu(1.0 + score_generated)
    loss += torch.mean(l2)
    return loss


def loss_hinge_gen(score_generated):
    """Generator hinge loss."""
    loss = -torch.mean(score_generated)
    return loss

def weights_init_normal(m):
    classname = m.__class__.__name__
    if classname.find("Conv3d") != -1:
        torch.nn.init.normal_(m.weight.data, 0.0, 0.02)
    elif classname.find("Conv2d") != -1:
        torch.nn.init.normal_(m.weight.data, 0.0, 0.02)
    elif classname.find("InstanceNorm2d") != -1:
        torch.nn.init.normal_(m.weight.data, 1.0, 0.02)
        torch.nn.init.constant_(m.bias.data, 0.0)
    elif classname.find("BatchNorm3d") != -1:
        torch.nn.init.normal_(m.weight.data, 1.0, 0.02)
        torch.nn.init.constant_(m.bias.data, 0.0)


class Trainer:
    def __init__(self,
                 data_loader,
                 test_loader,
                 scheduler=lrs.StepLR,
                 dev='cuda:0', devid=0):
        self.dataLoader = data_loader
        self.testLoader = test_loader
        self.dev = dev
        self.cudaid = devid

        # 要改的地方
        #下面网络根据训练来选择，其他网络记得注释掉，还有后面的torch.save也要改名。
        #wast网络
        # self.hffl = HighFocalFrequencyLoss(loss_weight=0.001) #wast专用，其他去掉
        # self.G = WaST(device = 'cuda',in_shape = [10,1,480,480],encoder_dim=12, block_list=[2, 6, 2], drop_path_rate=0.25, mlp_ratio=2.)
        # G_lr = 0.0001  # 0.001
        # eta_min = 0.00005
        # self.criterion = ZhouDDR(l1flag=False).cuda(self.cudaid)#

        #phydnet
        # self.G = PhyDNet(device ='cuda')#.cuda(self.cudaid)
        # G_lr = 0.0001  # 0.001
        # eta_min = 0.00005
        # self.criterion = ZhouDDR(l1flag=False).cuda(self.cudaid)  # zhuyi
        # self.criterion = nn.MSELoss()#ZhouDDR(l1flag=False).cuda(self.cudaid)#

        # predrnnv2
        # self.G = PredRNNv2(device = 'cuda')
        # G_lr = 0.0001  # 0.001
        # eta_min = 0.00005
        # self.criterion = ZhouDDR(l1flag=False).cuda(self.cudaid)#zhuyi
        # self.criterion = nn.MSELoss()#ZhouDDR(l1flag=False).cuda(self.cudaid)#

        # simvp
        # self.G = SimVP(in_shape=[10, 1, 480, 480],
        #                hiddem=32, hid_T=256, N_T=8, N_S=2, model_type='incepu',
        #                drop_path=0.0).cuda(self.cudaid)  # simvp
        # G_lr = 0.0001  # 0.001
        # eta_min = 0.00001
        # # self.criterion = nn.MSELoss()#
        # self.criterion = ZhouDDR(l1flag=False).cuda(self.cudaid)#
        # self.G = SimVP(in_shape=[10, 1, 480, 480],
        #                hiddem=32, hid_T=256, N_T=8, N_S=2, model_type='incepu',
        #                drop_path=0.0).cuda(self.cudaid)  # simvp
        # G_lr = 0.0001  # 0.001
        # eta_min = 0.00005
        # # self.criterion = nn.MSELoss()
        # self.criterion = ZhouDDR(l1flag=False)  ##zhuyi!

        #TAU
        # self.G = SimVP(in_shape = [20,3,640,640],
        #     hiddem=32, hid_T=96, N_T=4,N_S = 2, model_type = 'tau',
        #     drop_path = 0.0 ).cuda(self.cudaid) #TAU
        # self.G = SimVP(in_shape = [10,1,480,480],
        #     hiddem=32, hid_T=256, N_T=8,N_S = 2, model_type = 'tau',
        #     drop_path = 0.0 ).cuda(self.cudaid) #TAU
        # self.G = Mynet2(in_shape=[10, 1, 480, 480],
        #                hiddem=32, hid_T=256, N_T=8, N_S=2, model_type='tau',
        #                drop_path=0.0).cuda(self.cudaid)  # TAU
        self.G = AllAttenModel(in_shape=[10, 1, 480, 480],
                       hid_S=64, hid_T=128, N_T=6, N_S=2, #model_type='incepu',drop_path=0.0
                       ).cuda(self.cudaid)
        G_lr = 0.0001  # 0.001
        eta_min = 0.00005
        self.criterion = ZhouDDR(l1flag=False).cuda(self.cudaid)#zhuyi

        # MMVp不能用
        # self.G = MMVP(device = 'cuda',in_shape = [20,3,640,640], aft_seq_length=20).cuda()
        # G_lr = 0.0001  # 0.001
        # eta_min = 0.00005

        #MS-DDN，UnetIncepDWRes
        # self.G = UnetIncepDWRes(n_channels = 3, n_classes = 3).cuda()
        # G_lr = 0.0001  # 0.001
        # eta_min = 0.00005
        # self.criterion = ZhouDDR(l1flag=False).cuda(self.cudaid)#

        #要改的地方
        # self.G.load_state_dict(torch.load('./saved_models_wast_old_weight//wast_61500.pth'))
        # self.G.load_state_dict(torch.load('./saved_models//phydnet_500.pth'))
        # self.G.load_state_dict(torch.load('./saved_models//predrnnv2_500.pth'))
        # self.G.load_state_dict(torch.load('./saved_models_simvp_old_weight//simvp_40500.pth'))
        # self.G.load_state_dict(torch.load('./saved_models//tau_1700.pth'))
        # self.G.load_state_dict(torch.load('./saved_models//nowcastnet_500.pth'))
        # self.G.load_state_dict(torch.load('./saved_models//UnetIncepDWRes_500.pth'))
        # self.G.load_state_dict(torch.load('./saved_models_tau_old_weight//tau_134500.pth'))
        # self.G.load_state_dict(torch.load('./saved_models//mynet_17000.pth'))


        # Optimizers

        self.optimizer_G = torch.optim.Adam(self.G.parameters(), lr=G_lr)
        # self.scheduler_G = scheduler(self.optimizer_G, step_size=10000, gamma=0.8, last_epoch=-1)#36000
        self.scheduler_G = lrs.CosineAnnealingLR(self.optimizer_G, T_max=50, eta_min=eta_min)


    def Train(self, turn=2):
        self.shot = -1
        torch.set_grad_enabled(True)
        torch.autograd.set_detect_anomaly(True)
        for t in range(turn):
            for kk, (rawRadarQPE, goldRadarQPE) in enumerate(self.dataLoader):  # ,residualQPE
                self.optimizer_G.zero_grad()
                # self.optimizer_D.zero_grad()
                # torch.cuda.empty_cache()
                self.shot = self.shot + 1

                inputRadarQPE = rawRadarQPE.cuda(self.cudaid)
                outputRadarQPE = goldRadarQPE.cuda(self.cudaid)
                # 要改的地方
                # phydnet专用
                # pred, _ = self.G.training_step(inputRadarQPE, outputRadarQPE,current_epoch=t+1)  # , predQPERes
                # G_loss1 = self.criterion(pred, outputRadarQPE)
                #predrnnv2
                # pred = self.G.MyTrain_Step(inputRadarQPE, outputRadarQPE, self.shot)
                # pred = self.G.training_step(inputRadarQPE, outputRadarQPE, self.shot)
                # G_loss1 = self.criterion(pred, outputRadarQPE)
                #simvp，tau，
                pred = self.G(inputRadarQPE)
                G_loss1 = self.criterion(pred, outputRadarQPE)
                #unetinceptdwres专用
                # pred = self.G.train_forward(inputRadarQPE)
                # G_loss1 = self.criterion(pred, outputRadarQPE)
                #mmvp专用,不能用
                # pred, G_loss1 = self.G.training_step(inputRadarQPE)
                #wast专用
                # pred = self.G(inputRadarQPE)
                # G_loss1 = self.criterion(pred, outputRadarQPE)#self.criterion(pred, outputRadarQPE, qpeFlag=False)
                # G_loss1 += self.hffl(pred, outputRadarQPE, reshape=True) #wast专用，其他去掉

                #下面不动，共用
                self.optimizer_G.zero_grad()
                G_loss1.backward()
                self.optimizer_G.step()

                self.scheduler_G.step()

                if self.shot % 5 == 0:

                    lr = self.scheduler_G.get_lr()[0]
                    # lossVal1 = float(G_loss1.cpu().data.numpy())
                    # lossVal2 = float(G_loss2.cpu().data.numpy())

                    print("\r[Epoch %d] [Batch %d] [LR:%f] [G loss: %f]" % (
                        t,
                        self.shot,
                        lr,
                        G_loss1.item()
                    )
                          )

                    # input9 = np.max(raw[0,9,:].data.numpy(), axis=0) #batch, time, channel
                    # input9 = RestoreNetImg(input9,0,1)
                    # logger.img('input9', input9)
                    input0 = rawRadarQPE[0, 0, 0, :].data.numpy()  # batch, time, channel+dem
                    input0 = RestoreNetImg(input0, 0, 1)
                    logger.img('0_input0', input0)
                    input4 = rawRadarQPE[0, 4, 0, :].data.numpy()  # batch, time, channel+dem
                    input4 = RestoreNetImg(input4, 0, 1)
                    logger.img('0_input4', input4)
                    input9 = rawRadarQPE[0, 9, 0, :].data.numpy()# batch, time, channel+dem
                    input9 = RestoreNetImg(input9, 0, 1)
                    logger.img('0_input9', input9)
                    # visThrev = 15 / 50

                    # gold0 = np.max(goldRadarQPE[0, 0, :, :].data.numpy(), axis=0)  # batch, time, channel
                    # # gold0[gold0 < visThrev] = 0
                    # gold0, max0, min0 = RestoreNetImg(gold0, 0, 1, returnFlag=True)
                    # # logger.img('A_gold_00', gold0)
                    # gold4 = np.max(goldRadarQPE[0, 4, :, :].data.numpy(), axis=0)  # batch, time, channel
                    # # gold4[gold4 < visThrev] = 0
                    # gold4, max4, min4 = RestoreNetImg(gold4, 0, 1, returnFlag=True)
                    # # logger.img('B_gold_04', gold4)
                    # gold9 = np.max(goldRadarQPE[0, 9, :, :].data.numpy(), axis=0)  # batch, time, channel
                    # # gold9[gold9 < visThrev] = 0
                    # gold9, max9, min9 = RestoreNetImg(gold9, 0, 1, returnFlag=True)
                    # # logger.img('C_gold009', gold9)

                    # output0 = np.max(pred[0, 0, :, :].cpu().data.numpy(), axis=0)  # batch, time, channel+dem
                    # # output0[output0 < visThrev] = 0
                    # output0 = RestoreNetImg(output0, 0, 1, maxVal=max0, minVal=min0)
                    # logger.img('D_output_00', output0)
                    # output4 = np.max(pred[0, 4, :, :].cpu().data.numpy(), axis=0)  # batch, time, channel+dem
                    # # output4[output4 < visThrev] = 0
                    # output4 = RestoreNetImg(output4, 0, 1, maxVal=max4, minVal=min4)
                    # logger.img('E_output_04', output4)
                    # output9 = np.max(pred[0, 9, :, :].cpu().data.numpy(), axis=0)  # batch, time, channel+dem
                    # # output9[output9 < visThrev] = 0
                    # output9 = RestoreNetImg(output9, 0, 1, maxVal=max9, minVal=min9)
                    # logger.img('F_output_09', output9)

                    gold0 = goldRadarQPE[0, 0, 0, :].data.numpy()  # batch, time, channel
                    # gold0[gold0 < visThrev] = 0
                    gold0,max0, min0 = RestoreNetImg(gold0, 0, 1, returnFlag=True)
                    # gold0 = RestoreNetImg(gold0, 0, 1, maxVal=max0, minVal=min0)
                    logger.img('G_gold3KM00_2', gold0)
                    gold4 = goldRadarQPE[0, 4, 0, :].data.numpy()  # batch, time, channel
                    # gold4[gold4 < visThrev] = 0
                    gold4,max4, min4 = RestoreNetImg(gold4, 0, 1, returnFlag=True)
                    # gold4 = RestoreNetImg(gold4, 0, 1, maxVal=max4, minVal=min4)
                    logger.img('H_gold3KM04_2', gold4)
                    gold9 = goldRadarQPE[0, 9, 0, :].data.numpy()  # batch, time, channel
                    # gold9[gold9 < visThrev] = 0
                    gold9,max9, min9 = RestoreNetImg(gold9, 0, 1, returnFlag=True)
                    # gold9 = RestoreNetImg(gold9, 0, 1, maxVal=max9, minVal=min9)
                    logger.img('I_gold3KM09_2', gold9)

                    output0 = pred[0, 0, 0, :].cpu().data.numpy()  # batch, time, channel+dem
                    # output0[output0 < visThrev] = 0
                    output0 = RestoreNetImg(output0, 0, 1, maxVal=max0, minVal=min0)
                    logger.img('J_output3KM00_2', output0)
                    output4 = pred[0, 4, 0, :].cpu().data.numpy()  # batch, time, channel+dem
                    # output4[output4 < visThrev] = 0
                    output4 = RestoreNetImg(output4, 0, 1, maxVal=max4, minVal=min4)
                    logger.img('K_output3KM04_2', output4)
                    output9 = pred[0, 9, 0, :].cpu().data.numpy()  # batch, time, channel+dem
                    # output9[output9 < visThrev] = 0
                    output9 = RestoreNetImg(output9, 0, 1, maxVal=max9, minVal=min9)
                    logger.img('L_output3KM09_2', output9)

                    # max0, min0 = 0.5, 0
                    # max4, min4 = 0.5, 0
                    # max9, min9 = 0.5,0
                    # goldQPE0 = goldRadarQPE[0, 0, 5, :].data.numpy()  # batch, time, channel
                    # goldQPE0= RestoreNetImg(goldQPE0, 0, 1, maxVal=max0, minVal=min0)
                    # logger.img('M_goldQPE0', goldQPE0)
                    # goldQPE4 = goldRadarQPE[0, 4, 5, :].data.numpy()  # batch, time, channel
                    # goldQPE4 = RestoreNetImg(goldQPE4, 0, 1, maxVal=max4, minVal=min4)
                    # logger.img('N_goldQPE4', goldQPE4)
                    # goldQPE9 = goldRadarQPE[0, 9, 5, :].data.numpy()  # batch, time, channel
                    # goldQPE9 = RestoreNetImg(goldQPE9, 0, 1, maxVal=max9, minVal=min9)
                    # logger.img('O_goldQPE9', goldQPE9)

                    # outputQPE0 = predQPE[0, 0, 0, :].cpu().data.numpy()  # batch, time, channel+dem
                    # outputQPE0 = RestoreNetImg(outputQPE0, 0, 1, maxVal=max0, minVal=min0)
                    # logger.img('P_outputQPE0', outputQPE0)
                    # outputQPE4 = predQPE[0, 4, 0, :].cpu().data.numpy()  # batch, time, channel+dem
                    # outputQPE4 = RestoreNetImg(outputQPE4, 0, 1, maxVal=max4, minVal=min4)
                    # logger.img('Q_outputQPE4', outputQPE4)
                    # outputQPE9 = predQPE[0, 9, 0, :].cpu().data.numpy()  # batch, time, channel+dem
                    # outputQPE9 = RestoreNetImg(outputQPE9, 0, 1, maxVal=max9, minVal=min9)
                    # logger.img('R_outputQPE9', outputQPE9)

                    # outputRadar0 = np.max(inputRadarQPE[0, 0, :5, :].cpu().data.numpy(),axis=0)  # batch, time, channel+dem
                    # outputRadar0 = RestoreNetImg(outputRadar0, 0, 1)
                    # logger.img('S_inputRadar0', outputRadar0)
                    # outputRadar4 = np.max(inputRadarQPE[0, 4, :5, :].cpu().data.numpy(),axis=0)  # batch, time, channel+dem
                    # outputRadar4 = RestoreNetImg(outputRadar4, 0, 1)
                    # logger.img('T_inputRadar4', outputRadar4)
                    # outputRadar9 = np.max(inputRadarQPE[0, 9, :5, :].cpu().data.numpy(),axis=0)  # batch, time, channel+dem
                    # outputRadar9 = RestoreNetImg(outputRadar9, 0, 1)
                    # logger.img('U_inputRadar9', outputRadar9)

                    # residualRadar0 = np.max(residualRadar[0, 0, :5, :].cpu().data.numpy(),
                    #                         axis=0)  # batch, time, channel+dem
                    # residualRadar0 = RestoreNetImg(residualRadar0, 0, 1)
                    # logger.img('S_residualRadar00', residualRadar0)
                    # residualRadar4 = np.max(residualRadar[0, 4, :5, :].cpu().data.numpy(),
                    #                         axis=0)  # batch, time, channel+dem
                    # residualRadar4 = RestoreNetImg(residualRadar4, 0, 1)
                    # logger.img('T_residualRadar4', residualRadar4)
                    # residualRadar9 = np.max(residualRadar[0, 9, :5, :].cpu().data.numpy(),
                    #                         axis=0)  # batch, time, channel+dem
                    # residualRadar9 = RestoreNetImg(residualRadar9, 0, 1)
                    # logger.img('U_residualRadar9', residualRadar9)
                    #
                    # residualRadar0 = np.max(predRadarRes[0, 0, :5, :].cpu().data.numpy(),
                    #                         axis=0)  # batch, time, channel+dem
                    # residualRadar0 = RestoreNetImg(residualRadar0, 0, 1)
                    # logger.img('V_predRadarRes0', residualRadar0)
                    # residualRadar4 = np.max(predRadarRes[0, 4, :5, :].cpu().data.numpy(),
                    #                         axis=0)  # batch, time, channel+dem
                    # residualRadar4 = RestoreNetImg(residualRadar4, 0, 1)
                    # logger.img('W_predRadarRes4', residualRadar4)
                    # residualRadar9 = np.max(predRadarRes[0, 9, :5, :].cpu().data.numpy(),
                    #                         axis=0)  # batch, time, channel+dem
                    # residualRadar9 = RestoreNetImg(residualRadar9, 0, 1)
                    # logger.img('X_predRadarRes9', residualRadar9)

                    # lossVal = float(G_loss.cpu().data.numpy())
                    # if np.abs(lossVal) > 0.1:
                    #     print('G loss > 0.1')
                    # else:
                    #     logger.plot('G_loss', lossVal)

                if self.shot != 0 and self.shot % 500 == 0:
                    if not os.path.exists('saved_models/'):
                        os.mkdir('saved_models/')

                    # 要改的地方
                    # torch.save(self.G.state_dict(), "saved_models/wast_%d.pth" % (self.shot))
                    # torch.save(self.G.state_dict(), "saved_models/phydnet_%d.pth" % (self.shot))
                    # torch.save(self.G.state_dict(), "saved_models/simvp_%d.pth" % (self.shot))
                    # torch.save(self.G.state_dict(), "saved_models/tau_%d.pth" % (self.shot))
                    # torch.save(self.G.state_dict(), "saved_models/nowcastnet_%d.pth" % (self.shot))
                    # torch.save(self.G.state_dict(), "saved_models/UnetIncepDWRes_%d.pth" % (self.shot))
                    # torch.save(self.G.state_dict(), "saved_models/predrnnv2_%d.pth" % (self.shot))
                    torch.save(self.G.state_dict(), "saved_models/mynet_%d.pth" % (self.shot))



