import numpy as np
import os
import bz2
import struct
import chardet
from matplotlib import pyplot as plt
import tifffile

'''
绘制雷达图像
@res 为二维numpy矩阵
'''
def plot_img(res,save_dir=None):
    """res : DN值"""
    res2 = res / (np.max(res) / 255)
    # res2 = res
    plt.figure(figsize=(res2.shape[1] / 100, res2.shape[0] / 100))  #
    plt.axes([0., 0., 1., 1.], frameon=False, xticks=[], yticks=[])
    plt.imshow(res2, cmap='gray',vmin=0,vmax=255)
    # plt.imshow(res2, cmap='jet', vmin=-10, vmax=None)
    # print('=================DRAWING===================')
    if save_dir is not None:
        print(save_dir)
        plt.savefig(save_dir)
    plt.show()
    plt.close()

#2000 1000 21
def read_bin_3d_quick(data_path, type='radar', XNumGrids=2000, YNumGrids=1000, ZNumGrids=21):
    # file = bz2.BZ2File(data_path, "rb")
    # data = file.read()
    # print(len(data))
    # file.close()
    file = bz2.BZ2File(data_path, "rb")
    file.read(1024)
    # file.seek(1024)
    valueZYX = None
    if type == 'qpe': #降水
        valueZYX = np.zeros((ZNumGrids,YNumGrids, XNumGrids), dtype=np.uint16)
        for i in range(0, ZNumGrids):
            for j in range(0, YNumGrids):
                #valueX = []
                value = struct.unpack("H"*XNumGrids, file.read(XNumGrids*2))
                valueZYX[i,j,:] = value
                # for k in range(0, XNumGrids):
                #     value, = struct.unpack("B", file.read(1))
                #     valueZYX[i][j][k] = value
        #valueZYX = valueZYX.astype(np.float32)
        #valueZYX /= 10 #0.1mm为单位

    else: # 雷达
        valueZYX = np.zeros((ZNumGrids, YNumGrids, XNumGrids), dtype=np.int16)
        for i in range(0, ZNumGrids):
            for j in range(0, YNumGrids):
                # valueX = []
                value = struct.unpack("B" * XNumGrids, file.read(XNumGrids))
                valueZYX[i, j, :] = np.array(value, dtype=np.int16)
        valueZYX -=66
        valueZYX //= 2
        valueZYX = np.maximum(valueZYX, 0)
        valueZYX = valueZYX.astype(np.uint8)

    file.close()
    return valueZYX

def read_bin_3d_radar(data_path, channel, XNumGrids=2000, YNumGrids=1000, ZNumGrids=21,):
    # file = bz2.BZ2File(data_path, "rb")
    # data = file.read()
    # print(len(data))
    # file.close()
    file = bz2.BZ2File(data_path, "rb")
    # file.read(1024)
    file.seek(1024,whence=1)
    valueZYX = None

    valueZYX = np.zeros((len(channel), YNumGrids, XNumGrids), dtype=np.int16)
    zid = -1
    offset = YNumGrids * XNumGrids
    cache = None #np.zeros(( YNumGrids, XNumGrids), dtype=np.int16)
    unpackStr = "B" * XNumGrids * YNumGrids
    for i in range(0, ZNumGrids):
        if i in channel:
            zid += 1
            cache = np.array(struct.unpack(unpackStr, file.read(XNumGrids*YNumGrids)), dtype=np.int16).reshape(( YNumGrids, XNumGrids))
            valueZYX[zid,:] = cache
            # for j in range(0, YNumGrids):
            #     value = struct.unpack("B" * XNumGrids, file.read(XNumGrids))
            #     valueZYX[zid, j, :] = np.array(value, dtype=np.int16)
        else:
            file.seek(offset,whence=1) #
    file.close()
    valueZYX -=66
    valueZYX //= 2
    valueZYX = np.maximum(valueZYX, 0)
    valueZYX = valueZYX.astype(np.uint8)
    return valueZYX

'''
读取三维反射率bin文件
@data_path bin文件路径
@save_npy_path 保存数据到npy文件中，只存储数据
@save_png_path 保存数图片为png格式
meiyong,ceshide 
'''
def read_bin_3d_info(data_path=None, save_npy_path=None,save_png_path="./demo_img", idx=None):
    file = bz2.BZ2File(data_path, "rb")
    data = file.read()
    print(len(data))
    file.close()
    #
    file = bz2.BZ2File(data_path, "rb")
    length = 0

    # result = chardet.detect(file.read())
    # encoding = result['encoding']
    # print(encoding)


    zonName, dataName, flag, version, = struct.unpack("12s38s8s8s", file.read(12 + 38 + 8 + 8))
    zonName = zonName.decode("gbk").rstrip('\x00')
    # zonName = zonName.decode(encoding).rstrip('\x00')
    # dataName = dataName.decode("gbk").rstrip('\x00')
    # dataName = dataName.decode(encoding).rstrip('\x00')
    flag = flag.decode("gbk").rstrip('\x00')
    # flag = flag.decode(encoding).rstrip('\x00')
    version = version.decode("gbk").rstrip('\x00')
    # version = version.decode(encoding).rstrip('\x00')
    length = length + 12 + 38 + 8 + 8

    # #
    # print(zonName)
    # # print("数据说明: " + dataName)
    # print("文件标志: " + flag)
    # print("数据版本号: " + version)

    #
    year, month, day, hour, minute, interval, = struct.unpack("HHHHHH", file.read(2 + 2 + 2 + 2 + 2 + 2))
    # print("时间: " + str(year) + "-" + str(month) + "-" + str(day) + " " + str(hour) + ":" + str(minute))
    # print("时段长: " + str(interval))
    length = length + 2 + 2 + 2 + 2 + 2 + 2


    #2000 1000 21
    XNumGrids, YNumGrids, ZNumGrids, = struct.unpack("HHH", file.read(2 + 2 + 2))
    # print("X: " + str(XNumGrids) + "  Y: " + str(YNumGrids) + "  Z:" + str(ZNumGrids))
    length = length + 2 + 2 + 2


    #
    RadarCount, = struct.unpack("i", file.read(4))
    # print("拼图雷达数: " + str(RadarCount))
    length = length + 4

    #95 35 105 30 0.01
    StartLon, StartLat, CenterLon, CenterLat, XReso, YReso, = struct.unpack("ffffff", file.read(4 + 4 + 4 + 4 + 4 + 4))
    # print(
    #     "开始经度: " + str(StartLon) + "  开始纬度:" + str(StartLat) + "  中心经度:" + str(CenterLon) + "  中心纬度:" + str(CenterLat))
    # print("经度方向分辨率:" + str(XReso) + "  纬度方向分辨率:" + str(YReso))
    length = length + 4 + 4 + 4 + 4 + 4 + 4


    ZhighGrids = []
    for i in range(0, 40):
        ZhighGrid, = struct.unpack("f", file.read(4))
        ZhighGrids.append(ZhighGrid)
    # print("垂直方向的高度:" + str(ZhighGrids))
    length = length + 40 * 4


    #
    # RadarStationNames = []
    # for i in range(0, 20):
    #     RadarStationName, = struct.unpack("16s", file.read(16))
    #     RadarStationName = RadarStationName.decode("gbk")
    #     RadarStationNames.append(RadarStationName.rstrip('\x00'))
    # print("相关站点名称:" + str(RadarStationNames))
    length = length + 20 * 16


    #
    RadarLongitudes = []
    for i in range(0, 20):
        RadarLongitude, = struct.unpack("f", file.read(4))
        RadarLongitudes.append(RadarLongitude)
    # print("相关站点所在经度:" + str(RadarLongitudes))
    length = length + 20 * 4


    #
    RadarLatitudes = []
    for i in range(0, 20):
        RadarLatitude, = struct.unpack("f", file.read(4))
        RadarLatitudes.append(RadarLatitude)
    # print("相关站点所在纬度:" + str(RadarLatitudes))
    length = length + 20 * 4

    #
    RadarAltitudes = []
    for i in range(0, 20):
        RadarAltitude, = struct.unpack("f", file.read(4))
        RadarAltitudes.append(RadarAltitude)
    # print("相关站点所在海拔高度:" + str(RadarAltitudes))
    length = length + 20 * 4


    #
    MosaicFlags = []
    for i in range(0, 20):
        MosaicFlag, = struct.unpack("B", file.read(1))
        MosaicFlags.append(MosaicFlag)
    # print("该相关站点数据是否包含在本次拼图中:" + str(MosaicFlags))
    length = length + 20 * 1

    # valueZYX = np.zeros((ZNumGrids,YNumGrids, XNumGrids), dtype=np.uint8)
    # for i in range(0, ZNumGrids):
    #     for j in range(0, YNumGrids):
    #         #valueX = []
    #         value = struct.unpack("B"*XNumGrids, file.read(XNumGrids))
    #         valueZYX[i,j,:] = value
    #         # for k in range(0, XNumGrids):
    #         #     value, = struct.unpack("B", file.read(1))
    #         #     valueZYX[i][j][k] = value

    #
    # print("数据:"+str(valueZYX))
    length = length + ZNumGrids * YNumGrids * XNumGrids * 1
    # print(length)
    #
    print("----------------------------数据----------------------------")

    file.close()




