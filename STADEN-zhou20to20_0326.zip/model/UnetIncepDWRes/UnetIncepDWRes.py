""" Full assembly of the parts to form the complete network """
import torch
import torch.nn as nn
# from torchinfo import summary
from model.UnetIncepDWRes.unet_parts import *
from model.UnetIncepDWRes.Translator import *


class UnetIncepDWRes(nn.Module):
    def __init__(self, n_channels, n_classes, hiddem=28, hid_T=128, N_T=4, bilinear=False):
        super(UnetIncepDWRes, self).__init__()
        self.n_channels = n_channels
        self.n_classes = n_classes
        self.bilinear = bilinear

        self.inc = (DoubleConv(n_channels, hiddem))
        self.down1 = (Down(hiddem, hiddem*2))
        self.down2 = (Down(hiddem*2, hiddem*4))
        self.down3 = (Down(hiddem*4, hiddem*8))
        factor = 2 if bilinear else 1
        self.down4 = (Down(hiddem*8, hiddem*16 // factor))

        self.translator = Translator(hiddem*16 // factor, hid_T, N_T, hiddem*16 // factor, incep_dilation=[1,2,3,5], groups=8)

        self.up1 = (Up(hiddem*16, hiddem*8 // factor, bilinear))
        self.up2 = (Up(hiddem*8, hiddem*4 // factor, bilinear))
        self.up3 = (Up(hiddem*4, hiddem*2 // factor, bilinear))
        self.up4 = (Up(hiddem*2, hiddem, bilinear))
        self.outc = (OutConv(hiddem, n_classes))

    def forward(self, x):
        B, T, C, H, W = x.shape
        x = x.reshape(B * T, C, H, W)

        # 编码
        x1 = self.inc(x)
        x2 = self.down1(x1)
        x3 = self.down2(x2)
        x4 = self.down3(x3)
        x5 = self.down4(x4)
        # print(x5.shape)

        _, C_, H_, W_ = x5.shape
        """时间和通道转换"""
        x = x5.view(B, C_, T, H_, W_)

        # 时空模块
        x = self.translator(x)

        x = x.reshape(B * T, C_, H_, W_)

        # 解码
        x = self.up1(x, x4)
        x = self.up2(x, x3)
        x = self.up3(x, x2)
        x = self.up4(x, x1)

        logits = self.outc(x)

        logits = logits.reshape(B, T, C, H, W)
        return logits

    def train_forward(self, x):
        cur = x.clone()
        y=[]
        for _ in range(2):
            cur = self.forward(cur)
            y.append(cur)
        return torch.cat(y,dim=1)

# if __name__ == '__main__':
#     device = torch.device("cpu")
#     model = UnetIncepDWRes(n_channels=3, n_classes=1, hiddem=16, hid_T=256, N_T=6, bilinear=True).to(device)
#     summary(model, [1, 20, 3, 360, 920], device=device)