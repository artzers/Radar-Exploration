from torch import nn
import torch
# from torchinfo import summary

class GroupConv3D_DW(nn.Module):
    def __init__(self, in_c, out_c, groups, dilation, act_norm=True):
        super(GroupConv3D_DW, self).__init__()
        self.act_norm = act_norm
        self.conv = nn.Conv3d(in_c, out_c, kernel_size=3, dilation=dilation, padding=dilation, groups=in_c)
        self.norm = nn.GroupNorm(groups, out_c)
        self.act = nn.LeakyReLU(0.2, inplace=True)

    def forward(self, x):
        y = self.norm(self.conv(x))
        # 残差连接时最后一个卷机不需要激活
        if self.act_norm:
            y = self.act(y)
        return y


class Inception(nn.Module):
    def __init__(self, in_c, hid_c, out_c, incep_dilation=[1, 2, 3, 5], groups=8, act_norm=True):
        super(Inception, self).__init__()
        self.conv1 = nn.Conv3d(in_c, hid_c, kernel_size=1, stride=1, padding=0)
        layers = []
        for dilation in incep_dilation:
            layers.append(
                GroupConv3D_DW(hid_c, out_c, groups=groups, dilation=dilation,  act_norm=act_norm))
        self.layers = nn.Sequential(*layers)

    def forward(self, x):
        x = self.conv1(x)
        y = 0
        for layer in self.layers:
            y += layer(x)

        return y


class residual_block(nn.Module):
    def __init__(self, incep_hid1, incep_hid2, incep_dilation=[1, 2, 3, 5], groups=8):
        super(residual_block, self).__init__()
         # incep_hid1(收入，中间，输出)
        self.inceip1 = Inception(incep_hid1[0], incep_hid1[1], incep_hid1[2], incep_dilation=incep_dilation, groups=groups, act_norm=True)
        self.inceip2 = Inception(incep_hid2[0], incep_hid2[1], incep_hid2[2], incep_dilation=incep_dilation, groups=groups, act_norm=False)

        # 处理参差连接通道维度不一样
        self.conv1 = nn.Conv3d(incep_hid1[0], incep_hid2[2], kernel_size=1, stride=1, padding=0)
        self.norm1 = nn.GroupNorm(groups, incep_hid2[2])
        self.act = nn.LeakyReLU(0.2, inplace=True)
        self.C = incep_hid2[2]

    def forward(self, x):
        residual = x  # 残差连接

        y = self.inceip1(x)
        y = self.inceip2(y)

        if self.C != residual.shape[1]:
            residual = self.conv1(x)
            residual = self.norm1(residual)

        y += residual

        y = self.act(y)

        return y


class Translator(nn.Module):
    def __init__(self, channel_in, channel_hid, N_T, hid_S, incep_dilation=[1, 2, 3, 5], groups=8):
        super(Translator, self).__init__()
        self.N_T = N_T

        res_layers = [residual_block([channel_in, channel_hid // 2, channel_hid], [channel_hid, channel_hid // 2, channel_hid], incep_dilation=incep_dilation, groups=groups)]
        for i in range(1, N_T - 1):
            res_layers.append(residual_block([channel_hid, channel_hid // 2, channel_hid], [channel_hid, channel_hid // 2, channel_hid], incep_dilation=incep_dilation, groups=groups))

        res_layers.append(residual_block([channel_hid, channel_hid // 2, channel_hid], [channel_hid, channel_hid // 2, hid_S], incep_dilation=incep_dilation, groups=groups))
        self.translator = nn.Sequential(*res_layers)

    def forward(self, x):
        B, C, T, H, W = x.shape

        z = x
        for i in range(self.N_T):
            z = self.translator[i](z)

        """需修改"""
        out_t = 10  # 输出的序列长度
        # print(z.shape)
        y = z.reshape(B, out_t, C, H, W)
        return y

# if __name__ == '__main__':
#     device = torch.device("cpu")
#     model = Translator(64, 128, 6, 64, incep_dilation=[1,2,3,5], groups=8)
#     summary(model, [1, 64, 20, 22, 57], device=device)