from .predrnn import PredRNN
from model.predrnnv2_model import PredRNNv2_Model
import torch
from utils import (reshape_patch, reshape_patch_back,
                           reserve_schedule_sampling_exp, schedule_sampling)


class Config:
    def __init__(self):
        self.reverse_scheduled_sampling = 0
        self.r_sampling_step_1 = 25000
        self.r_sampling_step_2 = 50000
        self.r_exp_alpha = 5000
        # scheduled sampling
        self.scheduled_sampling = 0  #设为0 就是部署
        self.sampling_stop_iter = 50000
        self.sampling_start_value = 1.0
        self.sampling_changing_rate = 0.00002
        # model
        self.num_hidden = '64,64,64,64'
        self.filter_size = 5
        self.stride = 1
        self.patch_size = 2
        self.layer_norm = 0
        self.decouple_beta = 0.1
        self.total_length = 20
        self.pre_seq_length = 10
        self.aft_seq_length = 10
        self.in_shape = [10,1,480,480]
        self.device = 'cuda:0'

class PredRNNv2(torch.nn.Module):
    r"""PredRNNv2

    Implementation of `PredRNN: A Recurrent Neural Network for Spatiotemporal
    Predictive Learning <https://arxiv.org/abs/2103.09504v4>`_.

    """

    def __init__(self, device):
        super(PredRNNv2, self).__init__()
        self.hparams = Config()
        self.eta = 1.0
        self.model = self._build_model()
        if device == 'cpu':
            self.model = self.model.cpu()
        else:
            self.model = self.model.cuda()

    def _build_model(self, **args):
        num_hidden = [int(x) for x in self.hparams.num_hidden.split(',')]
        num_layers = len(num_hidden)
        return PredRNNv2_Model(num_layers, num_hidden, self.hparams)

    def training_step(self, input,gold,globalStep):
        self.global_step = globalStep
        batch_x, batch_y = input,gold
        ims = torch.cat([batch_x, batch_y], dim=1).permute(0, 1, 3, 4, 2).contiguous()
        ims = reshape_patch(ims, self.hparams.patch_size)

        if self.hparams.reverse_scheduled_sampling == 1:
            real_input_flag = reserve_schedule_sampling_exp(
                self.global_step, ims.shape[0], self.hparams)
        else:
            self.eta, real_input_flag = schedule_sampling(
                self.eta, self.global_step, ims.shape[0], self.hparams)

        img_gen = self.model(ims, real_input_flag)
        img_gen = reshape_patch_back(img_gen, self.hparams.patch_size)
        pred_y = img_gen[:, -self.hparams.aft_seq_length:].permute(0, 1, 4, 2, 3).contiguous()
        return pred_y

    # def MyTrain_Step(self,input,gold,globalStep):
    #     cur = input.clone()
    #     pred = []
    #     cur = self.training_step(input,gold[:,:10],globalStep)
    #     pred.append(cur)
    #     cur = self.training_step(cur, gold[:, 10:], globalStep)
    #     pred.append(cur)
    #     return torch.cat(pred, dim=1)