import torch
from torch import nn
from model.swinlstm_model import SwinLSTM

class Config:
    def __init__(self):
        self.in_shape = [10,5,640,640]
        self.patch_size = 2
        self.window_size = 4
        self.embed_dim = 128

class SwinLSTM_D(nn.Module):
    r"""SwinLSTM 
    Implementation of `SwinLSTM: Improving Spatiotemporal Prediction Accuracy using Swin
    Transformer and LSTM <http://arxiv.org/abs/2308.09891>`_.

    """

    def __init__(self, **args):
        super().__init__(**args)
        self.depths_downsample = [2,4]
        self.depths_upsample = [4,2]
        self.num_heads = [2,2]
        self.config = Config()
        self.model = SwinLSTM(img_size=[640,640],patch_size=2,in_chans=5,embed_dim=128,
                              depths_downsample = self.depths_downsample,
                              depths_upsample = self.depths_upsample,
                              num_heads = self.num_heads, window_size = 4)
    
    def forward(self, inputs, **kwargs):
        """Forward the model"""
        states_down = [None] * len(self.depths_downsample)
        states_up = [None] * len(self.depths_downsample)

        outputs = []

        inputs_len = inputs.shape[1]

        last_input = inputs[:, -1]

        for i in range(inputs_len - 1):
            output, states_down, states_up = self.model(inputs[:, i], states_down, states_up)
            outputs.append(output)

        for i in range(10):
            output, states_down, states_up = self.model(last_input, states_down, states_up)
            outputs.append(output)
            last_input = output

        return outputs
    #
    # def training_step(self, batch, batch_idx):
    #     batch_x, batch_y = batch
    #     ims = torch.cat([batch_x, batch_y], dim=1).permute(0, 1, 3, 4, 2).contiguous()
    #
    #     img_gen, loss = self.model(ims)
    #     self.log('train_loss', loss, on_step=True, on_epoch=True, prog_bar=True)
    #     return loss

