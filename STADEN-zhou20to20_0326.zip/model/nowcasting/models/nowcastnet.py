from copy import deepcopy

import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
from nowcasting.layers.utils import warp, make_grid
from nowcasting.layers.generation.generative_network import Generative_Encoder, Generative_Decoder
from nowcasting.layers.evolution.evolution_network import Evolution_Network
from nowcasting.layers.generation.noise_projector import Noise_Projector
# from torchinfo import summary
import argparse

class NowCastNet(nn.Module):
    def __init__(self):
        super(NowCastNet, self).__init__()
        self.configs = init_configs()
        self.pred_length = self.configs.total_length - self.configs.input_length
        """
        self.evo_net = Evolution_Network(self.configs.input_length, self.pred_length, base_c=32)
        """

        """此处添加"""
        self.evo_net = Evolution_Network(self.configs.input_length * self.configs.input_channel, self.pred_length, base_c=24) # base_c=32

        """
        self.gen_enc = Generative_Encoder(self.configs.total_length, base_c=self.configs.ngf)
        """
        """此处添加"""
        self.gen_enc = Generative_Encoder(2* self.configs.input_length * (self.configs.input_channel), base_c=self.configs.ngf) #去掉dem

        self.conv_evo = nn.Conv2d(self.configs.input_length * self.configs.output_channel,
                                  self.configs.input_length, kernel_size=3, padding=1)
        self.configs_radar = deepcopy(self.configs)
        self.configs_radar.output_channel -= 1
        self.configs_radar.ngf = 16
        self.gen_dec_radar = Generative_Decoder(self.configs_radar)
        self.configs_qpe = deepcopy(self.configs)
        self.configs_qpe.output_channel = 1
        self.configs_qpe.ngf = 8
        self.gen_dec_qpe = Generative_Decoder(self.configs_qpe)

        self.proj = Noise_Projector(self.configs.ngf, self.configs)

        sample_tensor = torch.zeros(1, 1, self.configs.img_height, self.configs.img_width)
        self.grid = make_grid(sample_tensor)

    def forward(self, all_frames):

        """
        all_frames = all_frames[:, :, :, :, :1]
        frames = all_frames.permute(0, 1, 4, 2, 3)
        batch = frames.shape[0]
        height = frames.shape[3]
        width = frames.shape[4]

        # Input Frames
        input_frames = frames[:, :self.configs.input_length]
        input_frames = input_frames.reshape(batch, self.configs.input_length*2, height, width)
        """

        """此处添加"""
        input_frames = all_frames
        batch = input_frames.shape[0]
        T = input_frames.shape[1] #时序
        C = input_frames.shape[2] #通道
        height = input_frames.shape[3]
        width = input_frames.shape[4]
        input_frames = input_frames.reshape(batch, T*C, height, width)

        # print('input_frames:',input_frames.shape)

        # Evolution Network
        intensity, motion = self.evo_net(input_frames)
        motion_ = motion.reshape(batch, self.pred_length, 2 * self.configs.output_channel, height, width)
        intensity_ = intensity.reshape(batch, self.pred_length, 1 * self.configs.output_channel, height, width)

        # evo_operator
        series = []
        """修改注意all_frames通道维不是最后一个"""
        last_frames = all_frames[:, (self.configs.input_length - 1):self.configs.input_length, :3, :, :]#去掉dem
        # print(last_frames.shape)
        # last_frames = torch.squeeze(last_frames,dim=1)
        grid = self.grid.repeat(batch, 1, 1, 1)
        # for i in range(self.pred_length):
        #     last_frames = warp(last_frames, motion_[:, i], grid.cuda(), mode="nearest", padding_mode="border")
        #     last_frames = last_frames + intensity_[:, i]
        #     series.append(last_frames)
        # evo_result = torch.cat(series, dim=1)
        for i in range(self.pred_length):
            # last_frames = warp(last_frames, motion_[:, i,:], grid.cuda(), mode="nearest", padding_mode="border")
            res_f = []
            for j in range(self.configs.output_channel):
                # print(i,j)
                res_f.append(warp(last_frames[:,:,j,:,:], motion_[:, i, 2*j:2*(j+1),:], grid.cuda(), mode="nearest", padding_mode="border")) #nearest
                # last_frames_layer = last_frames[:,j,:,:].clone()
                # last_frames_layer = torch.unsqueeze(last_frames_layer, dim=0)
                # last_frames_layer = warp(last_frames_layer, motion_[:, i,2*j:2*(j+1)], grid.cuda(), mode="bilinear", padding_mode="border")
                # res_f.append(last_frames_layer)
            res_f = torch.cat(res_f, dim=1)
            # last_frames = res_f + intensity_[:, i, :]
            last_frames = res_f + intensity_[:, i, :]
            last_frames = torch.unsqueeze(last_frames, dim=0)
            series.append(last_frames)
        evo_result = torch.cat(series, dim=1)

        # evo_result = evo_result/128 #zhou 注释

        # print('evo_result:', evo_result.shape)

        # Generative Network
        evo_result = evo_result.reshape(batch, -1, height, width)
        new_input_frames = all_frames[:,:,:,:].reshape(batch, T*(C), height, width)#去掉dem
        evo_feature = self.gen_enc(torch.cat([new_input_frames, evo_result], dim=1))

        # print('evo_feature:', evo_feature.shape)
        """
        noise = torch.randn(batch, self.configs.ngf, height // 32, width // 32).cuda()
        """

        """此处添加"""
        # 潜在随机向量Z
        noise = torch.randn(batch, self.configs.ngf, height // 32, width // 32).cuda()
        noise_feature = self.proj(noise)
        # print('noise_feature:', noise_feature.shape)
        noise_feature = noise_feature.reshape(batch, -1, (height // 32)*4, (width // 32)*4)

        """
        noise_feature = self.proj(noise).reshape(batch, -1, 4, 4, 8, 8).permute(0, 1, 4, 5, 2, 3).reshape(batch, -1, height // 8, width // 8)
        """
        # print('noise_feature:', noise_feature.shape)

        # 解码
        feature = torch.cat([evo_feature, noise_feature], dim=1)
        # print(feature.shape)
        new_evo_result = self.conv_evo(evo_result)
        gen_result_radar = self.gen_dec_radar(feature, new_evo_result)
        gen_result_radar = gen_result_radar.reshape(batch, T, self.configs_radar.output_channel, height, width)
        gen_result_qpe = self.gen_dec_qpe(feature, new_evo_result)
        gen_result_qpe = gen_result_qpe.reshape(batch, T, self.configs_qpe.output_channel, height, width)
        gen_result = torch.cat([gen_result_radar, gen_result_qpe], dim=2)
        # print(gen_result.shape)

        """
        return gen_result.unsqueeze(-1)
        """
        """此处添加"""
        return gen_result


def init_configs():
    parser = argparse.ArgumentParser(description='NowcastNet')
    parser.add_argument('--input_length', type=int, default=10)
    parser.add_argument('--total_length', type=int, default=20)
    parser.add_argument('--img_height', type=int, default=640)
    parser.add_argument('--img_width', type=int, default=640)
    parser.add_argument('--ngf', type=int, default=24) # 32

    """此处添加"""
    parser.add_argument('--input_channel', type=int, default=3) # channel //+ dem
    parser.add_argument('--output_channel', type=int, default=1)

    args = parser.parse_args()
    args.evo_ic = args.total_length - args.input_length
    args.gen_oc = args.total_length - args.input_length
    args.ic_feature = args.ngf * 10
    return args


if __name__ == '__main__':
    device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
    model = NowCastNet().to(device)
    # print(model)
    # summary(model, [1, 20, 3, 360, 920], device=device)