import torch
from torch import nn
import numpy as np

from model.phydnet_model import PhyDNet_Model

class Config:
    def __init__(self):
        self.in_shape = [10,1,480,480]
        self.patch_size = 4
        self.pre_seq_length = 10
        self.aft_seq_length = 10
        self.device = 'cuda'
        self.dist = False

class PhyDNet(torch.nn.Module):
    r"""PhyDNet

    Implementation of `Disentangling Physical Dynamics from Unknown Factors for
    Unsupervised Video Prediction <https://arxiv.org/abs/2003.01460>`_.

    """

    def __init__(self,device, **args):
        super().__init__(**args)
        self.constraints = self._get_constraints()
        self.hparams = Config()
        if device == 'cpu':
            self.hparams.device = 'cpu'
            self.model = PhyDNet_Model(self.hparams)
        else:
            self.hparams.device = 'cuda'
            self.model = PhyDNet_Model(self.hparams).cuda()
        # self.criterion = nn.MSELoss(reduction='mean')

    def _get_constraints(self):
        constraints = torch.zeros((49, 7, 7))
        ind = 0
        for i in range(0, 7):
            for j in range(0, 7):
                constraints[ind,i,j] = 1
                ind +=1
        return constraints 

    def forward(self, batch_x, **kwargs):
        if not self.hparams.dist:
            pred_y = self.model.inference(batch_x, self.constraints, return_loss=False)
        else:
            pred_y = self.model.module.inference(batch_x, self.constraints, return_loss=False)
        return pred_y
    
    def training_step(self, input, gold, current_epoch, min_teaching_ration = 0.1):
        batch_x, batch_y = input, gold
        # teacher_forcing_ratio = np.maximum(0 , 1 - current_epoch * 0.003)
        teacher_forcing_ratio = np.maximum(min_teaching_ration, 1 - current_epoch * 0.3)
        pred_y, loss = self.model(batch_x, batch_y, self.constraints, teacher_forcing_ratio)
        # loss = self.criterion(pred_y, batch_y)
        # self.log('train_loss', loss, on_step=True, on_epoch=True, prog_bar=True)
        return pred_y, loss