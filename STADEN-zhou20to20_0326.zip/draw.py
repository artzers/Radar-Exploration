import os

import cartopy.crs as ccrs
import matplotlib.pyplot as plt
import cartopy.feature as cfeat
import numpy as np
from PIL import Image, ImageOps
from cartopy.io.shapereader import Reader
import matplotlib.gridspec as gridspec
import warnings
from matplotlib.colors import LinearSegmentedColormap, BoundaryNorm
warnings.filterwarnings("ignore", category=UserWarning)

# 显示你选择的模型进行可视化对比
def draw_all_model(model_names):

    real_data = np.load('/home/yh/python_code/leida_project/train_show/real_nanData.npy')

    all_data = []
    all_data.append(real_data)

    # (69 / 255, 155 / 255, 251 / 255), (140 / 255, 238 / 255, 238 / 255),
    # (109 / 255, 250 / 255, 61 / 255),
    # colors = [
    #     (69 / 255, 155 / 255, 251 / 255), (140 / 255, 238 / 255, 238 / 255),
    #     (109 / 255, 250 / 255, 61 / 255),
    #     (0 / 255, 216 / 255, 0 / 255),
    #     (1 / 255, 144 / 255, 0 / 255), (255 / 255, 255 / 255, 0 / 255),
    #     (231 / 255, 192 / 255, 0 / 255), (255 / 255, 144 / 255, 0 / 255),
    #     (255 / 255, 0 / 255, 0 / 255), (214 / 255, 0 / 255, 0 / 255),
    #     (192 / 255, 0 / 255, 0 / 255), (255 / 255, 0 / 255, 240 / 255),
    #     (150 / 255, 0 / 255, 180 / 255), (173 / 255, 144 / 255, 240 / 255)
    # ]

    # colors = [
    #     (3 / 255, 161 / 255, 253 / 255),
    #     (1 / 255, 235 / 255, 237 / 255), (6 / 255, 216 / 255, 3 / 255),
    #     (1 / 255, 147 / 255, 0 / 255), (254 / 255, 254 / 255, 1 / 255),
    #     (233 / 255, 193 / 255, 1 / 255), (255 / 255, 142 / 255, 3 / 255),
    #     (253 / 255, 0 / 255, 2 / 255), (219 / 255, 0 / 255, 2 / 255),
    #     (190 / 255, 0 / 255, 5 / 255), (254 / 255, 0 / 255, 244 / 255),
    #     (176 / 255, 144 / 255, 242 / 255), (151 / 255, 0 / 255, 184 / 255)
    # ]
    # ['#FFFFFF', '#039EF7', '#04EAE8', '#00DB00', '#029005', '#FFFF03', '#E7C200', '#FF8F00',
    #             '#FE0000', '#D30104', '#C20000', '#FF00F4', '#AC91ED', '#9B00B9']
    colors = ['#029005', '#FFFF03', '#E7C200', '#FF8F00',
            '#FE0000', '#D30104', '#C20000', '#FF00F4', '#AC91ED', '#9B00B9']


    cm = LinearSegmentedColormap.from_list('custom_cmap', colors)

    # color_max = 71
    # color_min = 0
    # n_gap = 5
    # levels = np.arange(color_min, color_max, n_gap)
    levels = [20, 25, 30, 35, 40, 45, 50, 55, 60, 65, 70]
    # 设置雷达反射率图覆盖范围
    lon_lat_data = np.load('/home/yh/python_code/leida_project/old_other/经纬度.npy')
    lon = lon_lat_data[0]
    lat = lon_lat_data[1]
    # 读取地区.shp文件
    province = Reader('/home/yh/python_code/leida_project/行政划分/四川省.shp')

    for i in range(len(model_names)):
        data = np.load('/home/yh/python_code/leida_project/train_show/' + model_names[i] + r'/pred_data.npy')

        data[np.isnan(real_data)] = np.nan

        all_data.append(data)

    all_data = np.array(all_data)
    all_data[all_data < 0] = 0

    # 反归一化
    all_data = all_data * 75

    for i in range(all_data.shape[1]):

        if i in [14, 24, 26, 75, 103, 106, 107, 120, 121, 220, 234, 242, 256, 309, 404, 472]:
            pass
        else:
            continue
        # if i != 472:
        #     continue

        proj = ccrs.PlateCarree()  # 创建投影，选择cartopy的platecarree投影
        fig, axs = plt.subplots(int(all_data.shape[0]), 10,
                                figsize=(18, int(all_data.shape[0]) * 3),
                                subplot_kw=dict(projection=proj))

        fig.suptitle(str(i))


        for k in range(all_data.shape[0]):
            for j in range(10):
                # 添加省界
                axs[k, j].add_geometries(province.geometries(), crs=proj, facecolor='none', edgecolor='k', lw=0.5)

                gl = axs[k, j].gridlines(crs=ccrs.PlateCarree(), draw_labels=True, linewidth=0.5, color='k', alpha=0.5,
                                         linestyle='--')
                gl.top_labels = False  # 关闭顶端标签
                gl.right_labels = False  # 关闭右侧标签

                pcm = axs[k, j].contourf(lon, lat, all_data[k, i, j*2+1, 0,], levels=levels, cmap=cm)
                # axs[0, j].axis('off')
                if k == 0:
                    axs[k, j].set_title('true' + str(j*2+1+1), fontsize=10, pad=1)
                else:
                    axs[k, j].set_title(model_names[k-1][:-1] + str(j*2+1+1), fontsize=10, pad=1)
                if j != 0:
                    gl.left_labels = False  # 关闭左端标签
                # gl.bottom_labels = False  # 关闭下侧标签

                gl.xlabel_style = {'size': 6}
                gl.ylabel_style = {'size': 6}



        plt.subplots_adjust(hspace=0, wspace=0)  # 调整行之间的垂直间距

        #  添加色标
        ax3 = fig.add_axes([0.25, 0.03, 0.5, 0.015])
        fc = fig.colorbar(pcm, cax=ax3, orientation='horizontal', extend='both')
        fc.set_ticks(levels)  # 自定义刻度值
        fc.set_label('dBZ')

        plt.tight_layout(w_pad=0.3)
        # plt.savefig( '/home/yh/python_code/leida_project/train_show/all/' + str(i+1) + ".png", bbox_inches='tight')
        plt.show()
        # plt.close()


# 保存一个模型的可视化结果
def draw_one_result(path, save_path):
    colors = ['#029005', '#FFFF03', '#E7C200', '#FF8F00',
              '#FE0000', '#D30104', '#C20000', '#FF00F4', '#AC91ED', '#9B00B9']
    cm = LinearSegmentedColormap.from_list('custom_cmap', colors)
    levels = [20, 25, 30, 35, 40, 45, 50, 55, 60, 65, 70]
    # 设置雷达反射率图覆盖范围
    lon_lat_data = np.load('/home/yh/python_code/leida_project/old_other/经纬度.npy')
    lon = lon_lat_data[0]
    lat = lon_lat_data[1]
    # 读取地区.shp文件
    province = Reader('/home/yh/python_code/leida_project/行政划分/四川省.shp')

    image_index = [4, 9, 14, 19]

    real_data = np.load('/home/yh/python_code/leida_project/train_show/real_nanData.npy')

    pred_data = np.load(path)
    pred_data[pred_data < 0] = 0
    pred_data[np.isnan(real_data)] = np.nan
    pred_data = pred_data * 75  # 反归一化


    batch_index = 472
    save_path = save_path + '/' + str(batch_index) + '_4'
    if not os.path.exists(save_path):
        os.mkdir(save_path)  # 创建文件夹

    for i in image_index:
        proj = ccrs.PlateCarree()  # 创建投影，选择cartopy的platecarree投影
        fig = plt.figure(figsize=(6, 5))
        ax = fig.add_subplot(111, projection=proj)
        # 添加省界
        ax.add_geometries(province.geometries(), crs=proj, facecolor='none', edgecolor='k', lw=0.5)
        gl = ax.gridlines(crs=ccrs.PlateCarree(), draw_labels=True, linewidth=0.5, color='k', alpha=0.5, linestyle='--')
        gl.top_labels = False  # 关闭顶端标签
        gl.right_labels = False  # 关闭右侧标签

        gl.bottom_labels = False  # 关闭顶端标签
        gl.left_labels = False  # 关闭右侧标签

        pcm = ax.contourf(lon, lat, pred_data[batch_index, i, 0, :, :], levels=levels, cmap=cm)
        # gl.xlabel_style = {'size': 16}
        # gl.ylabel_style = {'size': 16}

        #  添加色标
        # 创建新的轴用于显示色标
        cax = fig.add_axes([1, 0.1, 0.03, 0.8])  # [left, bottom, width, height]
        fc = fig.colorbar(pcm, cax=cax, orientation='vertical')
        fc.set_ticks(levels)  # 自定义刻度值
        fc.set_label('dBz', fontsize=16)
        fc.ax.tick_params(labelsize=16)

        plt.tight_layout()
        plt.savefig(save_path + '/' + str(i+1) + ".png", bbox_inches='tight')
        plt.close()

# 裁剪图片
def crop_image(path):

    save_path = path + '_small'
    if not os.path.exists(save_path):
        os.mkdir(save_path)  # 创建文件夹

    image_name = ['5', '10', '15', '20']
    for name in image_name:

        image_path = os.path.join(path, name+'.png')
        # 打开图片
        image = Image.open(image_path)  # 500*600
        print(image.size)
        # image.show()

        # 裁剪图片的一部分 (例如，裁剪左上角 300x300 像素的区域)
        left = 113
        top = 222
        right = 333
        bottom = 419
        cropped_image = image.crop((left, top, right, bottom))

        # 添加黑色边框
        border_size = 1  # 边框宽度
        cropped_image = ImageOps.expand(cropped_image, border=border_size, fill='black')

        print(cropped_image.size)
        cropped_image.save(os.path.join(save_path, name+'.png'))




if __name__ == '__main__':

    # model_names = ['convlstm', 'predrnn', 'phydnet', 'Unet', 'simvp', 'nowcastnet', 'UnetIncepDWRes_loss1']
    # draw_all_model(model_names)

    draw_one_result(
        path='/home/yh/python_code/leida_project/train_show/real_nanData.npy',
        save_path='/home/yh/python_code/leida_project/train_show/real_image/image'
    )

    # model_names = ['real_image', 'convlstm', 'predrnn', 'phydnet', 'Unet', 'simvp', 'nowcastnet', 'UnetIncepDW', 'UnetIncepDWRes', 'UnetIncepDWRes_loss']
    #
    # for name in model_names:
    #     path = f'/home/yh/python_code/leida_project/train_show/{name}/image/472_1'
    #     crop_image(path)

    pass