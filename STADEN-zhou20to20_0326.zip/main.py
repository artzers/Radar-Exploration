import os, torch
import numpy as np
#import pynvml
from torch import nn
from torch.nn import functional as F
from vis import vis_tool
import tifffile
from torch.utils.data import DataLoader
from Util import GetRadarQPEDataSetAndCropCR#p,GetRadarQPEDataSetAndCropZ357
import math,time
from tqdm import tqdm

#from Net import Trainer
import Net
#import ParallelNet

'''
python -m visdom.server

在浏览器中打开：

http://localhost:8097/
'''


def CalcMeanStd(path):
    srcPath = path
    fileList = os.listdir(srcPath)
    fileNum = len(fileList)

    globalMean = 0
    globalStd = 0

    for name in tqdm(fileList):
        if not name.endswith('.tif'):
            continue
        img = tifffile.imread(os.path.join(srcPath, name))
        mean = np.mean(img)
        globalMean += mean
    globalMean /= fileNum


    for name in tqdm(fileList):
        if not name.endswith('.tif'):
            continue
        img = tifffile.imread(os.path.join(srcPath, name))
        img = img.astype(float)
        img -= globalMean
        sz = img.shape[0] * img.shape[1] * img.shape[2]
        globalStd += np.sum(img ** 2) / float(sz)
    globalStd = (globalStd / len(fileList)) ** (0.5)

    print(globalMean)
    print(globalStd)
    return globalMean,globalStd


def CalcMeanMax(path):
    srcPath = path
    fileList = os.listdir(srcPath)
    fileNum = len(fileList)

    maxVal = 0
    for name in tqdm(fileList):
        img = tifffile.imread(os.path.join(srcPath, name))
        maxVal = np.maximum(maxVal, np.max(img))

    print(maxVal)

    globalMean = 0
    globalStd = 0

    for name in tqdm(fileList):
        img = tifffile.imread(os.path.join(srcPath, name))
        mean = np.mean(img)
        globalMean += mean
    globalMean /= fileNum
    print(globalMean)
    return globalMean,maxVal

env = 'openstl-20to20'
globalDev = 'cuda:0'
globalDeviceID = 0

#要改的地方
radarRoot = 'E:/外推数据/swan/zhou_CR/'
trainListRootStep3 = './'
trainListPrefixStep3 = 'trainList_'
trainListPostfixStep3 = '_30_ratio.txt'
trainListRootStep4 = trainListRootStep3
trainListPrefixStep4 = trainListPrefixStep3
trainListPostfixStep4 = trainListPostfixStep3
# trainListRootStep3 = 'E:\OpenSTL_zhou/'
# trainListPrefixStep3 = 'step3_'
# trainListPostfixStep3 = '_30.txt'
# trainListRootStep4 = 'E:\OpenSTL_zhou/'
# trainListPrefixStep4 = 'step4_'
# trainListPostfixStep4 = '_30_5.txt'

if __name__ == '__main__':
    # lowMean,lowStd = 2000,2000#CalcMeanStd(imgPath)#
    # highMean, highStd = 1000,2000#CalcMeanStd(maskPath)#
    # print(lowMean,lowStd)
    # print(highMean,highStd)
    # exit(0)
    train_dataset = GetRadarQPEDataSetAndCropCR(radarRoot, trainListRootStep3, trainListRootStep4,
                                                  trainListPrefixStep3, trainListPostfixStep3,
                                                  trainListPrefixStep4, trainListPostfixStep4, 100,
                                                  yearList=[2020, 2021, 2022])  # 2020, 2022
    # train_dataset = GetRadarQPEDataSetAndCropZ357(radarRoot, trainListRootStep3,trainListRootStep4,
    #              trainListPrefixStep3, trainListPostfixStep3,
    #              trainListPrefixStep4, trainListPostfixStep4, 100,
    #                                           yearList=[2020,2021, 2022])  # 2020, 2022
    # train_dataset = GetRadarQPEDataSetAndCrop(radarRoot, qpeRoot, trainListRoot, trainListPrefix,
    #                                           trainListPostfix, 100,
    #                                           yearList=[2021,2022 ]) #2020, 2022

    train_loader = DataLoader(train_dataset, batch_size=1, shuffle=True,num_workers=0)
    visdomable = True
    if visdomable == True:
        logger = vis_tool.Visualizer(env=env)
        logger.reinit(env=env)

    Net.logger = logger
    # Net.lowMean = lowMean
    # Net.lowStd = lowStd
    # Net.highMean = highMean
    # Net.highStd = highStd
    trainer = Net.Trainer(data_loader=train_loader, test_loader=None)

    time_start = time.time()
    trainer.Train(turn=10000)
    time_end = time.time()
    print('totally time cost', time_end - time_start)
