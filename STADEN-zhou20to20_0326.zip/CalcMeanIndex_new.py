from model.UnetIncepDWRes import Mynet2
from model.phydnet import PhyDNet
from model.wast import WaST
from vis import vis_tool
import os, torch
from torch.utils.data import DataLoader
import numpy as np
from model.simvp import *
import tifffile, datetime
from computer_zhibiao import csi_pod_far
import matplotlib
import matplotlib.pyplot as plt
from matplotlib import colors
import cartopy.crs as ccrs
import numpy as np
from matplotlib.colors import LinearSegmentedColormap
from model.predrnnv2 import PredRNNv2
from model.UnetIncepDWRes import AllAttenModel


class GetRadarQPEDataSetAndCropZuotu:
    def __init__(self, radarRoot, trainListRoot, specific_file, yearList):
        self.radarRoot = radarRoot
        self.trainListRoot = trainListRoot
        self.yearList = yearList

        # Store all series from the specific file
        self.trainSeriesList = []
        self.year_mapping = {}  # To map timestamp to year

        # Read the mixed-year file
        path = os.path.join(self.trainListRoot, specific_file)
        with open(path, 'r') as f:
            lines = f.readlines()
            for line in lines:
                tmp = line.strip().split(' ')
                if float(tmp[1]) > 0.16:  # Keep existing threshold
                    timestamp = tmp[0]
                    self.trainSeriesList.append(timestamp)
                    year = int(timestamp[:4])
                    if year in yearList:
                        self.year_mapping[timestamp] = yearList.index(year)
                    else:
                        raise ValueError(f"Year {year} from timestamp {timestamp} not in yearList {yearList}")

        self.inputRadar = None
        self.goldRadar = None
        self.yearID = 0
        self.firstName = ''

    def __len__(self):
        return len(self.trainSeriesList)

    def __getitem__(self, idx):
        beginTimeStr = self.trainSeriesList[idx]
        self.yearID = self.year_mapping[beginTimeStr]
        return self.mygetitem(beginTimeStr)

    def mygetitem(self, beginTimeStr):
        dt = datetime.datetime.strptime(beginTimeStr, '%Y%m%d%H%M')
        self.firstName = dt.strftime("%Y%m%d%H%M")
        print(self.firstName)

        self.inputRadar = np.zeros((10, 1, 480, 480), dtype=np.float32)
        self.goldRadar = np.zeros((10, 1, 480, 480), dtype=np.float32)

        self.radarYearDir = os.path.join(self.radarRoot, str(self.yearList[self.yearID]))

        # Input radar (first 10 frames)
        for k in range(10):
            curDt = dt + datetime.timedelta(minutes=12 * k)
            curDt = curDt.strftime("%Y%m%d%H%M")
            radarFile = os.path.join(self.radarYearDir, f'CR_{curDt}.tif')
            if not os.path.exists(radarFile):
                raise FileNotFoundError(f"Radar file not found: {radarFile}")
            curRadar = tifffile.imread(radarFile)[180:660, 740:1220]
            curRadar = curRadar.astype(float) / 50.  # uint8, no negative values
            self.inputRadar[k, 0, :] = curRadar

        # Gold radar (next 10 frames)
        for k in range(10, 20):
            curDt = dt + datetime.timedelta(minutes=12 * k)
            curDt = curDt.strftime("%Y%m%d%H%M")
            radarFile = os.path.join(self.radarYearDir, f'CR_{curDt}.tif')
            if not os.path.exists(radarFile):
                raise FileNotFoundError(f"Radar file not found: {radarFile}")
            curRadar = tifffile.imread(radarFile)[180:660, 740:1220]
            curRadar = curRadar.astype(float) / 50.  # uint8, no negative values
            self.goldRadar[k - 10, 0, :] = curRadar

        self.inputRadar = torch.from_numpy(self.inputRadar.copy()).float()
        self.goldRadar = torch.from_numpy(self.goldRadar.copy()).float()
        return self.inputRadar, self.goldRadar, self.firstName


#phydnet
# G = PhyDNet(device ='cuda')
#predrnnv2
# G= PredRNNv2(device = 'cuda')
# G.hparams.scheduled_sampling = 0
# G.hparams.reverse_scheduled_sampling = 0
# G.hparams.device='cuda'
#simvp
# G = SimVP(in_shape=[10, 1, 480, 480],
#                        hiddem=32, hid_T=256, N_T=8, N_S=2, model_type='incepu',
#                        drop_path=0.0).cuda()
#TAU
# G = SimVP(in_shape = [10, 1, 480, 480],
#             hiddem=32, hid_T=256, N_T=8,N_S = 2, model_type = 'tau',
#             drop_path = 0.0 ).cuda() #TAU.cpu()#.cuda() #TAU
# G = Mynet2(in_shape = [10, 1, 480, 480],
#             hiddem=32, hid_T=256, N_T=8,N_S = 2, model_type = 'tau',
#             drop_path = 0.0 ).cuda() #TAU.cpu()#.cuda() #TAU
#MS UnetIncepDWRes
# G = UnetIncepDWRes(n_channels = 3, n_classes = 3).cuda()
#wast
# G = WaST(device = 'cuda',in_shape = [10,1,480,480],encoder_dim=12, block_list=[2, 6, 2], drop_path_rate=0.25, mlp_ratio=2.)
# G = AllAttenModel(in_shape=[10, 1, 480, 480],
#                        hid_S=56, hid_T=128, N_T=8, N_S=2, #model_type='incepu',drop_path=0.0
#                        ).cuda()#.cpu()#
G = AllAttenModel(in_shape=[10, 1, 480, 480],
                       hid_S=64, hid_T=128, N_T=6, N_S=2, #model_type='incepu',drop_path=0.0
                       ).cuda()#.cpu()#
# Load pre-trained weights
# G.load_state_dict(torch.load('./saved_models_phydnet_csiloss//phydnet_23000.pth', map_location=torch.device('cuda')))
# G.load_state_dict(torch.load('./saved_models_predrnnv2_sichuan//predrnnv2_26500.pth', map_location=torch.device('cpu')))
# G.load_state_dict(torch.load('./saved_models_simvp_csiloss//simvp_71500.pth', map_location=torch.device('cuda')))
# G.load_state_dict(torch.load('./saved_models_simvp_new_weight_hffl//simvp-weight_96500.pth', map_location=torch.device('cuda')))
# G.load_state_dict(torch.load('./saved_models//tau_30000.pth', map_location=torch.device('cuda')))
# G.load_state_dict(torch.load('./saved_models_tau_csiloss//tau_28000.pth', map_location=torch.device('cuda')))
# G.load_state_dict(torch.load('./saved_models_wast_new_weight_hffl//wast-weight_47500.pth', map_location=torch.device('cuda')))
# G.load_state_dict(torch.load('./saved_models_wast_csiloss//wast_84000.pth', map_location=torch.device('cuda')))
# G.load_state_dict(torch.load('./saved_models_phydnet_new_weight_hffl//phydnet-weight_25500.pth', map_location=torch.device('cuda')))
# G.load_state_dict(torch.load('./saved_models_predrnnv2_new_weight_hffl//predrnnv2-weight_15500.pth', map_location=torch.device('cuda')))
# G.load_state_dict(torch.load('./saved_models_predrnnv2_csiloss//predrnnv2_23500.pth', map_location=torch.device('cuda')))
# G.load_state_dict(torch.load('./saved_models_UnetIncepDWRes_sichuan//UnetIncepDWRes_7500.pth', map_location=torch.device('cuda')))
# G.load_state_dict(torch.load('./saved_models_wast_sichuan//wast_61000.pth', map_location=torch.device('cuda')))
# G.load_state_dict(torch.load('./saved_models//wast-weight_47500.pth', map_location=torch.device('cpu')))
G.load_state_dict(torch.load('./saved_models_mynet_csiloss//mynet_401000.pth', map_location=torch.device('cuda')))

# Dataset and DataLoader setup
radarRoot = 'E:/外推数据/swan/zhou_CR'
trainListRoot = './'
specific_file = 'trian_100.txt'  # Your mixed-year TXT file

train_dataset = GetRadarQPEDataSetAndCropZuotu(
    radarRoot=radarRoot,
    trainListRoot=trainListRoot,
    specific_file=specific_file,
    yearList=[2020, 2021, 2022]
)

train_loader = DataLoader(
    train_dataset,
    batch_size=1,
    shuffle=False,  # Process sequentially
    num_workers=0
)

# Main processing loop
count = -1
seriesNameList = []
calcCount = len(train_dataset) - 1  # Process all items
CR20index = np.zeros((calcCount + 1, 15))

for kk, (inputRadarQPE, goldRadarQPE, firstName) in enumerate(train_loader):
    count = count + 1
    print('count:', count)
    if count > calcCount:
        break

    inputRadarQPE = inputRadarQPE.cuda()#.cpu()#
    goldRadarQPE = goldRadarQPE.cuda()#.cpu()#

    with torch.no_grad():
        # predRadarRes = G(inputRadarQPE)
        # pred = predRadarRes
        # output = pred[0, :].cpu().data.numpy()
        # goldRadar = goldRadarQPE.cpu().data.numpy()[0, :]
        #
        # seriesNameList.append(firstName)

        # predRadarRes = G.training_step(inputRadarQPE, goldRadarQPE, globalStep=0)#predrnnv2
        # predRadarRes = G.train_forward(inputRadarQPE) #UnetIncepDWRes专用
        # predRadarRes = G(inputRadarQPE)  # simvp,tau
        # predRadarRes, _ = G.training_step(inputRadarQPE, goldRadarQPE, min_teaching_ration=0, current_epoch=100)#phydnet
        predRadarRes = G(inputRadarQPE) #wast

        pred = predRadarRes  # inputRadarQPE[:, -1, :] + predRadarRes
        # pred= inputRadarQPE + predRadarRes
        output = pred[0, :].cpu().data.numpy()
        goldRadar = goldRadarQPE.cpu().data.numpy()[0, :]

        seriesNameList.append(firstName)

        # Calculate metrics
        csi15, pod15, far15 = csi_pod_far(output, goldRadar, 15 / 50)
        print('CR 3km 15: ', csi15, pod15, far15)
        csi20, pod20, far20 = csi_pod_far(output, goldRadar, 20 / 50)
        print('CR 3km 20: ', csi20, pod20, far20)
        csi30, pod30, far30 = csi_pod_far(output, goldRadar, 30 / 50)
        print('CR 3km 30: ', csi30, pod30, far30)
        csi35, pod35, far35 = csi_pod_far(output, goldRadar, 35 / 50)
        print('CR 3km 35: ', csi35, pod35, far35)
        csi40, pod40, far40 = csi_pod_far(output, goldRadar, 40 / 50)
        print('CR 3km 40: ', csi40, pod40, far40)

        CR20index[count, :] = np.array([csi15, pod15, far15, csi20, pod20, far20,
                                        csi30, pod30, far30, csi35, pod35, far35,
                                        csi40, pod40, far40])

        # Print running means
        print('current mean CSI POD FAR15: %.4f %.4f %.4f' % (np.mean(CR20index[:count + 1, 0]),
                                                              np.mean(CR20index[:count + 1, 1]),
                                                              np.mean(CR20index[:count + 1, 2])))
        print('current mean CSI POD FAR20: %.4f %.4f %.4f' % (np.mean(CR20index[:count + 1, 3]),
                                                              np.mean(CR20index[:count + 1, 4]),
                                                              np.mean(CR20index[:count + 1, 5])))
        print('current mean CSI POD FAR30: %.4f %.4f %.4f' % (np.mean(CR20index[:count + 1, 6]),
                                                              np.mean(CR20index[:count + 1, 7]),
                                                              np.mean(CR20index[:count + 1, 8])))
        print('current mean CSI POD FAR35: %.4f %.4f %.4f' % (np.mean(CR20index[:count + 1, 9]),
                                                              np.mean(CR20index[:count + 1, 10]),
                                                              np.mean(CR20index[:count + 1, 11])))
        print('current mean CSI POD FAR40: %.4f %.4f %.4f' % (np.mean(CR20index[:count + 1, 12]),
                                                              np.mean(CR20index[:count + 1, 13]),
                                                              np.mean(CR20index[:count + 1, 14])))

# Save results
with open('CR_wast_new_weight.txt', 'w') as f:
    for k in range(calcCount + 1):
        f.write(seriesNameList[k][0] + '\n')
np.savetxt('CR20index_mynet_new_weight.txt', CR20index, fmt='%.4f', delimiter=' ')