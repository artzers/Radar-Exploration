from vis import vis_tool
import os, torch
import numpy as np
from model.simvp import  *
import tifffile,datetime
from sebiao import plt_qpe_show, plt_radar_show
from computer_zhibiao import csi_pod_far
from read_binbz2 import read_bin_3d_radar
import datetime
from Util import RestoreNetImg
import tifffile
from model.phydnet import *
from model.UnetIncepDWRes.UnetIncepDWRes import UnetIncepDWRes
from model.wast import WaST
from model.predrnnv2 import PredRNNv2

#要改的地方
#phydnet
# G = PhyDNet(device ='cpu')
#predrnnv2
# G= PredRNNv2(device = 'cuda')
# G.hparams.scheduled_sampling = 0
# G.hparams.reverse_scheduled_sampling = 0
#simvp
# G = SimVP(in_shape=[10, 1, 480, 480],
#                        hiddem=32, hid_T=256, N_T=8, N_S=2, model_type='incepu',
#                        drop_path=0.0).cpu()  # simvp
#TAU
# G = SimVP(in_shape = [10,3,640,640],
#             hiddem=32, hid_T=96, N_T=4,N_S = 2, model_type = 'tau',
#             drop_path = 0.0 ).cpu() #TAU
G = SimVP(in_shape = [10,1,480,480],
            hiddem=32, hid_T=256, N_T=8,N_S = 2, model_type = 'tau',
            drop_path = 0.0 ).cpu()
#MS UnetIncepDWRes
# G = UnetIncepDWRes(n_channels = 3, n_classes = 3).cpu()
#wast
# G = WaST(device = 'cpu', in_shape = [10,3,640,640],encoder_dim=6, block_list=[1, 2, 1], drop_path_rate=0.25, mlp_ratio=2.)

#要改的地方
# G.load_state_dict(torch.load('./saved_models//phydnet_500.pth', map_location=torch.device('cpu')))
# G.load_state_dict(torch.load('./saved_models//predrnnv2_500.pth', map_location=torch.device('cpu')))
# G.load_state_dict(torch.load('./saved_models//simvp_40500.pth', map_location=torch.device('cpu')))
G.load_state_dict(torch.load('./saved_models_tau_old_weight//tau_134500.pth', map_location=torch.device('cpu')))
# G.load_state_dict(torch.load('./saved_models//UnetIncepDWRes_500.pth', map_location=torch.device('cpu')))
# G.load_state_dict(torch.load('./saved_models//wast_500.pth', map_location=torch.device('cpu')))

# G = G.eval()

#要改的地方
yearID = 2020#2020#2021#
ind = 0

radarRoot = 'D:/外推数据/swan/zhou_CR/'
# radarRoot = 'E:/外推数据/swan/zhou_Combine/'

radarYearDir = os.path.join(radarRoot, str(yearID))

#要改的地方
beginTimeStr = '202008110342'
#202108170100'#'202007251906'#'202204111306'#"202007142106"#"202108251906"#"202108252206"#"202308061206"#"202309111906"#
dt = datetime.datetime.strptime(beginTimeStr, '%Y%m%d%H%M')
curDt = dt #+ datetime.timedelta(minutes=60)
curDt = curDt.strftime("%Y%m%d%H%M")
# saveQPERoot = './result_QPE/yubao_%s/'%(curDt)
save3kmRoot = './result_3km/yubao_%s/'%(curDt)
# radarChannel = [1,3,5]#[1,3,5,7,9]

inputRadar = np.zeros((10, 1, 480,480), dtype = np.float32)
goldRadar = np.zeros((10, 1, 480,480), dtype=np.float32)
# inputQPE = np.zeros((10, 1, 896, 1024), dtype=np.float32)
# goldQPE = np.zeros((10, 1, 896,1024), dtype=np.float32)
for k in range(10):
    curDt = dt + datetime.timedelta(minutes=12 * k)
    curDt = curDt.strftime("%Y%m%d%H%M")

    radarFile = os.path.join(radarYearDir,
                             'CR_%s' % (curDt)
                             + '.tif')
    curRadar = tifffile.imread(radarFile)[180:660, 740:1220]
    curRadar = curRadar.astype(float) / 50.  # uint8，没有负数
    inputRadar[k, :, :] = curRadar  # 896,1024

for k in range(10, 20):
    curDt = dt + datetime.timedelta(minutes=12 * k)
    curDt = curDt.strftime("%Y%m%d%H%M")
    radarFile = os.path.join(radarYearDir,
                             'CR_%s' % (curDt)
                             + '.tif')
    curRadar = tifffile.imread(radarFile)[180:660, 740:1220]
    curRadar = curRadar.astype(float) / 50.  # uint8，没有负数
    goldRadar[k - 10, :, :] = curRadar  # 896,1024

# print(np.sum(inputRadar>30/50))

inputRadarQPE = torch.from_numpy(inputRadar.copy()).float()
goldRadarQPE = torch.from_numpy(goldRadar.copy()).float()
inputRadarQPE = torch.unsqueeze(inputRadarQPE, dim=0)
goldRadarQPE = torch.unsqueeze(goldRadarQPE, dim=0)
# inputRadarQPE = inputRadarQPE.cuda(0)

pred = None
#要改的地方
with torch.no_grad(): #注意看应该是那个网络
    # predRadarRes = G.training_step(inputRadarQPE, goldRadarQPE, globalStep=0)
    # predRadarRes = G.train_forward(inputRadarQPE) #UnetIncepDWRes专用
    predRadarRes = G(inputRadarQPE) #simvp,tau
    # predRadarRes, _ = G.training_step(inputRadarQPE, goldRadarQPE, min_teaching_ration=0, current_epoch=100)#phydnet
    # predRadarRes = G(inputRadarQPE) #wast

pred= predRadarRes #inputRadarQPE[:, -1, :] + predRadarRes
# pred= inputRadarQPE + predRadarRes
output = pred[0,:].cpu().data.numpy()
# all, 归一化除以了50
# csi15, pod15, far15 = csi_pod_far(output[:9,:], goldRadar[:9,:], 15/50)
# print('all 15: ', csi15, pod15, far15)
# csi20, pod20, far20 = csi_pod_far(output[:9,:], goldRadar[:9,:], 20/50)
# print('all 20: ', csi20, pod20, far20)
# csi30, pod30, far30 = csi_pod_far(output[:9,:], goldRadar[:9,:], 30/50)
# print('all 30: ', csi30, pod30, far30)
# csi35, pod35, far35 = csi_pod_far(output[:9,:], goldRadar[:9,:], 35/50)
# print('all 35: ', csi35, pod35, far35)

# csi15, pod15, far15 = csi_pod_far(np.max(output[:10, : ], 1),
#                                           np.max(goldRadar[:10, : ], 1), 15 / 50)
# print('CR 10 15: %.4f %.4f %.4f '%(csi15, pod15, far15))
# csi20, pod20, far20 = csi_pod_far(np.max(output[:10, :], 1),
#                                   np.max(goldRadar[:10, :], 1), 20 / 50)
# print('CR 10 20: %.4f %.4f %.4f '%(csi20, pod20, far20))
# csi30, pod30, far30 = csi_pod_far(np.max(output[:10, :], 1),
#                                   np.max(goldRadar[:10, :], 1), 30 / 50)
# print('CR 3km 30: %.4f %.4f %.4f '%(csi30, pod30, far30))
# csi35, pod35, far35 = csi_pod_far(np.max(output[:10, :], 1),
#                                   np.max(goldRadar[:10, :], 1), 35 / 50)
# print('CR 10 35: %.4f %.4f %.4f '%(csi35, pod35, far35))
# csi40, pod40, far40 = csi_pod_far(np.max(output[:10, :], 1),
#                                   np.max(goldRadar[:10, :], 1), 40 / 50)
# print('CR 10 40: %.4f %.4f %.4f '%(csi40, pod40, far40))


csi15, pod15, far15 = csi_pod_far(np.max(output[:, :], 1),
                                  np.max(goldRadar[:, :], 1), 15 / 50)
print('CR 20 15: %.4f %.4f %.4f '%(csi15, pod15, far15))
csi20, pod20, far20 = csi_pod_far(np.max(output[:, :], 1),
                                  np.max(goldRadar[:, :], 1), 20 / 50)
print('CR 20 20: %.4f %.4f %.4f '%(csi20, pod20, far20))
csi30, pod30, far30 = csi_pod_far(np.max(output[:, :], 1),
                                  np.max(goldRadar[:, :], 1), 30 / 50)
print('CR 20 30: %.4f %.4f %.4f '%(csi30, pod30, far30))
csi35, pod35, far35 = csi_pod_far(np.max(output[:, :], 1),
                                  np.max(goldRadar[:, :], 1), 35 / 50)
print('CR 20 35: %.4f %.4f %.4f '%(csi35, pod35, far35))
csi40, pod40, far40 = csi_pod_far(np.max(output[:, :], 1),
                                  np.max(goldRadar[:, :], 1), 40 / 50)
print('CR 20 40: %.4f %.4f %.4f '%(csi40, pod40, far40))

#save img
if not os.path.exists(save3kmRoot):
    os.mkdir(save3kmRoot)
for k in range(10):
    print('save : ', os.path.join(save3kmRoot,'gold_cmb_'+str(k)+'.tif'))
    plt_radar_show(goldRadar[k,0,:]*50,os.path.join(save3kmRoot,'gold_cmb_'+str(k)+'.tif'))
for k in range(10):
    print('save : ', os.path.join(save3kmRoot, 'pred_cmb_' + str(k) + '.tif'))
    plt_radar_show(output[k,0,:]*50,os.path.join(save3kmRoot,'pred_cmb_'+str(k)+'.tif'))
for k in range(10):
    print('save : ', os.path.join(save3kmRoot, 'input_cmb_' + str(k) + '.tif'))
    plt_radar_show(inputRadar[k,0,:]*50,os.path.join(save3kmRoot,'input_cmb_'+str(k)+'.tif'))
# visdomable = True
# env = 'ZhouUnetINcepDWRes2D-10to20'
# if visdomable == True:
#     logger = vis_tool.Visualizer(env=env)
#     logger.reinit(env=env)

# rawRadarQPE = inputRadarQPE.cpu()
# input0 = np.max(rawRadarQPE[0, 0, :, :].data.numpy(), axis=0)  # batch, time, channel+dem
# input0 = RestoreNetImg(input0, 0, 1)
# logger.img('0_input0', input0)
# input4 = np.max(rawRadarQPE[0, 4, :, :].data.numpy(), axis=0)  # batch, time, channel+dem
# input4 = RestoreNetImg(input4, 0, 1)
# logger.img('0_input4', input4)
# input9 = np.max(rawRadarQPE[0, 9, :, :].data.numpy(), axis=0)  # batch, time, channel+dem
# input9 = RestoreNetImg(input9, 0, 1)
# logger.img('0_input9', input9)
# # visThrev = 15 / 50
# goldRadarQPE = goldRadar
# gold0 = np.max(goldRadarQPE[0, :, :], axis=0)  # batch, time, channel
# # gold0[gold0 < visThrev] = 0
# gold0, max0, min0 = RestoreNetImg(gold0, 0, 1, returnFlag=True)
# logger.img('A_gold_00', gold0)
# gold4 = np.max(goldRadarQPE[4, :, :], axis=0)  # batch, time, channel
# # gold4[gold4 < visThrev] = 0
# gold4, max4, min4 = RestoreNetImg(gold4, 0, 1, returnFlag=True)
# logger.img('B_gold_04', gold4)
# gold9 = np.max(goldRadarQPE[ 9, :, :], axis=0)  # batch, time, channel
# # gold9[gold9 < visThrev] = 0
# gold9, max9, min9 = RestoreNetImg(gold9, 0, 1, returnFlag=True)
# logger.img('C_gold009', gold9)
#
# output0 = np.max(pred[0, 0, :, :].cpu().data.numpy(), axis=0)  # batch, time, channel+dem
# # output0[output0 < visThrev] = 0
# output0 = RestoreNetImg(output0, 0, 1, maxVal=max0, minVal=min0)
# logger.img('D_output_00', output0)
# output4 = np.max(pred[0, 4, :, :].cpu().data.numpy(), axis=0)  # batch, time, channel+dem
# # output4[output4 < visThrev] = 0
# output4 = RestoreNetImg(output4, 0, 1, maxVal=max4, minVal=min4)
# logger.img('E_output_04', output4)
# output9 = np.max(pred[0, 9, :, :].cpu().data.numpy(), axis=0)  # batch, time, channel+dem
# # output9[output9 < visThrev] = 0
# output9 = RestoreNetImg(output9, 0, 1, maxVal=max9, minVal=min9)
# logger.img('F_output_09', output9)
#
# gold0 = goldRadarQPE[0, 2, :]  # batch, time, channel
# # gold0[gold0 < visThrev] = 0
# # gold0,max0, min0 = RestoreNetImg(gold0, 0, 1, returnFlag=True)
# gold0 = RestoreNetImg(gold0, 0, 1, maxVal=max0, minVal=min0)
# logger.img('G_gold3KM00_2', gold0)
# gold4 = goldRadarQPE[4, 2, :]  # batch, time, channel
# # gold4[gold4 < visThrev] = 0
# # gold4,max4, min4 = RestoreNetImg(gold4, 0, 1, returnFlag=True)
# gold4 = RestoreNetImg(gold4, 0, 1, maxVal=max4, minVal=min4)
# logger.img('H_gold3KM04_2', gold4)
# gold9 = goldRadarQPE[9, 2, :]  # batch, time, channel
# # gold9[gold9 < visThrev] = 0
# # gold9,max9, min9 = RestoreNetImg(gold9, 0, 1, returnFlag=True)
# gold9 = RestoreNetImg(gold9, 0, 1, maxVal=max9, minVal=min9)
# logger.img('I_gold3KM09_2', gold9)
#
# output0 = pred[0, 0, 2, :].cpu().data.numpy()  # batch, time, channel+dem
# # output0[output0 < visThrev] = 0
# output0 = RestoreNetImg(output0, 0, 1, maxVal=max0, minVal=min0)
# logger.img('J_output3KM00_2', output0)
# output4 = pred[0, 4, 2, :].cpu().data.numpy()  # batch, time, channel+dem
# # output4[output4 < visThrev] = 0
# output4 = RestoreNetImg(output4, 0, 1, maxVal=max4, minVal=min4)
# logger.img('K_output3KM04_2', output4)
# output9 = pred[0, 9, 2, :].cpu().data.numpy()  # batch, time, channel+dem
# # output9[output9 < visThrev] = 0
# output9 = RestoreNetImg(output9, 0, 1, maxVal=max9, minVal=min9)
# logger.img('L_output3KM09_2', output9)



