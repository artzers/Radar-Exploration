import os, torch
import numpy as np
from torch.optim import lr_scheduler as lrs
from Util import RestoreNetImg
from My_loss import ZhouDDR,ZhouDDRRain
from torch.nn import functional as F
from model.UnetIncepDWRes import AllAttenModel,AllAttenModelRain
from model.UnetIncepDWRes_NWP_radar_lth_deeper import MultiModel
torch.autograd.set_detect_anomaly(True)

logger = None
lowMean =0
lowStd = 0
highMean =0
highStd = 0
globalMax = 0

device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")

def get_style_loss(f1,f2):
    #same size
    B,c,h,w = f1.size()
    f1 = f1.view(B*c,  h * w)
    gram1 = torch.mm(f1, f1.t())

    f2 = f2.view(B*c, h * w)
    gram2 = torch.mm(f2, f2.t())
    layer_style_loss = torch.mean((gram1 - gram2) ** 2)
    return layer_style_loss

def loss_hinge_disc(score_generated, score_real):
    """Discriminator hinge loss."""
    l1 = F.relu(1.0 - score_real)
    loss = torch.mean(l1)
    l2 = F.relu(1.0 + score_generated)
    loss += torch.mean(l2)
    return loss


def loss_hinge_gen(score_generated):
    """Generator hinge loss."""
    loss = -torch.mean(score_generated)
    return loss

def weights_init_normal(m):
    classname = m.__class__.__name__
    if classname.find("Conv3d") != -1:
        torch.nn.init.normal_(m.weight.data, 0.0, 0.02)
    elif classname.find("Conv2d") != -1:
        torch.nn.init.normal_(m.weight.data, 0.0, 0.02)
    elif classname.find("InstanceNorm2d") != -1:
        torch.nn.init.normal_(m.weight.data, 1.0, 0.02)
        torch.nn.init.constant_(m.bias.data, 0.0)
    elif classname.find("BatchNorm3d") != -1:
        torch.nn.init.normal_(m.weight.data, 1.0, 0.02)
        torch.nn.init.constant_(m.bias.data, 0.0)


class Trainer:
    def __init__(self,
                 data_loader,
                 test_loader,
                 scheduler=lrs.StepLR,
                 dev='cuda:0', devid=0):
        self.dataLoader = data_loader
        self.testLoader = test_loader
        self.dev = dev
        self.cudaid = devid

        # self.G = AllAttenModel(in_shape=[30, 3, 840, 840], in_rain_shape = [30, 1, 840, 840],
        #                hid_S=36*2, hid_T=64*2, N_T=6, N_S=2, #model_type='incepu',drop_path=0.0
        #                ).cuda(self.cudaid)
        self.G = MultiModel(in_shape=[30, 1, 840, 840], in_prep_shape = [30, 3, 840, 840],
                       hid_S=64, hid_T=128, N_T=6, N_S=4,
                       ).cuda(self.cudaid)
        G_lr = 0.0001  # 0.001
        eta_min = 0.00001
        # change weight 0.2*mtl
        self.criterion = ZhouDDR(l1flag=True).cuda(self.cudaid)#zhuyi
        # self.criterion = torch.nn.L1Loss(reduction='mean').cuda(self.cudaid)
        # self.criterionRain = ZhouDDRRain(l1flag=True).cuda(self.cudaid)#torch.nn.L1Loss(reduction='mean').cuda(self.cudaid)  # zhuyi
        self.G.load_state_dict(torch.load('./saved_models//mynet_56000.pth'))
        # self.R = AllAttenModelRain(in_shape=[30, 3, 840, 840], in_rain_shape = [30, 1, 840, 840],
        #                hid_S=36*2, hid_T=64*2, N_T=6, N_S=2,).cuda(self.cudaid)
        # self.R.load_state_dict(torch.load('./saved_models//mynetrain_24800.pth'))

        self.optimizer_G = torch.optim.Adam(self.G.parameters(), lr=G_lr)
        # self.optimizer_R = torch.optim.Adam(self.R.parameters(), lr=G_lr)
        # self.scheduler_G = scheduler(self.optimizer_G, step_size=10000, gamma=0.8, last_epoch=-1)#36000
        self.scheduler_G = lrs.CosineAnnealingLR(self.optimizer_G, T_max=100, eta_min=eta_min)
        # self.scheduler_R = lrs.CosineAnnealingLR(self.optimizer_R, T_max=100, eta_min=eta_min)

    def Train(self, turn=2):
        self.shot = -1
        torch.set_grad_enabled(True)
        torch.autograd.set_detect_anomaly(True)
        for t in range(turn):
            for kk, (rawRadar, goldRadar, rawRain,goldRain) in enumerate(self.dataLoader):  # ,residualQPE
                self.optimizer_G.zero_grad()
                # self.optimizer_D.zero_grad()
                # torch.cuda.empty_cache()
                self.shot = self.shot + 1

                inputRadar = rawRadar.cuda(self.cudaid)
                targetRadar = goldRadar.cuda(self.cudaid)
                inputRain = rawRain.cuda(self.cudaid)
                targetRain = goldRain.cuda(self.cudaid)

                # predRadar, radarHid = self.G(inputRadar)  # , predRain
                predRadar = self.G(inputRain,inputRadar )
                G_loss1 = self.criterion(predRadar, targetRadar)
                #下面不动，共用
                self.optimizer_G.zero_grad()
                G_loss1.backward()
                self.optimizer_G.step()
                self.scheduler_G.step()

                # radarHid = radarHid.detach()
                # predRain = self.R(inputRain, radarHid)
                # G_loss2 = self.criterionRain(predRain, targetRain)
                # self.optimizer_R.zero_grad()
                # G_loss2.backward()
                # self.optimizer_R.step()
                # self.scheduler_R.step()

                if self.shot % 5 == 0:

                    lr = self.scheduler_G.get_lr()[0]
                    # lrRain = self.scheduler_R.get_lr()[0]
                    # lossVal1 = float(G_loss1.cpu().data.numpy())
                    # lossVal2 = float(G_loss2.cpu().data.numpy())

                    # print("\r[Epoch %d] [Batch %d] [LR:%f %f] [G loss: %f %f]" % (
                    #     t,
                    #     self.shot,
                    #     lr, lrRain,
                    #     G_loss1.item(),
                    #     G_loss2.item()
                    # )
                    print("\r[Epoch %d] [Batch %d] [LR:%f ] [G loss: %f]" % (
                        t,
                        self.shot,
                        lr,
                        G_loss1.item(),
                    )
                          )

                    # input9 = np.max(raw[0,9,:].data.numpy(), axis=0) #batch, time, channel
                    # input9 = RestoreNetImg(input9,0,1)
                    # logger.img('input9', input9)
                    input0 = rawRadar[0, 0, 0, :].data.numpy()  # batch, time, channel+dem
                    input0 = RestoreNetImg(input0, 0, 1)
                    logger.img('0_inputRadar00', input0)
                    input4 = rawRadar[0, 15, 0, :].data.numpy()  # batch, time, channel+dem
                    input4 = RestoreNetImg(input4, 0, 1)
                    logger.img('0_inputRadar15', input4)
                    input9 = rawRadar[0, 29, 0, :].data.numpy()# batch, time, channel+dem
                    input9 = RestoreNetImg(input9, 0, 1)
                    logger.img('0_inputRadar29', input9)

                    input0 = rawRain[0, 0, 0, :].data.numpy()  # batch, time, channel+dem
                    input0 = RestoreNetImg(input0, 0, 1)
                    logger.img('0_inputRain0', input0)
                    input4 = rawRain[0, 15, 0, :].data.numpy()  # batch, time, channel+dem
                    input4 = RestoreNetImg(input4, 0, 1)
                    logger.img('0_inputRain15', input4)
                    input9 = rawRain[0, 29, 0, :].data.numpy()  # batch, time, channel+dem
                    input9 = RestoreNetImg(input9, 0, 1)
                    logger.img('0_inputRain29', input9)
                    # visThrev = 15 / 50

                    gold0 = goldRadar[0, 0, 0, :].data.numpy()  # batch, time, channel
                    # gold0[gold0 < visThrev] = 0
                    gold0,max0, min0 = RestoreNetImg(gold0, 0, 1, returnFlag=True)
                    # gold0 = RestoreNetImg(gold0, 0, 1, maxVal=max0, minVal=min0)
                    logger.img('G_goldRadar_00', gold0)
                    gold4 = goldRadar[0, 15, 0, :].data.numpy()  # batch, time, channel
                    # gold4[gold4 < visThrev] = 0
                    gold4,max4, min4 = RestoreNetImg(gold4, 0, 1, returnFlag=True)
                    # gold4 = RestoreNetImg(gold4, 0, 1, maxVal=max4, minVal=min4)
                    logger.img('G_goldRadar_15', gold4)
                    gold9 = goldRadar[0, 29, 0, :].data.numpy()  # batch, time, channel
                    # gold9[gold9 < visThrev] = 0
                    gold9,max9, min9 = RestoreNetImg(gold9, 0, 1, returnFlag=True)
                    # gold9 = RestoreNetImg(gold9, 0, 1, maxVal=max9, minVal=min9)
                    logger.img('G_goldRadar_29', gold9)

                    output0 = predRadar[0, 0, 0, :].cpu().data.numpy()  # batch, time, channel+dem
                    # output0[output0 < visThrev] = 0
                    output0 = RestoreNetImg(output0, 0, 1, maxVal=max0, minVal=min0)
                    logger.img('outputRadar_00', output0)
                    output4 = predRadar[0, 15, 0, :].cpu().data.numpy()  # batch, time, channel+dem
                    # output4[output4 < visThrev] = 0
                    output4 = RestoreNetImg(output4, 0, 1, maxVal=max4, minVal=min4)
                    logger.img('outputRadar_15', output4)
                    output9 = predRadar[0, 29, 0, :].cpu().data.numpy()  # batch, time, channel+dem
                    # output9[output9 < visThrev] = 0
                    output9 = RestoreNetImg(output9, 0, 1, maxVal=max9, minVal=min9)
                    logger.img('outputRadar_29', output9)

                    # gold0 = goldRain[0, 0, 0, :].data.numpy()  # batch, time, channel
                    # # gold0[gold0 < visThrev] = 0
                    # gold0, max0, min0 = RestoreNetImg(gold0, 0, 1, returnFlag=True)
                    # # gold0 = RestoreNetImg(gold0, 0, 1, maxVal=max0, minVal=min0)
                    # logger.img('G_goldRain_00', gold0)
                    # gold4 = goldRain[0, 15, 0, :].data.numpy()  # batch, time, channel
                    # # gold4[gold4 < visThrev] = 0
                    # gold4, max4, min4 = RestoreNetImg(gold4, 0, 1, returnFlag=True)
                    # # gold4 = RestoreNetImg(gold4, 0, 1, maxVal=max4, minVal=min4)
                    # logger.img('G_goldRain_15', gold4)
                    # gold9 = goldRain[0, 29, 0, :].data.numpy()  # batch, time, channel
                    # # gold9[gold9 < visThrev] = 0
                    # gold9, max9, min9 = RestoreNetImg(gold9, 0, 1, returnFlag=True)
                    # # gold9 = RestoreNetImg(gold9, 0, 1, maxVal=max9, minVal=min9)
                    # logger.img('G_goldRain_29', gold9)

                    # output0 = predRain[0, 0, 0, :].cpu().data.numpy()  # batch, time, channel+dem
                    # # output0[output0 < visThrev] = 0
                    # output0 = RestoreNetImg(output0, 0, 1, maxVal=max0, minVal=min0)#
                    # logger.img('outputRain_00', output0)
                    # output4 = predRain[0, 15, 0, :].cpu().data.numpy()  # batch, time, channel+dem
                    # output4[output4 < visThrev] = 0
                    # output4 = RestoreNetImg(output4, 0, 1, maxVal=max4, minVal=min4) #
                    # logger.img('outputRain_15', output4)
                    # output9 = predRain[0, 29, 0, :].cpu().data.numpy()  # batch, time, channel+dem
                    # # output9[output9 < visThrev] = 0
                    # output9 = RestoreNetImg(output9, 0, 1, maxVal=max9, minVal=min9) #
                    # logger.img('outputRain_29', output9)


                if self.shot != 0 and self.shot % 400 == 0:
                    if not os.path.exists('saved_models/'):
                        os.mkdir('saved_models/')
                    torch.save(self.G.state_dict(), "saved_models/mynet_%d.pth" % (self.shot+56000))
                    # torch.save(self.R.state_dict(), "saved_models/mynetrain_%d.pth" % (self.shot))



