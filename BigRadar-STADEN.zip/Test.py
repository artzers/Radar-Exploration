from vis import vis_tool
import os, torch
import numpy as np
from model.simvp import  *
import tifffile,datetime
from sebiao import plt_qpe_show, plt_radar_show
from computer_zhibiao import csi_pod_far
import datetime
from Util import RestoreNetImg
import tifffile
# from model.UnetIncepDWRes.UnetIncepDWRes import UnetIncepDWRes
# from model.wast import WaST
# from model.predrnnv2 import PredRNNv2
from Util_lth import TestGetRadarQPEDataSetAndCropCR
from torch.utils.data import DataLoader
import Net
#要改的地方
#phydnet
# G = PhyDNet(device ='cpu')
#predrnnv2
# G= PredRNNv2(device = 'cuda')
# G.hparams.scheduled_sampling = 0
# G.hparams.reverse_scheduled_sampling = 0
#simvp
# G = SimVP(in_shape=[10, 1, 480, 480],
#                        hiddem=32, hid_T=256, N_T=8, N_S=2, model_type='incepu',
#                        drop_path=0.0).cpu()  # simvp
#TAU
# G = SimVP(in_shape = [10,3,640,640],
#             hiddem=32, hid_T=96, N_T=4,N_S = 2, model_type = 'tau',
#             drop_path = 0.0 ).cpu() #TAU
# G = SimVP(in_shape = [10,1,480,480],
#             hiddem=32, hid_T=256, N_T=8,N_S = 2, model_type = 'tau',
#             drop_path = 0.0 ).cpu()
#MS UnetIncepDWRes
# G = UnetIncepDWRes(n_channels = 3, n_classes = 3).cpu()
#wast
# G = WaST(device = 'cpu', in_shape = [10,3,640,640],encoder_dim=6, block_list=[1, 2, 1], drop_path_rate=0.25, mlp_ratio=2.)

##################################
def output_csi_pod_far(output, goldRadar):
    # 定义阈值列表
    thresholds = [15, 20, 30, 35, 40]

    # 准备空列表，存放当前这一个 Batch 的 5 个阈值结果
    batch_csi = []
    batch_pod = []
    batch_far = []

    # 预处理数据 (提取最大值)
    output_max = np.max(output[:, :], 1)
    gold_max = np.max(goldRadar[:, :], 1)

    # 循环计算每个阈值
    for th in thresholds:
        # 调用你的计算函数 (注意这里除以 50.0 保持浮点数)
        c, p, f = csi_pod_far(output_max, gold_max, th / 50.0)

        # 打印 (保持你原有的打印习惯)
        print('CR 20 %d: %.4f %.4f %.4f' % (th, c, p, f))

        # 将结果添加到列表
        batch_csi.append(c)
        batch_pod.append(p)
        batch_far.append(f)

    # 【关键】返回这三个列表
    return batch_csi, batch_pod, batch_far
CRRoot = r'E:\20260120省台雷达\2025\2025年CREF/'
QRRoot = r'E:\20260120省台雷达\2025\2025年QREF/'
VILRoot = r'E:\20260120省台雷达\2025\2025年VIL/'
RainRoot = r'E:\20260120省台雷达\2025\2025年QPR/'
trainList3 = 'ValidSequence_2023-2024.txt'
trainList4 = 'trainList_120_2025.txt'
save_dir = "./result_lth/"
# lth code
# model instacne
from model.UnetIncepDWRes_NWP_radar_lth_deeper import MultiModel
G = MultiModel(in_shape=[30, 1, 840, 840], in_prep_shape=[30, 3, 840, 840],
                    hid_S=64, hid_T=128, N_T=6, N_S=4,
                    )
# load model state
G.load_state_dict(torch.load(r'E:\20260120省台雷达\2324project\saved_models\mynet_73600.pth', map_location=torch.device('cuda')))
G.eval()
# dataloader
Test_dataset = TestGetRadarQPEDataSetAndCropCR(CRRoot, QRRoot, VILRoot, RainRoot,
                                            trainList3, trainList4
                                            )
Test_loader = DataLoader(Test_dataset, batch_size=1, shuffle=False, num_workers=0)
total_csi_list = []
total_pod_list = []
total_far_list = []
all_preds = []
all_golds = []
for i, (inputRadar, goldRadar , inputRain,goldRain) in enumerate(Test_loader):
    predRadar = G(inputRain,inputRadar )
    predRadar = predRadar.detach().numpy()
    goldRadar = goldRadar.detach().numpy()
    filename = Test_dataset._get_timeseris()
    # 2. 将当前批次结果加入列表
    # all_preds.append(predRadar)
    # all_golds.append(goldRadar)
    if not os.path.exists(save_dir):
        os.makedirs(save_dir,exist_ok=True)

    np.save(os.path.join(save_dir, f'{filename}_InRadar.npy'), inputRadar)
    np.save(os.path.join(save_dir, f'{filename}_PredictRadar.npy'), predRadar)
    np.save(os.path.join(save_dir, f'{filename}_TargetRadar.npy'), goldRadar)
    print(f"save sucessful dir:{save_dir}")
    # --- 2. 调用函数，并接收返回的列表 ---
    # b_csi, b_pod, b_far 都是包含 5 个值的列表 (对应 5 个阈值)
    b_csi, b_pod, b_far = output_csi_pod_far(predRadar, goldRadar)

    # --- 3. 将当前批次的结果添加到总列表中 ---
    total_csi_list.append(b_csi)
    total_pod_list.append(b_pod)
    total_far_list.append(b_far)

# --- 循环结束 ---

# --- 4. 计算并输出总平均 ---
# 将列表转换为 numpy 数组，形状通常是 (Batch数量, 5)
# axis=0 表示沿着“批次”方向求平均，这样你会得到每个阈值的平均分
avg_csi_per_threshold = np.mean(np.array(total_csi_list), axis=0)
avg_pod_per_threshold = np.mean(np.array(total_pod_list), axis=0)
avg_far_per_threshold = np.mean(np.array(total_far_list), axis=0)

print("\n========== Final Evaluation Results ==========")
thresholds = [15, 20, 30, 35, 40]

# 输出每个阈值的平均分
for idx, th in enumerate(thresholds):
    print('Threshold %d Average -> CSI: %.4f, POD: %.4f, FAR: %.4f' % (
        th,
        avg_csi_per_threshold[idx],
        avg_pod_per_threshold[idx],
        avg_far_per_threshold[idx]
    ))

# # axis=0 表示在第一个维度（样本数）上拼接
# final_preds = np.concatenate(all_preds, axis=0)
# final_golds = np.concatenate(all_golds, axis=0)
#
# # 4. 保存为 .npy 文件
# np.save('final_prediction.npy', final_preds)
# np.save('final_ground_truth.npy', final_golds)

# print("保存完成！")
# print(f"预测结果形状: {final_preds.shape}")
# print(f"真实结果形状: {final_golds.shape}")







##################################

#要改的地方
# G.load_state_dict(torch.load('./saved_models//phydnet_500.pth', map_location=torch.device('cpu')))
# G.load_state_dict(torch.load('./saved_models//predrnnv2_500.pth', map_location=torch.device('cpu')))
# G.load_state_dict(torch.load('./saved_models//simvp_40500.pth', map_location=torch.device('cpu')))
# G.load_state_dict(torch.load('./saved_models_tau_old_weight//tau_134500.pth', map_location=torch.device('cpu')))
# G.load_state_dict(torch.load('./saved_models//UnetIncepDWRes_500.pth', map_location=torch.device('cpu')))
# G.load_state_dict(torch.load('./saved_models//wast_500.pth', map_location=torch.device('cpu')))

# G = G.eval()
#
# #要改的地方
# yearID = 2020#2020#2021#
# ind = 0
#
# radarRoot = 'D:/外推数据/swan/zhou_CR/'
# # radarRoot = 'E:/外推数据/swan/zhou_Combine/'
#
# radarYearDir = os.path.join(radarRoot, str(yearID))
#
# #要改的地方
# beginTimeStr = '202008110342'
# #202108170100'#'202007251906'#'202204111306'#"202007142106"#"202108251906"#"202108252206"#"202308061206"#"202309111906"#
# dt = datetime.datetime.strptime(beginTimeStr, '%Y%m%d%H%M')
# curDt = dt #+ datetime.timedelta(minutes=60)
# curDt = curDt.strftime("%Y%m%d%H%M")
# # saveQPERoot = './result_QPE/yubao_%s/'%(curDt)
# save3kmRoot = './result_3km/yubao_%s/'%(curDt)
# # radarChannel = [1,3,5]#[1,3,5,7,9]
#
# inputRadar = np.zeros((10, 1, 480,480), dtype = np.float32)
# goldRadar = np.zeros((10, 1, 480,480), dtype=np.float32)
# # inputQPE = np.zeros((10, 1, 896, 1024), dtype=np.float32)
# # goldQPE = np.zeros((10, 1, 896,1024), dtype=np.float32)
# for k in range(10):
#     curDt = dt + datetime.timedelta(minutes=12 * k)
#     curDt = curDt.strftime("%Y%m%d%H%M")
#
#     radarFile = os.path.join(radarYearDir,
#                              'CR_%s' % (curDt)
#                              + '.tif')
#     curRadar = tifffile.imread(radarFile)[180:660, 740:1220]
#     curRadar = curRadar.astype(float) / 50.  # uint8，没有负数
#     inputRadar[k, :, :] = curRadar  # 896,1024
#
# for k in range(10, 20):
#     curDt = dt + datetime.timedelta(minutes=12 * k)
#     curDt = curDt.strftime("%Y%m%d%H%M")
#     radarFile = os.path.join(radarYearDir,
#                              'CR_%s' % (curDt)
#                              + '.tif')
#     curRadar = tifffile.imread(radarFile)[180:660, 740:1220]
#     curRadar = curRadar.astype(float) / 50.  # uint8，没有负数
#     goldRadar[k - 10, :, :] = curRadar  # 896,1024
#
# # print(np.sum(inputRadar>30/50))
#
# inputRadarQPE = torch.from_numpy(inputRadar.copy()).float()
# goldRadarQPE = torch.from_numpy(goldRadar.copy()).float()
# inputRadarQPE = torch.unsqueeze(inputRadarQPE, dim=0)
# goldRadarQPE = torch.unsqueeze(goldRadarQPE, dim=0)
# # inputRadarQPE = inputRadarQPE.cuda(0)
#
# pred = None
# #要改的地方
# with torch.no_grad(): #注意看应该是那个网络
#     # predRadarRes = G.training_step(inputRadarQPE, goldRadarQPE, globalStep=0)
#     # predRadarRes = G.train_forward(inputRadarQPE) #UnetIncepDWRes专用
#     predRadarRes = G(inputRadarQPE) #simvp,tau
#     # predRadarRes, _ = G.training_step(inputRadarQPE, goldRadarQPE, min_teaching_ration=0, current_epoch=100)#phydnet
#     # predRadarRes = G(inputRadarQPE) #wast
#
# pred= predRadarRes #inputRadarQPE[:, -1, :] + predRadarRes
# # pred= inputRadarQPE + predRadarRes
# output = pred[0,:].cpu().data.numpy()
# # all, 归一化除以了50
# # csi15, pod15, far15 = csi_pod_far(output[:9,:], goldRadar[:9,:], 15/50)
# # print('all 15: ', csi15, pod15, far15)
# # csi20, pod20, far20 = csi_pod_far(output[:9,:], goldRadar[:9,:], 20/50)
# # print('all 20: ', csi20, pod20, far20)
# # csi30, pod30, far30 = csi_pod_far(output[:9,:], goldRadar[:9,:], 30/50)
# # print('all 30: ', csi30, pod30, far30)
# # csi35, pod35, far35 = csi_pod_far(output[:9,:], goldRadar[:9,:], 35/50)
# # print('all 35: ', csi35, pod35, far35)
#
# # csi15, pod15, far15 = csi_pod_far(np.max(output[:10, : ], 1),
# #                                           np.max(goldRadar[:10, : ], 1), 15 / 50)
# # print('CR 10 15: %.4f %.4f %.4f '%(csi15, pod15, far15))
# # csi20, pod20, far20 = csi_pod_far(np.max(output[:10, :], 1),
# #                                   np.max(goldRadar[:10, :], 1), 20 / 50)
# # print('CR 10 20: %.4f %.4f %.4f '%(csi20, pod20, far20))
# # csi30, pod30, far30 = csi_pod_far(np.max(output[:10, :], 1),
# #                                   np.max(goldRadar[:10, :], 1), 30 / 50)
# # print('CR 3km 30: %.4f %.4f %.4f '%(csi30, pod30, far30))
# # csi35, pod35, far35 = csi_pod_far(np.max(output[:10, :], 1),
# #                                   np.max(goldRadar[:10, :], 1), 35 / 50)
# # print('CR 10 35: %.4f %.4f %.4f '%(csi35, pod35, far35))
# # csi40, pod40, far40 = csi_pod_far(np.max(output[:10, :], 1),
# #                                   np.max(goldRadar[:10, :], 1), 40 / 50)
# # print('CR 10 40: %.4f %.4f %.4f '%(csi40, pod40, far40))
#
#
# #save img
# if not os.path.exists(save3kmRoot):
#     os.mkdir(save3kmRoot)
# for k in range(10):
#     print('save : ', os.path.join(save3kmRoot,'gold_cmb_'+str(k)+'.tif'))
#     plt_radar_show(goldRadar[k,0,:]*50,os.path.join(save3kmRoot,'gold_cmb_'+str(k)+'.tif'))
# for k in range(10):
#     print('save : ', os.path.join(save3kmRoot, 'pred_cmb_' + str(k) + '.tif'))
#     plt_radar_show(output[k,0,:]*50,os.path.join(save3kmRoot,'pred_cmb_'+str(k)+'.tif'))
# for k in range(10):
#     print('save : ', os.path.join(save3kmRoot, 'input_cmb_' + str(k) + '.tif'))
#     plt_radar_show(inputRadar[k,0,:]*50,os.path.join(save3kmRoot,'input_cmb_'+str(k)+'.tif'))
# # visdomable = True
# # env = 'ZhouUnetINcepDWRes2D-10to20'
# # if visdomable == True:
# #     logger = vis_tool.Visualizer(env=env)
# #     logger.reinit(env=env)
#
# # rawRadarQPE = inputRadarQPE.cpu()
# # input0 = np.max(rawRadarQPE[0, 0, :, :].data.numpy(), axis=0)  # batch, time, channel+dem
# # input0 = RestoreNetImg(input0, 0, 1)
# # logger.img('0_input0', input0)
# # input4 = np.max(rawRadarQPE[0, 4, :, :].data.numpy(), axis=0)  # batch, time, channel+dem
# # input4 = RestoreNetImg(input4, 0, 1)
# # logger.img('0_input4', input4)
# # input9 = np.max(rawRadarQPE[0, 9, :, :].data.numpy(), axis=0)  # batch, time, channel+dem
# # input9 = RestoreNetImg(input9, 0, 1)
# # logger.img('0_input9', input9)
# # # visThrev = 15 / 50
# # goldRadarQPE = goldRadar
# # gold0 = np.max(goldRadarQPE[0, :, :], axis=0)  # batch, time, channel
# # # gold0[gold0 < visThrev] = 0
# # gold0, max0, min0 = RestoreNetImg(gold0, 0, 1, returnFlag=True)
# # logger.img('A_gold_00', gold0)
# # gold4 = np.max(goldRadarQPE[4, :, :], axis=0)  # batch, time, channel
# # # gold4[gold4 < visThrev] = 0
# # gold4, max4, min4 = RestoreNetImg(gold4, 0, 1, returnFlag=True)
# # logger.img('B_gold_04', gold4)
# # gold9 = np.max(goldRadarQPE[ 9, :, :], axis=0)  # batch, time, channel
# # # gold9[gold9 < visThrev] = 0
# # gold9, max9, min9 = RestoreNetImg(gold9, 0, 1, returnFlag=True)
# # logger.img('C_gold009', gold9)
# #
# # output0 = np.max(pred[0, 0, :, :].cpu().data.numpy(), axis=0)  # batch, time, channel+dem
# # # output0[output0 < visThrev] = 0
# # output0 = RestoreNetImg(output0, 0, 1, maxVal=max0, minVal=min0)
# # logger.img('D_output_00', output0)
# # output4 = np.max(pred[0, 4, :, :].cpu().data.numpy(), axis=0)  # batch, time, channel+dem
# # # output4[output4 < visThrev] = 0
# # output4 = RestoreNetImg(output4, 0, 1, maxVal=max4, minVal=min4)
# # logger.img('E_output_04', output4)
# # output9 = np.max(pred[0, 9, :, :].cpu().data.numpy(), axis=0)  # batch, time, channel+dem
# # # output9[output9 < visThrev] = 0
# # output9 = RestoreNetImg(output9, 0, 1, maxVal=max9, minVal=min9)
# # logger.img('F_output_09', output9)
# #
# # gold0 = goldRadarQPE[0, 2, :]  # batch, time, channel
# # # gold0[gold0 < visThrev] = 0
# # # gold0,max0, min0 = RestoreNetImg(gold0, 0, 1, returnFlag=True)
# # gold0 = RestoreNetImg(gold0, 0, 1, maxVal=max0, minVal=min0)
# # logger.img('G_gold3KM00_2', gold0)
# # gold4 = goldRadarQPE[4, 2, :]  # batch, time, channel
# # # gold4[gold4 < visThrev] = 0
# # # gold4,max4, min4 = RestoreNetImg(gold4, 0, 1, returnFlag=True)
# # gold4 = RestoreNetImg(gold4, 0, 1, maxVal=max4, minVal=min4)
# # logger.img('H_gold3KM04_2', gold4)
# # gold9 = goldRadarQPE[9, 2, :]  # batch, time, channel
# # # gold9[gold9 < visThrev] = 0
# # # gold9,max9, min9 = RestoreNetImg(gold9, 0, 1, returnFlag=True)
# # gold9 = RestoreNetImg(gold9, 0, 1, maxVal=max9, minVal=min9)
# # logger.img('I_gold3KM09_2', gold9)
# #
# # output0 = pred[0, 0, 2, :].cpu().data.numpy()  # batch, time, channel+dem
# # # output0[output0 < visThrev] = 0
# # output0 = RestoreNetImg(output0, 0, 1, maxVal=max0, minVal=min0)
# # logger.img('J_output3KM00_2', output0)
# # output4 = pred[0, 4, 2, :].cpu().data.numpy()  # batch, time, channel+dem
# # # output4[output4 < visThrev] = 0
# # output4 = RestoreNetImg(output4, 0, 1, maxVal=max4, minVal=min4)
# # logger.img('K_output3KM04_2', output4)
# # output9 = pred[0, 9, 2, :].cpu().data.numpy()  # batch, time, channel+dem
# # # output9[output9 < visThrev] = 0
# # output9 = RestoreNetImg(output9, 0, 1, maxVal=max9, minVal=min9)
# # logger.img('L_output3KM09_2', output9)
#
#
#
