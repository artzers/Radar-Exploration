import os, torch
import numpy as np
from torch import nn

import h5py
import datetime
import tifffile
from Util import GetRadarQPEDataSetAndCropCR

def prepare(dev, *args):
    # print(dev)
    device = torch.device(dev)
    if dev == 'cpu':
        device = torch.device('cpu')
    return [a.to(device) for a in args]


def calc_psnr(sr, hr, scale):
    diff = (sr - hr)
    # shave = scale + 6
    # valid = diff[..., shave:-shave, shave:-shave,:]#2，2，1
    # mse = valid.pow(2).mean()
    mse = np.mean(diff * diff) + 0.0001
    return -10 * np.log10(mse / (4095 ** 2))


def RestoreNetImg(img, mean, max, returnFlag = False, maxVal = None, minVal = None):
    # rImg = (img - self.mean1) / self.std1
    #rImg = np.maximum(np.minimum(img * max + mean, 255), 0)
    rImg = img * max + mean
    if maxVal is None:
        maxVal = np.max(rImg)*0.9
    if minVal is None:
        minVal = np.min(rImg)
    rImg = 255./(maxVal - minVal+0.001) * (rImg - minVal)
    rImg = np.maximum(np.minimum(rImg, 255), 0)
    if returnFlag:
        return rImg, maxVal, minVal
    else:
        return rImg

def RestoreNetImgV2(img, mean, max):
    # rImg = (img - self.mean1) / self.std1
    #rImg = np.maximum(np.minimum(img * max + mean, 255), 0)
    rImg = img * max + mean
    rImg = np.maximum(np.minimum(rImg, 255), 0)
    return rImg


class TestGetRadarQPEDataSetAndCropCR(GetRadarQPEDataSetAndCropCR):
    def __init__(self, CRRoot,QRRoot, VILRoot,RainRoot, trainList3,trainList4,
                 # epoch,
        CRRoot1 = None,QRRoot1 = None,VILRoot1 = None,RainRoot1 = None
                 ):
        super().__init__(CRRoot,QRRoot, VILRoot,RainRoot, trainList3,trainList4,epoch = 100)
        self.interval = 60
        self.beginTimeStr = None
    def __len__(self):
        return int(len(self.trainSeriesListStep4) // 60)

    def __getitem__(self, idx):
        self.trainSeriesListStep4
        print("train",idx)
        print(self.trainSeriesListStep4[idx * self.interval],self.trainSeriesListStep4[idx])

        beginTimeStr = self.trainSeriesListStep4[idx * self.interval]
        self.beginTimeStr = beginTimeStr
        # self.interval += 60
        print("test",beginTimeStr)
        return self.mygetitem(beginTimeStr)

    def _get_timeseris(self):
        return self.beginTimeStr
