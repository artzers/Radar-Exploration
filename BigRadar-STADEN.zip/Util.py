import os, torch
import numpy as np
from torch import nn

import h5py
import datetime
import tifffile


def prepare(dev, *args):
    # print(dev)
    device = torch.device(dev)
    if dev == 'cpu':
        device = torch.device('cpu')
    return [a.to(device) for a in args]


def calc_psnr(sr, hr, scale):
    diff = (sr - hr)
    # shave = scale + 6
    # valid = diff[..., shave:-shave, shave:-shave,:]#2，2，1
    # mse = valid.pow(2).mean()
    mse = np.mean(diff * diff) + 0.0001
    return -10 * np.log10(mse / (4095 ** 2))


def RestoreNetImg(img, mean, max, returnFlag = False, maxVal = None, minVal = None):
    # rImg = (img - self.mean1) / self.std1
    #rImg = np.maximum(np.minimum(img * max + mean, 255), 0)
    rImg = img * max + mean
    if maxVal is None:
        maxVal = np.max(rImg)*0.9
    if minVal is None:
        minVal = np.min(rImg)
    rImg = 255./(maxVal - minVal+0.001) * (rImg - minVal)
    rImg = np.maximum(np.minimum(rImg, 255), 0)
    if returnFlag:
        return rImg, maxVal, minVal
    else:
        return rImg

def RestoreNetImgV2(img, mean, max):
    # rImg = (img - self.mean1) / self.std1
    #rImg = np.maximum(np.minimum(img * max + mean, 255), 0)
    rImg = img * max + mean
    rImg = np.maximum(np.minimum(rImg, 255), 0)
    return rImg


class GetRadarQPEDataSetAndCropCR:
    def __init__(self, CRRoot,QRRoot, VILRoot,RainRoot, trainList3,trainList4,
                 epoch,
        CRRoot1 = None,QRRoot1 = None,VILRoot1 = None,RainRoot1 = None
                 ):
        self.CRRoot = CRRoot
        self.QRRoot = QRRoot
        self.VILRoot = VILRoot
        self.RainRoot = RainRoot

        self.CRRoot1 = CRRoot1
        self.QRRoot1 = QRRoot1
        self.VILRoot1 = VILRoot1
        self.RainRoot1 = RainRoot1

        self.trainList3 = trainList3
        self.trainList4 = trainList4
        self.epoch = epoch

        self.trainSeriesListStep3 = []
        self.trainSeriesListStep4 = []
        with open(trainList3, 'r') as f:
            lines = f.readlines()
            for line in lines:
                self.trainSeriesListStep3.append(line.strip()[:-2])

        with open(trainList4, 'r') as f:
            lines = f.readlines()
            for line in lines:
                self.trainSeriesListStep4.append(line.strip()[:-2])
        self.inputRadar = None
        self.goldRadar = None
        self.inputRain = None
        self.goldRain = None
        self.step4Flag = False
        self.threvFlag4 = 0.8#0.985 #要改的地方
        self.threvFlag4to3 = 0.25  # 0.25 #要改的地方
        self.ind = -1
        self.firstName = ''

    def __len__(self):
        return self.epoch

    def len(self):
        return self.epoch

    def __getitem__(self, hehe):
        if not self.step4Flag: #必须换新数据
            if np.random.rand() < self.threvFlag4to3: #还是step3
                self.ind = np.random.randint(len(self.trainSeriesListStep3))
                beginTimeStr = self.trainSeriesListStep3[self.ind]
                self.step4Flag = False
                print('step3')
                return self.mygetitem(beginTimeStr)
            else: #换step4
                self.ind = np.random.randint(len(self.trainSeriesListStep4))
                beginTimeStr = self.trainSeriesListStep4[self.ind]
                self.step4Flag = True
                print('step4')
                return self.mygetitem(beginTimeStr)
        else: #上一个是step4
            if np.random.rand() < self.threvFlag4 and self.inputRadar is not None:#继续用
                return self.inputRadar, self.goldRadar  , self.inputRain, self.goldRain
            else: #换别的
                if np.random.rand() < self.threvFlag4to3:  # 用step3
                    self.ind = np.random.randint(len(self.trainSeriesListStep3))
                    beginTimeStr = self.trainSeriesListStep3[self.ind]
                    self.step4Flag = False
                    print('step3')
                    return self.mygetitem(beginTimeStr)
                else: #用step4
                    self.ind = np.random.randint(len(self.trainSeriesListStep4))
                    beginTimeStr = self.trainSeriesListStep4[self.ind]
                    self.step4Flag = True
                    print('step4')
                    return self.mygetitem(beginTimeStr)

    def mygetitem(self,beginTimeStr):
        # print(beginTimeStr)
        dt = datetime.datetime.strptime(beginTimeStr, '%Y%m%d%H%M')
        self.firstName =  dt.strftime("%Y%m%d%H%M")
        print(self.firstName)

        self.inputRadar = np.zeros((30, 3, 840, 840), dtype=np.float32)
        self.inputRain = np.zeros((30, 1, 840, 840), dtype=np.float32)
        self.goldRadar = np.zeros((30, 1, 840,840), dtype=np.float32)
        self.goldRain = np.zeros((30, 1, 840,840), dtype=np.float32)
        for k in range(30):
            curDt = dt + datetime.timedelta(minutes=6 * k)
            curDt = curDt.strftime("%Y%m%d%H%M")
            crFile = os.path.join(self.CRRoot, \
                                  'Z_RADA_C_BABJ_%s' % (curDt) \
                                  + '_CREF.h5')
            if not os.path.exists(crFile):
                print("changed path")
                crFile = os.path.join(self.CRRoot1, \
                                      'Z_RADA_C_BABJ_%s' % (curDt) \
                                      + '_CREF.h5')
                qrFile = os.path.join(self.QRRoot1, \
                                      'Z_RADA_C_BABJ_%s' % (curDt) \
                                      + '_QREF.h5')
                vilFile = os.path.join(self.VILRoot1, \
                                       'Z_RADA_C_BABJ_%s' % (curDt) \
                                       + '_VIL.h5')
                rainFile = os.path.join(self.RainRoot1, \
                                        'Z_RADA_C_BABJ_%s' % (curDt) \
                                        + '_QPR.h5')
            else:
                qrFile = os.path.join(self.QRRoot, \
                                      'Z_RADA_C_BABJ_%s' % (curDt) \
                                      + '_QREF.h5')
                vilFile = os.path.join(self.VILRoot, \
                                       'Z_RADA_C_BABJ_%s' % (curDt) \
                                       + '_VIL.h5')
                rainFile = os.path.join(self.RainRoot, \
                                        'Z_RADA_C_BABJ_%s' % (curDt) \
                                        + '_QPR.h5')
            fcr = h5py.File(crFile, 'r')
            fqr = h5py.File(qrFile, 'r')
            fvil = h5py.File(vilFile, 'r')
            frain = h5py.File(rainFile, 'r')
            self.inputRadar[k,0, :, :] = fcr['CREF'][328:1168,205:1045]/50  # 896,1024
            self.inputRadar[k, 1, :, :] = fqr['QREF'][328 :1168, 205 :1045]/50
            self.inputRadar[k, 2, :, :] = fvil['VIL'][328:1168, 205:1045]

            self.inputRain[k,:] = frain['QPR'][328 :1168, 205 :1045]
        self.inputRadar[self.inputRadar<0] = 0.

        for k in range(30,60):
            curDt = dt + datetime.timedelta(minutes=6 * k)
            curDt = curDt.strftime("%Y%m%d%H%M")
            crFile = os.path.join(self.CRRoot, \
                                  'Z_RADA_C_BABJ_%s' % (curDt) \
                                  + '_CREF.h5')
            if not os.path.exists(crFile):
                # print("changed path")
                crFile = os.path.join(self.CRRoot1, \
                                      'Z_RADA_C_BABJ_%s' % (curDt) \
                                      + '_CREF.h5')
                qrFile = os.path.join(self.QRRoot1, \
                                      'Z_RADA_C_BABJ_%s' % (curDt) \
                                      + '_QREF.h5')
                vilFile = os.path.join(self.VILRoot1, \
                                       'Z_RADA_C_BABJ_%s' % (curDt) \
                                       + '_VIL.h5')
                rainFile = os.path.join(self.RainRoot1, \
                                        'Z_RADA_C_BABJ_%s' % (curDt) \
                                        + '_QPR.h5')
            else:
                qrFile = os.path.join(self.QRRoot, \
                                      'Z_RADA_C_BABJ_%s' % (curDt) \
                                      + '_QREF.h5')
                vilFile = os.path.join(self.VILRoot, \
                                       'Z_RADA_C_BABJ_%s' % (curDt) \
                                       + '_VIL.h5')
                rainFile = os.path.join(self.RainRoot, \
                                        'Z_RADA_C_BABJ_%s' % (curDt) \
                                        + '_QPR.h5')
            fcr = h5py.File(crFile, 'r')
            frain = h5py.File(rainFile, 'r')
            self.goldRadar[k-30, :, :] = fcr['CREF'][328:1168, 205:1045] / 50  # 896,1024
            self.goldRain[k-30, :] = frain['QPR'][328:1168, 205:1045]
        self.goldRadar[self.goldRadar < 0] = 0.
        self.goldRain[self.goldRain < 0] = 0.

        self.inputRadar = torch.from_numpy(self.inputRadar.copy()).float()
        self.goldRadar = torch.from_numpy(self.goldRadar.copy()).float()

        self.inputRain = torch.from_numpy(self.inputRain.copy()).float()
        self.goldRain = torch.from_numpy(self.goldRain.copy()).float()

        return self.inputRadar, self.goldRadar , self.inputRain,self.goldRain