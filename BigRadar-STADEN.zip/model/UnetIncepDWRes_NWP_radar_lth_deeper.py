""" Full assembly of the parts to form the complete network """
import torch
import math
import torch.nn as nn
# from torchinfo import summary
from model.unet_parts import *
# from model.Translator import *
# from modules.cbam import *
import torch.nn.functional as F
from einops import rearrange

from modules import (ConvSC, ConvNeXtSubBlock, ConvMixerSubBlock, GASubBlock, gInception_ST,
                             HorNetSubBlock, MLPMixerSubBlock, MogaSubBlock, PoolFormerSubBlock,
                             SwinSubBlock, UniformerSubBlock, VANSubBlock, ViTSubBlock, TAUSubBlock)


class TemporalMixer(nn.Module):
    def __init__(self, channel_in, channel_hid, N_T):
        super(TemporalMixer, self).__init__()
        self.N_T = N_T
        res_layers = []
        res_layers.append(nn.Conv2d(in_channels=channel_in, out_channels=channel_hid, kernel_size=1))
        res_layers.append(nn.LeakyReLU(inplace=True))
        for i in range(1,N_T-1):
            res_layers.append(nn.Conv2d(in_channels=channel_hid, out_channels=channel_hid, kernel_size=1))
            res_layers.append(nn.LeakyReLU(inplace=True))
        res_layers.append(nn.InstanceNorm2d(channel_hid))
        res_layers.append(nn.Conv2d(in_channels=channel_in, out_channels=channel_hid, kernel_size=1))
        res_layers.append(nn.LeakyReLU(inplace=True))

        self.translator = nn.Sequential(*res_layers)

    def forward(self, x):
        B, CT, H, W = x.shape

        z = x
        z = self.translator(z)
        """需修改"""
        # out_t = 10  # 输出的序列长度
        z = z + x
        y = z.reshape(B, CT, H, W)
        return y


class TemporalAttentionModule(nn.Module):
    """Large Kernel Attention for SimVP"""

    def __init__(self, dim, kernel_size,dilation=3,  reduction=2): #16
        super().__init__()
        d_k = 2 * dilation - 1
        d_p = (d_k - 1) // 2
        dd_k = kernel_size // dilation + ((kernel_size // dilation) % 2 - 1)
        dd_p = (dilation * (dd_k - 1) // 2)

        self.conv0 = nn.Conv2d(dim, dim, d_k, padding=d_p, groups=dim)
        self.conv_spatial = nn.Conv2d(
            dim, dim, dd_k, stride=1, padding=dd_p, groups=dim, dilation=dilation)
        # self.conv_time = TemporalMixer(dim, dim,3)
        self.conv1 = nn.Conv2d(dim, dim, 1)

        self.reduction = max(dim // reduction, 4)
        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        self.fc = nn.Sequential(
            nn.Linear(dim, dim // self.reduction, bias=False), # reduction
            nn.ReLU(True),
            nn.Linear(dim // self.reduction, dim, bias=False), # expansion
            nn.Sigmoid()
        )

    def forward(self, x):
        u = x.clone()
        attn = self.conv0(x)           # depth-wise conv
        attn = self.conv_spatial(attn) # depth-wise dilation convolution
        # attn = self.conv_time(attn)
        f_x = self.conv1(attn)    # 1x1 conv
        # append a se operation
        b, c, _, _ = x.size()
        se_atten = self.avg_pool(x).view(b, c)
        se_atten = self.fc(se_atten).view(b, c, 1, 1)
        return se_atten * f_x * u


class AttentionModule(nn.Module):
    """Large Kernel Attention for SimVP"""

    def __init__(self, dim, kernel_size, dilation=3):
        super().__init__()
        d_k = 2 * dilation - 1
        d_p = (d_k - 1) // 2
        dd_k = kernel_size // dilation + ((kernel_size // dilation) % 2 - 1)
        dd_p = (dilation * (dd_k - 1) // 2)

        self.conv0 = nn.Conv2d(dim, dim, d_k, padding=d_p, groups=dim)
        self.conv_spatial = nn.Conv2d(
            dim, dim, dd_k, stride=1, padding=dd_p, groups=dim, dilation=dilation)
        self.conv1 = nn.Conv2d(dim, 2 * dim, 1)

    def forward(self, x):
        u = x.clone()
        attn = self.conv0(x)  # depth-wise conv
        attn = self.conv_spatial(attn)  # depth-wise dilation convolution

        f_g = self.conv1(attn)
        split_dim = f_g.shape[1] // 2
        f_x, g_x = torch.split(f_g, split_dim, dim=1)
        return torch.sigmoid(g_x) * f_x

class SpatialAttention(nn.Module):
    """A Spatial Attention block for SimVP"""

    def __init__(self, d_model, kernel_size=21):
        super().__init__()

        self.conv1 = nn.Conv2d(d_model, d_model, 1)         # 1x1 conv
        self.activation = nn.GELU()                          # GELU
        self.spatial_att = AttentionModule(d_model, kernel_size)
        self.conv2 = nn.Conv2d(d_model, d_model, 1)         # 1x1 conv

    def forward(self, x):
        skip = x.clone()
        x = self.conv1(x)
        x = self.activation(x)
        x = self.spatial_att(x)
        x = self.conv2(x)
        x = x + skip
        return x

class DWConv(nn.Module):
    def __init__(self, dim=768):
        super(DWConv, self).__init__()
        self.dwconv = nn.Conv2d(dim, dim, 3, 1, 1, bias=True, groups=dim)

    def forward(self, x):
        x = self.dwconv(x)
        return x

class MixMlp(nn.Module):
    def __init__(self,
                 in_features, hidden_features=None, out_features=None, act_layer=nn.SiLU, drop=0.):
        super().__init__()
        out_features = out_features or in_features
        hidden_features = hidden_features or in_features
        self.fc1 = nn.Conv2d(in_features, hidden_features, 1)  # 1x1
        self.dwconv = DWConv(hidden_features)                  # CFF: Convlutional feed-forward network
        self.act = act_layer(inplace=True)                                 # GELU
        self.fc2 = nn.Conv2d(hidden_features, out_features, 1) # 1x1
        self.drop = nn.Dropout(drop)
        self.apply(self._init_weights)

    def _init_weights(self, m):
        if isinstance(m, nn.Linear):
            nn.init.trunc_normal_(m.weight, std=.02)
            if isinstance(m, nn.Linear) and m.bias is not None:
                nn.init.constant_(m.bias, 0)
        elif isinstance(m, nn.LayerNorm):
            nn.init.constant_(m.bias, 0)
            nn.init.constant_(m.weight, 1.0)
        elif isinstance(m, nn.Conv2d):
            fan_out = m.kernel_size[0] * m.kernel_size[1] * m.out_channels
            fan_out //= m.groups
            m.weight.data.normal_(0, math.sqrt(2.0 / fan_out))
            if m.bias is not None:
                m.bias.data.zero_()

    def forward(self, x):
        x = self.fc1(x)
        x = self.dwconv(x)
        x = self.act(x)
        x = self.drop(x)
        x = self.fc2(x)
        x = self.drop(x)
        return x

class TCSpatialAttenBlock(nn.Module):
    """A GABlock (gSTA) for SimVP"""

    def __init__(self, dim, kernel_size=21, mlp_ratio=4.,
                 drop=0., init_value=1e-2, act_layer=nn.SiLU):
        super().__init__()
        self.norm1 = nn.InstanceNorm2d(dim)
        self.attn = SpatialAttention(dim, kernel_size)

        self.norm2 = nn.InstanceNorm2d(dim)
        mlp_hidden_dim = int(dim * mlp_ratio)
        self.mlp = MixMlp(
            in_features=dim, hidden_features=mlp_hidden_dim, act_layer=act_layer, drop=drop)

        self.layer_scale_1 = nn.Parameter(init_value * torch.ones((dim)), requires_grad=True)
        self.layer_scale_2 = nn.Parameter(init_value * torch.ones((dim)), requires_grad=True)

        self.apply(self._init_weights)

    def _init_weights(self, m):
        if isinstance(m, nn.Linear):
            nn.init.trunc_normal_(m.weight, std=.02)
            if isinstance(m, nn.Linear) and m.bias is not None:
                nn.init.constant_(m.bias, 0)
        elif isinstance(m, nn.LayerNorm):
            nn.init.constant_(m.bias, 0)
            nn.init.constant_(m.weight, 1.0)
        elif isinstance(m, nn.Conv2d):
            fan_out = m.kernel_size[0] * m.kernel_size[1] * m.out_channels
            fan_out //= m.groups
            m.weight.data.normal_(0, math.sqrt(2.0 / fan_out))
            if m.bias is not None:
                m.bias.data.zero_()

    # @torch.jit.ignore
    # def no_weight_decay(self):
    #     return {'layer_scale_1', 'layer_scale_2'}

    def forward(self, x):
        x = x + self.layer_scale_1.unsqueeze(-1).unsqueeze(-1) * self.attn(self.norm1(x))
        x = x + self.layer_scale_2.unsqueeze(-1).unsqueeze(-1) * self.mlp(self.norm2(x))
        return x

class SubTCBlock(nn.Module):
    def __init__(self, in_channels, out_channels,mlp_ratio=8.):
        super(SubTCBlock, self).__init__()
        self.in_channels = in_channels
        self.out_channels = out_channels
        self.block = TCSpatialAttenBlock(
            in_channels, kernel_size=21, mlp_ratio=mlp_ratio, act_layer=nn.SiLU)

        if in_channels != out_channels:
            self.reduction = nn.Conv2d(
                in_channels, out_channels, kernel_size=1, stride=1, padding=0)

    def forward(self, x):
        z = self.block(x)
        return z if self.in_channels == self.out_channels else self.reduction(z)

class TCNet(nn.Module):
    def __init__(self, channel_in, channel_hid, N2):
        super(TCNet, self).__init__()
        self.N2 = N2
        # downsample
        enc_layers = [SubTCBlock(
            channel_in, channel_hid)]
        # middle layers
        for i in range(1, N2-1):
            enc_layers.append(SubTCBlock(
                channel_hid, channel_hid))
        # upsample
        enc_layers.append(SubTCBlock(
            channel_hid, channel_in))
        self.enc = nn.Sequential(*enc_layers)

    def forward(self, x):
        B, T, C, H, W = x.shape
        x = rearrange(x, 'b t c h w -> b (t c) h w')
        z = x
        for i in range(self.N2):
            z = self.enc[i](z)

        y = z.reshape(B, T, C, H, W)
        return y


# class STFECN(nn.Module):
#     # def __init__(self, input_channels, num_step, output_channel, hiddem=32, hid_T=128, N_T=4, bilinear=True):
#     def __init__(self, in_shape, output_channel, hiddem=24, hid_T=64, N_T=6, bilinear=False):
#         super(STFECN, self).__init__()
#         T,C,H,W = in_shape
#         self.output_channel = output_channel
#         self.bilinear = bilinear
#
#         self.inc = (DoubleConv(C, hiddem))
#         self.down1 = (Down(hiddem, hiddem))
#         self.cbam_down1 = CBAM(hiddem, reduction=16)
#         self.down2 = (Down(hiddem, hiddem))
#         self.cbam_down2 = CBAM(hiddem , reduction=16)
#         self.down3 = (Down(hiddem, hiddem))
#         self.cbam_down3 = CBAM(hiddem, reduction=16)
#
#         # self.down4 = (Down(hiddem*8, hiddem*16 // factor))
#
#
#         # hid_S = 16
#         # T = 10
#         self.hid = MidMetaNet(T*hiddem, hid_T, N_T)
#
#         # self.translator = Translator(hiddem*16 // factor, hid_T, N_T, hiddem*16 // factor, incep_dilation=[1,2,3,5], groups=8)
#         # self.translator = Translator(hiddem * 8 //factor , hid_T, N_T, hiddem * 8 ,
#         #                              incep_dilation=[1, 2, 3, 5], groups=8)
#         self.bottomconv = DoubleConv(hiddem , hiddem )
#         # self.up1 = (Up(hiddem*16, hiddem*8 // factor, bilinear))
#         # self.cbam_up1 = CBAM(hiddem*8 // factor, reduction=16)
#         self.up2 = (Up(hiddem, hiddem, bilinear))
#         self.cbam_up2 = CBAM(hiddem, reduction=16)
#         self.up3 = (Up(hiddem, hiddem, bilinear))
#         self.cbam_up3 = CBAM(hiddem, reduction=16)
#         self.up4 = (Up(hiddem, hiddem, bilinear))
#         # self.res1 = BasicResBlock(hiddem*2, hiddem * 2, kernel_size=7)
#         # self.cbam_res1 = CBAM(hiddem * 2 , reduction=16)
#         # self.res2 = BasicResBlock(hiddem*2, hiddem * 2,kernel_size=5)
#         # self.cbam_res2 = CBAM(hiddem * 2, reduction=16)
#         # self.res3 = BasicResBlock(hiddem * 2, hiddem * 2)
#         self.outc = (OutConv(hiddem, self.output_channel))
#
#         self.fpg_module1 = FPG(img_size=640,
#                               patch_size=16,
#                               in_channels=C,
#                               out_channels=C,
#                               embed_dim=128,
#                               input_frames=20,
#                               depth=2,
#                               mlp_ratio=4.,
#                               uniform_drop=False,
#                               drop_rate=0.,
#                               drop_path_rate=0.,
#                               norm_layer=None,
#                               dropcls=0.)
#         #
#         # self.fpg_module2 = FPG(img_size=320,
#         #                        patch_size=16,
#         #                        in_channels=3,
#         #                        out_channels=3,
#         #                        embed_dim=256,
#         #                        input_frames=20,
#         #                        depth=2,
#         #                        mlp_ratio=4.,
#         #                        uniform_drop=False,
#         #                        drop_rate=0.,
#         #                        drop_path_rate=0.,
#         #                        norm_layer=None,
#         #                        dropcls=0.)
#         #
#         # self.fpg_module3 = FPG(img_size=160,
#         #                        patch_size=16,
#         #                        in_channels=3,
#         #                        out_channels=3,
#         #                        embed_dim=256,
#         #                        input_frames=20,
#         #                        depth=2,
#         #                        mlp_ratio=4.,
#         #                        uniform_drop=False,
#         #                        drop_rate=0.,
#         #                        drop_path_rate=0.,
#         #                        norm_layer=None,
#         #                        dropcls=0.)
#
#     def forward(self, input):
#         B, T, C, H, W = input.shape
#         # fx1 = self.fpg_module1(input)
#         x = input.reshape(B * T, C, H, W)
#         # 编码
#         x1 = self.inc(x)
#         # x1 = x1.reshape(B , 2*T, C, H, W)
#         # B, T, C, H, W = x1.shape
#         # fx1 = self.fpg_module1(x1.view(B, T, -1, H, W))
#         x2 = self.down1(x1)
#         x2 = self.cbam_down1(x2)
#         # fx2 = self.fpg_module2(x2)
#         x3 = self.down2(x2)
#         x3 = self.cbam_down2(x3)
#         # fx3 = self.fpg_module3(x3)
#         x4 = self.down3(x3)
#         x4 = self.cbam_down3(x4)
#         # x5 = self.down4(x4)
#         # print(x5.shape)
#         # B_, T_,C_, H_, W_ = x5.shape
#         # B_, T_, C_, H_, W_ = x4.shape
#         _, C_, H_, W_ = x4.shape
#         # 时空模块
#         # x_bottom = self.translator(x5)
#         x_bottom = self.hid(x4.view(B, C_, T, H_, W_))
#         # assert not torch.any(torch.isnan(x_bottom))
#         # x_bottom = self.translator(x4)
#         x_bottom = x_bottom.reshape(B * T, C_, H_, W_)
#         # x_bottom = self.bottomconv(x_bottom)
#         # assert not torch.any(torch.isnan(x_bottom))
#         # 解码
#         # x = self.up1(x_bottom, x4)
#         # x = self.cbam_up1(x)
#         # x = self.up2(x, x3)
#         x = self.up2(x_bottom, x3) #x3
#         x = self.cbam_up2(x)
#         x = self.up3(x, x2) #x2
#         x = self.cbam_up3(x)
#         x = self.up4(x, x1) #+fx1.view(B*T,-1, H,W)
#         # x = self.res1(x)
#         # x = self.cbam_res1(x)
#         # x = self.res2(x)
#         # x = self.cbam_res2(x)
#         # x = self.res3(x)
#         radar = self.outc(x)
#
#         return radar.view(B,T,C,H,W)#+fx1
#
# def sampling_generator(N, reverse=False):
#     samplings = [False, True] * (N // 2)
#     if reverse: return list(reversed(samplings[:N]))
#     else: return samplings[:N]


class BasicConv2d(nn.Module):
    def __init__(self,
                 in_channels,
                 out_channels,
                 kernel_size=3,
                 stride=1,
                 padding=0,
                 dilation=1,
                 upsampling=False,
                 act_norm=False,
                 act_inplace=True):
        super(BasicConv2d, self).__init__()
        self.act_norm = act_norm
        if upsampling is True:
            self.conv = nn.Sequential(*[
                nn.Conv2d(in_channels, out_channels*4, kernel_size=kernel_size,
                          stride=1, padding=padding, dilation=dilation),
                nn.PixelShuffle(2)
            ])
            # self.conv = nn.Sequential(*[nn.Conv2d(in_channels, out_channels, kernel_size=kernel_size,
            #           stride=1, padding=padding, dilation=dilation),
            #     nn.Upsample(scale_factor=2, mode='bilinear')
            #                             ])
        else:
            self.conv = nn.Conv2d(
                in_channels, out_channels, kernel_size=kernel_size,
                stride=stride, padding=padding, dilation=dilation)

        self.norm = nn.GroupNorm(2, out_channels)
        # self.act = nn.GELU() #inplace=act_inplace
        self.act = nn.SiLU(inplace=act_inplace)

        self.apply(self._init_weights)

    def _init_weights(self, m):
        if isinstance(m, (nn.Conv2d)):
            nn.init.trunc_normal_(m.weight, std=.02)
            nn.init.constant_(m.bias, 0)

    def forward(self, x):
        y = self.conv(x)
        if self.act_norm:
            y = self.act(self.norm(y))
        return y


class ConvLayer(nn.Module):

    def __init__(self,
                 C_in,
                 C_out,
                 kernel_size=3,
                 downsampling=False,
                 upsampling=False,
                 act_norm=True,
                 act_inplace=True):
        super(ConvLayer, self).__init__()

        stride = 2 if downsampling is True else 1
        padding = (kernel_size - stride + 1) // 2

        self.conv = BasicConv2d(C_in, C_out, kernel_size=kernel_size, stride=stride,
                                upsampling=upsampling, padding=padding,
                                act_norm=act_norm, act_inplace=act_inplace)

    def forward(self, x):
        y = self.conv(x)
        return y

# class Encoder(nn.Module):
#     """3D Encoder for SimVP"""
#
#     def __init__(self, C_in, C_hid, N_S, spatio_kernel, act_inplace=True):
#         # samplings = sampling_generator(N_S)
#         super(Encoder, self).__init__()
#
#         self.conv1 = (ConvSC(C_in, C_hid, spatio_kernel, downsampling=False,  act_inplace=act_inplace))
#         self.conv2 = (ConvSC(C_hid, C_hid, spatio_kernel, downsampling=True, act_inplace=act_inplace))
#         self.cbam2 = (CBAM(C_hid, reduction=8))
#         # self.enc = nn.Sequential(*self.enclist)
#
#     def forward(self, x):  # B*4, 3, 128, 128
#         enc1 = self.conv1(x)
#         # latent = enc1
#         encodeList = [enc1]
#         latent = self.conv2(enc1)
#         latent = self.cbam2(latent)
#         encodeList.append(latent)
#         return encodeList

class GroupConv2d(nn.Module):
    def __init__(self, in_channels, out_channels, kernel_size, stride, padding, groups, act_norm=False):
        super(GroupConv2d, self).__init__()
        self.act_norm = act_norm
        if in_channels % groups != 0:
            groups = 1
        self.conv = nn.Conv2d(in_channels, out_channels, kernel_size=kernel_size,
                              stride=stride, padding=padding, groups=groups)
        self.norm = nn.GroupNorm(groups, out_channels)
        self.activate = nn.LeakyReLU(0.2, inplace=True)

    def forward(self, x):
        y = self.conv(x)
        if self.act_norm:
            y = self.activate(self.norm(y))
        return y


class Inception(nn.Module):
    def __init__(self, C_in, C_hid, C_out, incep_ker=[3, 5, 7, 11], groups=8):
        super(Inception, self).__init__()
        self.conv1 = nn.Conv2d(C_in, C_hid, kernel_size=1, stride=1, padding=0)
        layers = []
        for ker in incep_ker:
            layers.append(GroupConv2d(C_hid, C_out, kernel_size=ker,
                          stride=1, padding=ker//2, groups=groups, act_norm=True))
        self.layers = nn.Sequential(*layers)

    def forward(self, x):
        x = self.conv1(x)
        y = 0
        for layer in self.layers:
            y += layer(x)
        return y

class DynamicTCNet(nn.Module):
    def __init__(self, channel_in, channel_hid, N_T, incep_ker=[3, 5, 7, 11], groups=8):
        super(DynamicTCNet, self).__init__()

        self.N_T = N_T
        enc_layers = [Inception(
            channel_in, channel_hid//2, channel_hid, incep_ker=incep_ker, groups=groups)]
        for i in range(1, N_T-1):
            enc_layers.append(Inception(
                channel_hid, channel_hid//2, channel_hid, incep_ker=incep_ker, groups=groups))
        enc_layers.append(Inception(channel_hid, channel_hid //
                          2, channel_hid, incep_ker=incep_ker, groups=groups))

        dec_layers = [Inception(
            channel_hid, channel_hid//2, channel_hid, incep_ker=incep_ker, groups=groups)]
        for i in range(1, N_T-1):
            dec_layers.append(Inception(
                2*channel_hid, channel_hid//2, channel_hid, incep_ker=incep_ker, groups=groups))
        dec_layers.append(Inception(2*channel_hid, channel_hid //
                          2, channel_in, incep_ker=incep_ker, groups=groups))

        self.enc = nn.Sequential(*enc_layers)
        self.dec = nn.Sequential(*dec_layers)

    def forward(self, input_state):
        B, T, C, H, W = input_state.shape
        # input_state = input_state.reshape(B, T*C, H, W)
        input_state = rearrange(input_state, 'b t c h w -> b (t c) h w')
        # encoder
        skips = []
        hidden_embed = input_state
        for i in range(self.N_T):
            hidden_embed = self.enc[i](hidden_embed)
            if i < self.N_T - 1:
                skips.append(hidden_embed)

        # decoder
        hidden_embed = self.dec[0](hidden_embed)
        for i in range(1, self.N_T):
            hidden_embed = self.dec[i](torch.cat([hidden_embed, skips[-i]], dim=1))

        # output_state = hidden_embed.reshape(B, T, C, H, W)
        output_state = rearrange(hidden_embed, 'b (t c) h w -> b t c h w', t=T)
        return output_state


# class Decoder(nn.Module):
#     """3D Decoder for SimVP"""
#
#     def __init__(self, C_hid, C_out, N_S, spatio_kernel, act_inplace=True):
#         samplings = sampling_generator(N_S, reverse=True)
#         super(Decoder, self).__init__()
#
#         self.declist = []
#         for s in samplings[:-1]:
#             self.declist.append(ConvSC(C_hid, C_hid, spatio_kernel, upsampling=s,
#                                        act_inplace=act_inplace))
#             self.declist.append(CBAM(C_hid, reduction=1))
#         self.declist.append(ConvSC(C_hid, C_hid, spatio_kernel, upsampling=samplings[-1],
#                                    act_inplace=act_inplace))
#
#         self.dec = nn.Sequential(*self.declist)
#         # self.dec = nn.Sequential(
#         #     *[ConvSC(C_hid, C_hid, spatio_kernel, upsampling=s,
#         #              act_inplace=act_inplace) for s in samplings[:-1]],
#         #       ConvSC(C_hid, C_hid, spatio_kernel, upsampling=samplings[-1],
#         #              act_inplace=act_inplace)
#         # )
#         self.readout = nn.Conv2d(C_hid, C_out, 1)
#
#     def forward(self, hid, enc1=None):
#         for i in range(0, len(self.dec)-1):
#             hid = self.dec[i](hid)
#         Y = self.dec[-1](hid + enc1)
#         Y = self.readout(Y)
#         return Y



class TerrainEncoder(nn.Module):
    """经典的地形特征编码器，用于处理静态地形数据"""
    def __init__(self, terrain_channels=1, hid_channels=16, output_channels=16):
        super(TerrainEncoder, self).__init__()
        # 使用经典的卷积层提取地形特征
        self.terrain_enc = nn.Sequential(
            nn.Conv2d(terrain_channels, hid_channels, kernel_size=3, stride=1, padding=1),
            nn.LeakyReLU(inplace=True),

            nn.Conv2d(hid_channels, hid_channels*2, kernel_size=3, stride=2, padding=1),
            nn.LeakyReLU(inplace=True),

            nn.Conv2d(hid_channels*2, hid_channels*2, kernel_size=3, stride=1, padding=1),
            nn.LeakyReLU(inplace=True),

            nn.Conv2d(hid_channels*2, output_channels, kernel_size=1, stride=1, padding=0),
        )


    def forward(self, terrain):


        features = self.terrain_enc(terrain)
        return features

class NWPEncoder(nn.Module):
    def __init__(self, terrain_channels=1, hid_channels=16, output_channels=16):
        super(NWPEncoder, self).__init__()
        # 使用经典的卷积层提取地形特征
        self.terrain_enc = nn.Sequential(
            nn.Conv2d(terrain_channels, hid_channels, kernel_size=3, stride=1, padding=1),
            nn.LeakyReLU(inplace=True),

            nn.Conv2d(hid_channels, hid_channels*2, kernel_size=3, stride=1, padding=1),
            nn.LeakyReLU(inplace=True),

            nn.Conv2d(hid_channels*2, hid_channels*2, kernel_size=3, stride=1, padding=1),
            nn.LeakyReLU(inplace=True),

            nn.Conv2d(hid_channels*2, output_channels, kernel_size=1, stride=1, padding=0),
        )


    def forward(self, terrain):


        features = self.terrain_enc(terrain)
        return features

class FiLMCondition(nn.Module):
    def __init__(self, in_c, feat_c):
        super().__init__()
        self.pool = nn.AdaptiveAvgPool2d(1)
        self.mlp = nn.Sequential(nn.Linear(in_c, feat_c*2))
        self.feat_c = feat_c
    def forward(self, cond_feat): # [B,Cc,H,W]
        B,  Cc, H, W = cond_feat.shape
        v = self.pool(cond_feat).reshape(B, -1)
        gamma_beta = self.mlp(v).view(B, 2, self.feat_c, 1, 1)
        return gamma_beta[:,0], gamma_beta[:,1] # gamma, beta

class FiLM(nn.Module):
    def __init__(self, in_c, feat_c):
        super().__init__()
        self.film = FiLMCondition(in_c, feat_c)
    def forward(self, feat, cond_feat): # [B,Cc,H,W]

        gamma, beta = self.film(cond_feat)
        b,c,h,w = gamma.shape
        gamma = gamma.unsqueeze(1).expand(b, 20, c, h, w).reshape(-1, c, h, w)
        beta = beta.unsqueeze(1).expand(b, 20, c, h, w).reshape(-1,c, h, w)
        feat = gamma * feat + beta
        return feat

# class CrossAttention2D(nn.Module):
#     def __init__(self, dim, num_heads=8):
#         super().__init__()
#         self.num_heads = num_heads
#         self.scale = (dim // num_heads) ** -0.5

#         self.to_q = nn.Conv2d(dim, dim, 1)
#         self.to_k = nn.Conv2d(dim, dim, 1)
#         self.to_v = nn.Conv2d(dim, dim, 1)
#         self.proj = nn.Conv2d(dim, dim, 1)

#     def forward(self, x_q, x_kv):
#         """
#         x_q: Query 特征图 (B, C, Hq, Wq) — 比如雷达
#         x_kv: Key/Value 特征图 (B, C, Hk, Wk) — 比如降水
#         """
#         B, C, Hq, Wq = x_q.shape
#         _, _, Hk, Wk = x_kv.shape
#         Nq, Nk = Hq * Wq, Hk * Wk

#         # [B, heads, C//heads, N]
#         q = self.to_q(x_q).reshape(B, self.num_heads, C // self.num_heads, Nq).permute(0,1,3,2)
#         k = self.to_k(x_kv).reshape(B, self.num_heads, C // self.num_heads, Nk)
#         v = self.to_v(x_kv).reshape(B, self.num_heads, C // self.num_heads, Nk).permute(0,1,3,2)

#         # Attention
#         attn = (q @ k) * self.scale               # [B, heads, Nq, Nk]
#         attn = attn.softmax(dim=-1)

#         out = attn @ v                            # [B, heads, Nq, C//heads]
#         out = out.permute(0,1,3,2).reshape(B, C, Hq, Wq)
#         out = self.proj(out)
#         return out

class ConvFusion(nn.Module):
    def __init__(self, in_channels):
        super().__init__()
        self.conv = nn.Sequential(
            ConvLayer(in_channels*2, in_channels, 3, downsampling=False),
            ConvLayer(in_channels, in_channels, 3, downsampling=False)
        )

    def forward(self, radar, rain):
        return self.conv(torch.cat([radar, rain], dim=1))

class GatedFusion(nn.Module):
    def __init__(self, channels):
        super().__init__()
        self.gate = nn.Sequential(
            nn.Conv2d(channels * 2, channels, 3, padding=1),
            nn.ReLU(inplace=True),
            nn.Conv2d(channels, channels, 1),
            nn.Sigmoid()
        )

    def forward(self, rain, nwp):
        g = self.gate(torch.cat([rain, nwp], dim=1))
        fused = g * nwp + (1 - g) * rain
        return fused


class MultiModel(nn.Module):
    def __init__(self, in_shape,in_prep_shape, hid_S=32, hid_T=256, N_S=4, N_T=4, # in_shape 是 雷达的形状； in_prep_shape 是 降雨的形状
                  spatio_kernel_enc=3,upfactor =4  ):
        super(MultiModel, self).__init__()
        T, C, H, W = in_shape  # T is pre_seq_length
        prepT, prepC, prepH, prepW = in_prep_shape
        # nwpT, nwpC, nwpH, nwpW = in_nwp_shape
        C = C * (upfactor * upfactor)
        prepC = prepC * (upfactor * upfactor)
        nwpC = 1
        act_inplace = False
        self.hid_S = hid_S
        #雷达
        self.enc1 = (ConvLayer(C, hid_S, spatio_kernel_enc, downsampling=False, act_inplace=act_inplace))
        self.enc2 = (ConvLayer(hid_S, hid_S, spatio_kernel_enc, downsampling=True, act_inplace=act_inplace))

        #降水
        self.prepEnc1 = (ConvLayer(prepC, hid_S, spatio_kernel_enc, downsampling=False, act_inplace=act_inplace))
        self.prepEnc2 = (ConvLayer(hid_S, hid_S, spatio_kernel_enc, downsampling=False, act_inplace=act_inplace))
        self.prepEnc3 = (ConvLayer(hid_S, hid_S, spatio_kernel_enc, downsampling=True, act_inplace=act_inplace))

        self.dec1 = ConvLayer(hid_S, hid_S, spatio_kernel_enc, upsampling=True, act_inplace=act_inplace)
        self.dec2 = ConvLayer(hid_S, hid_S, spatio_kernel_enc, upsampling=False, act_inplace=act_inplace)
        self.dec3 = ConvLayer(hid_S, hid_S, spatio_kernel_enc, upsampling=False, act_inplace=act_inplace)
        self.readout = nn.Conv2d(hid_S // (upfactor * upfactor), 1, 1)

        # 雷达
        self.hid = TCNet(T * hid_S, hid_T, N_T)
        self.hid2 = DynamicTCNet(T*hid_S, hid_T, N_T//2, incep_ker=[3, 5, 7,11], groups=8)
        # 雷达 2nd
        self.hid_2nd = TCNet(T * hid_S, hid_T, N_T)
        self.hid2_2nd = DynamicTCNet(T*hid_S, hid_T, N_T//2, incep_ker=[3, 5, 7,11], groups=8)

        #降水
        self.hidRain = TCNet(T * hid_S, hid_T, N_T)

        #for nwp
        self.nwp_encoder = NWPEncoder(
            terrain_channels=nwpC,
            hid_channels=16,
            output_channels=hid_S  # 输出通道数为hid_S的1/4
        )
        # for terrain - 地形特征编码器
        self.terrain_encoder = TerrainEncoder(
            terrain_channels=1,
            hid_channels=16,
            output_channels=hid_S//4  # 输出通道数为hid_S的1/4
        )
        #低级

        #中级
        self.fusionRadarPrep = ConvFusion(hid_S)
        #高级
        #self.filmNWP = FiLM(hid_S//4,hid_S)
        self.fusionNWP = GatedFusion(hid_S)
        self.act = nn.Sigmoid()
        self.pixelUnshuffleRaw = nn.PixelUnshuffle(downscale_factor=upfactor)
        self.pixelUnshuffleRain = nn.PixelUnshuffle(downscale_factor=upfactor)
        self.pixelup = nn.PixelShuffle(upscale_factor=upfactor)
    def forward(self, rain_raw, radar_raw, NWP = None, terrain = None): # x_raw 是雷达数据，prep_raw是降雨数据
        # 编码地形特征
        B, T, _, H_raw, W_raw = rain_raw.shape
        rain_raw = self.pixelUnshuffleRain(rain_raw)
        radar_raw = self.pixelUnshuffleRaw(radar_raw)
        # print(rain_raw.shape,radar_raw.shape)
        # exit(1)
        if terrain is not None:
            terrain = terrain.unsqueeze(1)  # (B, H, W) -> (B, 1, H, W)
            terrain = F.interpolate(terrain, size=(301, 301), mode='bilinear', align_corners=False)  # (B,1， H, W)

            # terrain_features = self.terrain_encoder(terrain)  # (B, hid_S//4, H'//2, W'//2)
            # 扩展地形特征到时间维度 (B, hid_S//4, H', W') -> (B, T, hid_S//4, H', W')
            # terrain_features = terrain_features.unsqueeze(1).expand(-1, -1, -1, -1)

            B, T, C, H, W = rain_raw.shape
            # 地形和降雨拼接
            terrain = terrain.unsqueeze(dim=1).expand(-1, T, -1, -1, -1)  # (B, T, 1, H, W)
            radar_raw_terrain = torch.cat([radar_raw, terrain], dim=2)  # (B, T, 2, H, W)
        else:
            radar_raw_terrain = radar_raw

        radar_raw_terrain = rearrange(radar_raw_terrain,'b t c h w -> (b t) c h w')

        # 降雨和地形一起编码
        prepB, prepT, prepC, prepH, prepW = radar_raw.shape
        prep_terr1 = self.prepEnc1(radar_raw_terrain)
        prep_terr2 = self.prepEnc2(prep_terr1)
        prep_terr3 = self.prepEnc3(prep_terr2)
        prep_terr = rearrange(prep_terr3, '(b t) c h w -> b t c h w', t=prepT)
        prep_terr = self.hid(prep_terr) + self.hid2(prep_terr)
        prep_terr = rearrange(prep_terr,  'b t c h w -> (b t) c h w',t=T)


        # 插值NWP数据使其与radar_raw的空间分辨率匹配
        # NWP shape: (B, T, 1, 167, 167) -> (B, T, 1, 301, 301)
        if NWP is not None:
            NWP_reshaped = rearrange(NWP, 'b t c h w -> (b t) c h w')
            NWP_interpolated = F.interpolate(NWP_reshaped, size=(151, 151), mode='bilinear', align_corners=False)
            # NWP_reshaped = rearrange(NWP_interpolated, '(b t) c h w -> b t c h w', t=prepT)
            NWP_reshaped = self.nwp_encoder(NWP_interpolated)
            prep_Nwp_terr = self.fusionNWP(prep_terr, NWP_reshaped)
        else:
            prep_Nwp_terr = prep_terr

        # 2nd bottelneck 处理
        # prep_Nwp_terr = rearrange(prep_Nwp_terr, '(b t) c h w -> b t c h w', t=T)
        # prep_Nwp_terr = self.hid_2nd(prep_Nwp_terr) + self.hid2_2nd(prep_Nwp_terr)
        # prep_Nwp_terr = rearrange(prep_Nwp_terr, 'b t c h w -> (b t) c h w', t=T)

        # 降水数据编码
        rain_raw = rearrange(rain_raw, 'b t c h w -> (b t) c h w')
        latent = self.enc1(rain_raw)
        latent = self.enc2(latent)  # down 2x
        # print("latent shape after enc2", latent.shape)
        latent = rearrange(latent, '(b t) c h w -> b t c h w', t=T)
        latent = self.hidRain(latent)

        # 降雨和雷达融合
        latent = rearrange(latent, 'b t c h w -> (b t) c h w', t=T)
        prep_Nwp_terr_rad = self.fusionRadarPrep(prep_Nwp_terr, latent)


        # 第三层
        prep_Nwp_terr_rad1 = self.dec1(prep_Nwp_terr_rad ) #+ latent

        # 第二层
        # prep_Nwp_terr_rad1 = prep_Nwp_terr_rad1[:,:,:H,:W]\
        prep_Nwp_terr_rad1 = prep_Nwp_terr_rad1
        prep_Nwp_terr_rad2 = self.dec2(prep_Nwp_terr_rad1)
        prep_Nwp_terr_rad2 = prep_Nwp_terr_rad1 + prep_Nwp_terr_rad2

        # 第一层
        # prep_Nwp_terr_rad2 = prep_Nwp_terr_rad2[:,:,:H,:W]
        prep_Nwp_terr_rad2 = prep_Nwp_terr_rad2
        prep_Nwp_terr_rad3 = self.dec3(prep_Nwp_terr_rad2) #+enc1
        prep_Nwp_terr_rad3 = prep_Nwp_terr_rad2 + prep_Nwp_terr_rad3
        prep_Nwp_terr_rad3 = self.pixelup(prep_Nwp_terr_rad3)
        # print(prep_Nwp_terr_rad3.shape)
        # exit(1)
        prep_Nwp_terr_rad_final = self.readout(prep_Nwp_terr_rad3)


        Y = rearrange(prep_Nwp_terr_rad_final, '(b t) c h w -> b t c h w', t = T)
        # Y = Y[:,:,:,:H,:W]
        return Y

def sampling_generator(N, reverse=False):
    samplings = [False, True] * (N // 2)
    if reverse: return list(reversed(samplings[:N]))
    else: return samplings[:N]


class Encoder(nn.Module):
    """3D Encoder for SimVP"""

    def __init__(self, C_in, C_hid, N_S, spatio_kernel, act_inplace=True):
        samplings = sampling_generator(N_S)
        super(Encoder, self).__init__()
        self.enc = nn.Sequential(
              ConvSC(C_in, C_hid, spatio_kernel, downsampling=samplings[0],
                     act_inplace=act_inplace),
            *[ConvSC(C_hid, C_hid, spatio_kernel, downsampling=s,
                     act_inplace=act_inplace) for s in samplings[1:]]
        )

    def forward(self, x):  # B*4, 3, 128, 128
        enc1 = self.enc[0](x)
        latent = enc1
        for i in range(1, len(self.enc)):
            latent = self.enc[i](latent)
        return latent, enc1


class Decoder(nn.Module):
    """3D Decoder for SimVP"""

    def __init__(self, C_hid, C_out, N_S, spatio_kernel, act_inplace=True):
        samplings = sampling_generator(N_S, reverse=True)
        super(Decoder, self).__init__()
        self.dec = nn.Sequential(
            *[ConvSC(C_hid, C_hid, spatio_kernel, upsampling=s,
                     act_inplace=act_inplace) for s in samplings[:-1]],
              ConvSC(C_hid, C_hid, spatio_kernel, upsampling=samplings[-1],
                     act_inplace=act_inplace)
        )
        self.readout = nn.Conv2d(C_hid, C_out, 1)

    def forward(self, hid, enc1=None):
        for i in range(0, len(self.dec)-1):
            hid = self.dec[i](hid)
        Y = self.dec[-1](hid + enc1)
        Y = self.readout(Y)
        return Y


class MidIncepNet(nn.Module):
    """The hidden Translator of IncepNet for SimVPv1"""

    def __init__(self, channel_in, channel_hid, N2, incep_ker=[3,5,7,11], groups=8, **kwargs):
        super(MidIncepNet, self).__init__()
        assert N2 >= 2 and len(incep_ker) > 1
        self.N2 = N2
        enc_layers = [gInception_ST(
            channel_in, channel_hid//2, channel_hid, incep_ker= incep_ker, groups=groups)]
        for i in range(1,N2-1):
            enc_layers.append(
                gInception_ST(channel_hid, channel_hid//2, channel_hid,
                              incep_ker=incep_ker, groups=groups))
        enc_layers.append(
                gInception_ST(channel_hid, channel_hid//2, channel_hid,
                              incep_ker=incep_ker, groups=groups))
        dec_layers = [
                gInception_ST(channel_hid, channel_hid//2, channel_hid,
                              incep_ker=incep_ker, groups=groups)]
        for i in range(1,N2-1):
            dec_layers.append(
                gInception_ST(2*channel_hid, channel_hid//2, channel_hid,
                              incep_ker=incep_ker, groups=groups))
        dec_layers.append(
                gInception_ST(2*channel_hid, channel_hid//2, channel_in,
                              incep_ker=incep_ker, groups=groups))

        self.enc = nn.Sequential(*enc_layers)
        self.dec = nn.Sequential(*dec_layers)

    def forward(self, x):
        B, T, C, H, W = x.shape
        x = x.reshape(B, T*C, H, W)

        # encoder
        skips = []
        z = x
        for i in range(self.N2):
            z = self.enc[i](z)
            if i < self.N2-1:
                skips.append(z)
        # decoder
        z = self.dec[0](z)
        for i in range(1,self.N2):
            z = self.dec[i](torch.cat([z, skips[-i]], dim=1) )

        y = z.reshape(B, T, C, H, W)
        return y


class MetaBlock(nn.Module):
    """The hidden Translator of MetaFormer for SimVP"""

    def __init__(self, in_channels, out_channels, input_resolution=None, model_type=None,
                 mlp_ratio=8., drop=0.0, drop_path=0.0, layer_i=0):
        super(MetaBlock, self).__init__()
        self.in_channels = in_channels
        self.out_channels = out_channels
        model_type = model_type.lower() if model_type is not None else 'gsta'

        if model_type == 'tau':
            self.block = TAUSubBlock(
                in_channels, kernel_size=10, mlp_ratio=mlp_ratio,
                drop=drop, drop_path=drop_path, act_layer=nn.GELU)
            # self.block = TAUSubBlock(
            #     in_channels, kernel_size=21, mlp_ratio=mlp_ratio,
            #     drop=drop, drop_path=drop_path, act_layer=nn.GELU)
        else:
            assert False and "Invalid model_type in SimVP"

        if in_channels != out_channels:
            self.reduction = nn.Conv2d(
                in_channels, out_channels, kernel_size=1, stride=1, padding=0)

    def forward(self, x):
        z = self.block(x)
        return z if self.in_channels == self.out_channels else self.reduction(z)


class MidMetaNet(nn.Module):
    """The hidden Translator of MetaFormer for SimVP"""

    def __init__(self, channel_in, channel_hid, N2,
                 input_resolution=None, model_type=None,
                 mlp_ratio=4., drop=0.0, drop_path=0.1):
        super(MidMetaNet, self).__init__()
        assert N2 >= 2 and mlp_ratio > 1
        self.N2 = N2
        dpr = [  # stochastic depth decay rule
            x.item() for x in torch.linspace(1e-2, drop_path, self.N2)]

        # downsample
        enc_layers = [MetaBlock(
            channel_in, channel_hid, input_resolution, model_type,
            mlp_ratio, drop, drop_path=dpr[0], layer_i=0)]
        # middle layers
        for i in range(1, N2-1):
            enc_layers.append(MetaBlock(
                channel_hid, channel_hid, input_resolution, model_type,
                mlp_ratio, drop, drop_path=dpr[i], layer_i=i))
        # upsample
        enc_layers.append(MetaBlock(
            channel_hid, channel_in, input_resolution, model_type,
            mlp_ratio, drop, drop_path=drop_path, layer_i=N2-1))
        self.enc = nn.Sequential(*enc_layers)

    def forward(self, x):
        B, T, C, H, W = x.shape
        x = x.reshape(B, T*C, H, W)

        z = x
        for i in range(self.N2):
            z = self.enc[i](z)

        y = z.reshape(B, T, C, H, W)
        return y



